/**
 * 桌面壳托盘对接：把工作区与本地化文案下发给原生托盘，并把托盘的
 * 「进入工作区」命令转成页面导航。浏览器打开同一页面时全部退化为空操作。
 *
 * 托盘本体由 `src-tauri/src/tray.rs` 持有；本模块只负责 IPC 与装配接线。
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/** 托盘菜单里的一个工作区条目。 */
export type TrayWorkspaceEntry = {
    /** 页面侧持有的工作区 id。 */
    readonly id: string;
    /** 菜单显示名。 */
    readonly title: string;
};
/** 托盘菜单文案（本地化后下发）。 */
export type DesktopTrayLabels = {
    /** 恢复主窗口。 */
    readonly show: string;
    /** 退出 DSH。 */
    readonly quit: string;
    /** 无工作区时的占位行。 */
    readonly empty: string;
};
/**
 * 把工作区列表与菜单文案下发给原生托盘。
 * @param workspaces - 当前工作区，按菜单显示顺序排列。
 * @param labels - 本地化后的菜单文案。
 */
export declare function syncDesktopTray(workspaces: readonly TrayWorkspaceEntry[], labels: DesktopTrayLabels): void;
/**
 * 订阅托盘菜单的「进入工作区」命令。
 * @param handler - 收到工作区 id 时调用。
 * @returns 取消订阅的清理函数。
 */
export declare function onTrayOpenWorkspace(handler: (workspaceId: string) => void): () => void;
/**
 * 真正退出 DSH：结束 `dsh web` 子进程并关闭外壳。
 */
export declare function quitDesktopApp(): void;
/**
 * 装配托盘的运行期接线：前端就绪即下发本地化菜单，工作区列表变化与语言切换
 * 都会重建菜单，托盘命令则转成页面导航。
 * @param ctx - client 根上下文（apply 世界）。
 * @returns 释放本次接线的清理函数。
 */
export declare function installDesktopTray(ctx: ClientContext): () => void;
//# sourceMappingURL=tray.d.ts.map