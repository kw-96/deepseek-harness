/**
 * 桌面壳外链出口：WebView 里点击 http(s) 外链时交给系统默认浏览器。
 *
 * 壳不会为 `target="_blank"` 创建新窗口（Tauri 默认拒绝该请求），所以这里
 * 拦下点击、调用壳的 `open_external` 命令；同窗口导航由壳的导航钩子兜底。
 * 浏览器标签页没有 Tauri 全局对象，本模块不做任何事。
 */
/**
 * 安装外链点击拦截；返回卸载函数。非桌面壳环境返回 undefined。
 * @returns 移除监听器的函数，或非桌面壳下的 undefined。
 */
export declare function installExternalLinkHandler(): (() => void) | undefined;
//# sourceMappingURL=external-links.d.ts.map