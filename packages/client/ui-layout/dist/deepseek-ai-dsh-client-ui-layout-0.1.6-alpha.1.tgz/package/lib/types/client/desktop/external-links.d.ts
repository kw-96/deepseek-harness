/**
 * 安装外链点击拦截；返回卸载函数。非桌面壳环境返回 undefined。
 * @returns 移除监听器的函数，或非桌面壳下的 undefined。
 */
export declare function installExternalLinkHandler(): (() => void) | undefined;
//# sourceMappingURL=external-links.d.ts.map