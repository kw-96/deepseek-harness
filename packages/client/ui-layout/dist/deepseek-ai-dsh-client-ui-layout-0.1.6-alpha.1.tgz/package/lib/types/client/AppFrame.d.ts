import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createLayoutStore } from './stores.ts';
/** Injected desktop callbacks assembled in apply. */
export type AppFrameInjected = {
    /** Select a session as current (desktop title-bar history / neighbor nav). */
    openSession: (id: SessionId) => void;
    /**
     * 右侧面板开合（桌面标题栏按钮与 View 菜单）：装配层把它接到官方右栏
     * （ui-sidebar-right 的 toggleExpanded），组合里没有该包时回落到 details 列。
     */
    toggleRightbar: () => void;
    /**
     * 底部面板开合（桌面标题栏按钮与 View 菜单）：外部底部工作台在场时由装配层
     * 直接驱动它并返回 true；返回 false 表示没有该占用者，由框架回落到本地
     * bottom 列。
     */
    toggleBottom: () => boolean;
};
/** Full composed props: runtime share + child-slot render share + store share. */
export type AppFrameProps = PropsRuntime<'root'> & PropsRenderSlots<'sidebar' | 'conversation' | 'main' | 'details' | 'rightbar' | 'bottom' | 'shell.overlay'> & PropsStore<ReturnType<typeof createLayoutStore>> & PropsLocale<'common'> & InjectFace<AppFrameInjected>;
/** The three-column frame (see module doc). */
export declare function AppFrame({ useStore, useSessions, usePanelInfo, actions, renderSlot, SessionProvider, openSession, toggleRightbar, toggleBottom: toggleBottomExternal, t, }: AppFrameProps): import("react").JSX.Element;
//# sourceMappingURL=AppFrame.d.ts.map