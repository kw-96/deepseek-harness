/**
 * Detect whether the page runs inside the experimental Tauri desktop shell.
 * Browser tabs never expose the Tauri globals injected by withGlobalTauri.
 */
/** True when the WebView carries Tauri IPC globals. */
export declare function isDesktopShell(): boolean;
//# sourceMappingURL=detect.d.ts.map