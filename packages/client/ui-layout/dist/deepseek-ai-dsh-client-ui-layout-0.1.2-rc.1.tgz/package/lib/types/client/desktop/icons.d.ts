/** Inline SVG glyphs for the desktop title bar (no ui-primitives dependency). */
/** Sidebar panel toggle glyph. */
export declare function PanelIcon(): import("react").JSX.Element;
/** Back chevron. */
export declare function ChevronLeft(): import("react").JSX.Element;
/** Forward chevron. */
export declare function ChevronRight(): import("react").JSX.Element;
/** Window minimize glyph. */
export declare function MinIcon(): import("react").JSX.Element;
/** Window maximize glyph. */
export declare function MaxIcon(): import("react").JSX.Element;
/** Window close glyph. */
export declare function CloseIcon(): import("react").JSX.Element;
//# sourceMappingURL=icons.d.ts.map