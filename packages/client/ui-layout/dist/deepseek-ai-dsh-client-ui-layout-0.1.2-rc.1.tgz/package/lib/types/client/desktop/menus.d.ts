/** Menu model builders for the desktop title bar. */
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
import type { DesktopAppWindow } from './window.ts';
import type { CommonKey } from '@deepseek-ai/dsh-client-locale/client';
/** Locale translator for common desktop title-bar keys. */
export type DesktopTitleBarT = (key: CommonKey) => string;
/** One dropdown row or separator. */
export type MenuItem = {
    kind: 'item';
    id: string;
    label: string;
    shortcut?: string;
    disabled?: boolean;
    run: () => void;
} | {
    kind: 'sep';
};
/** Top-level menu identifier. */
export type MenuId = 'file' | 'edit' | 'view';
/** Read the current document zoom factor. */
export declare function readZoom(): number;
/** Apply a document zoom factor (Chromium / WebView2). */
export declare function setZoom(factor: number): void;
/** Run a document editing command when the browser supports it. */
export declare function editCommand(command: string): void;
/** True when the event target is a text field that owns clipboard / undo keys. */
export declare function isEditableTarget(target: EventTarget | null): boolean;
/**
 * Match a menu shortcut label (e.g. `Ctrl+Shift+E`, `F11`) against a keydown.
 * @param event - browser keydown.
 * @param shortcut - label shown beside the menu item.
 * @returns whether the event matches the shortcut.
 */
export declare function eventMatchesShortcut(event: KeyboardEvent, shortcut: string): boolean;
/**
 * Run the first enabled menu item whose shortcut matches this keydown.
 * Native edit shortcuts are skipped while a text field is focused.
 * @param event - browser keydown.
 * @param menus - current File / Edit / View definitions.
 * @returns true when a menu action ran (caller should preventDefault).
 */
export declare function tryRunMenuShortcut(event: KeyboardEvent, menus: readonly {
    items: readonly MenuItem[];
}[]): boolean;
/**
 * 在下拉菜单内处理方向键、Home、End 与 Escape。
 * @param event 菜单中的键盘事件。
 * @param close 关闭菜单并将焦点交回菜单按钮。
 */
export declare function navigateDropdownKey(event: ReactKeyboardEvent<HTMLElement>, close: () => void): void;
/** Inputs required to assemble the three menus. */
export type BuildMenusInput = {
    t: DesktopTitleBarT;
    win: DesktopAppWindow | undefined;
    backEnabled: boolean;
    forwardEnabled: boolean;
    sessionIdsLength: number;
    toggleSidebar: () => void;
    toggleDetails: () => void;
    toggleBottom: () => void;
    openBottom: () => void;
    walkHistory: (direction: 'back' | 'forward') => void;
    neighborSession: (delta: -1 | 1) => void;
};
/**
 * Build File / Edit / View menu definitions for the title bar.
 * @param input - actions and locale translator.
 * @returns ordered menu groups.
 */
export declare function buildMenus(input: BuildMenusInput): {
    id: MenuId;
    label: string;
    items: MenuItem[];
}[];
//# sourceMappingURL=menus.d.ts.map