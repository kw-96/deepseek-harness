/**
 * Thin wrapper over `window.__TAURI__.window` so the desktop title bar does
 * not take an npm dependency on `@tauri-apps/api`.
 */
/** Subset of the Tauri window face used by the title bar. */
export interface DesktopAppWindow {
    minimize(): Promise<void>;
    toggleMaximize(): Promise<void>;
    close(): Promise<void>;
    setFullscreen(fullscreen: boolean): Promise<void>;
    isFullscreen(): Promise<boolean>;
    startDragging(): Promise<void>;
}
/**
 * Resolve the current Tauri window, or undefined outside the desktop shell.
 * @returns the current window face when Tauri globals are present.
 */
export declare function getDesktopWindow(): DesktopAppWindow | undefined;
//# sourceMappingURL=window.d.ts.map