/**
 * Session visit stack for the desktop title-bar back/forward controls.
 * Push on ordinary selection changes; walk the stack for explicit navigation.
 */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** Mutable history cursor over visited session ids. */
export type SessionHistory = {
    stack: SessionId[];
    index: number;
};
/** Create an empty session history. */
export declare function createSessionHistory(): SessionHistory;
/**
 * Record a session selection that is not itself a history walk.
 * @param history - mutable history.
 * @param id - newly selected session, or undefined when clearing.
 */
export declare function pushSessionVisit(history: SessionHistory, id: SessionId | undefined): void;
/** Whether back navigation has a prior entry. */
export declare function canGoBack(history: SessionHistory): boolean;
/** Whether forward navigation has a later entry. */
export declare function canGoForward(history: SessionHistory): boolean;
/**
 * Move one step backward in the visit stack.
 * @param history - mutable history.
 * @returns the session to open, when available.
 */
export declare function goBack(history: SessionHistory): SessionId | undefined;
/**
 * Move one step forward in the visit stack.
 * @param history - mutable history.
 * @returns the session to open, when available.
 */
export declare function goForward(history: SessionHistory): SessionId | undefined;
//# sourceMappingURL=session-history.d.ts.map