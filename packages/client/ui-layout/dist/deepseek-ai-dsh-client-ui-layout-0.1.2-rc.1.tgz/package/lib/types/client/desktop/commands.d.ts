/**
 * Cross-plugin desktop title-bar commands delivered as window CustomEvents.
 * Feature packages listen without taking a ui-layout runtime dependency.
 */
/** Window event name for desktop chrome commands. */
export declare const DESKTOP_COMMAND_EVENT = "dsh-desktop:command";
/** Commands the title bar may dispatch to other plugins. */
export type DesktopCommand = 'new-session' | 'open-settings' | 'add-workspace';
/** Detail payload for {@link DESKTOP_COMMAND_EVENT}. */
export type DesktopCommandDetail = {
    readonly command: DesktopCommand;
};
/**
 * Dispatch a desktop chrome command to listening plugins.
 * @param command - command discriminator.
 */
export declare function dispatchDesktopCommand(command: DesktopCommand): void;
/**
 * Subscribe to desktop chrome commands.
 * @param handler - receives the command discriminator.
 * @returns disposer.
 */
export declare function onDesktopCommand(handler: (command: DesktopCommand) => void): () => void;
//# sourceMappingURL=commands.d.ts.map