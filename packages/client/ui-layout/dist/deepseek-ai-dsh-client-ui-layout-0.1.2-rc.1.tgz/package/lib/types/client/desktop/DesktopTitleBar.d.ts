import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
import { type DesktopTitleBarT } from './menus.ts';
export type { DesktopTitleBarT };
/** Props for the desktop title bar. */
export type DesktopTitleBarProps = {
    t: DesktopTitleBarT;
    sidebarCollapsed: boolean;
    toggleSidebar: () => void;
    toggleDetails: () => void;
    toggleBottom: () => void;
    openBottom: () => void;
    openSession: (id: SessionId) => void;
    useSessions: <S>(sel: (s: SessionListState) => S) => S;
};
/**
 * Render the Codex-style desktop title bar.
 * @param props - layout actions, session hooks, and locale translator.
 * @returns the title bar element tree.
 */
export declare function DesktopTitleBar(props: DesktopTitleBarProps): import("react").JSX.Element;
//# sourceMappingURL=DesktopTitleBar.d.ts.map