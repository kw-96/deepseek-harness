/** Host service for persistent DeepSeek Harness plugin enablement. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
import type { McpMutationReceipt, McpServerInput, McpServersSnapshot, MutationReceipt, PluginCategory, PluginManagerSnapshot, SkillMutationReceipt, SkillsSnapshot } from './types.js';
export type * from './types.js';
/** Plugin manager configuration. */
export interface Config {
    /** Additional local Loader entry ids that cannot be changed from the UI. */
    protectedEntries?: readonly string[];
    /** Maximum time to wait for the existing profile HMR watcher. */
    settleTimeoutMs?: number;
}
/** Loader-validated configuration for profile-owned manager settings. */
export declare const Config: z.ZodObject<{
    protectedEntries: z.ZodDefault<z.ZodArray<z.ZodString>>;
    settleTimeoutMs: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
/** Persistent plugin management Remote for a trusted Harness Web client. */
export declare class PluginManager extends TypertRemoteService {
    static inject: string[];
    private readonly protectedIds;
    private readonly location;
    private readonly settleTimeoutMs;
    private mutationTail;
    constructor(ctx: Context, config?: Config);
    /** Read the current Loader without maintaining a second lifecycle cache. */
    list(): PluginManagerSnapshot;
    /** Persist and apply one entry's desired enablement. */
    setEnabled(entryId: string, enabled: boolean): Promise<MutationReceipt>;
    /** Persist and apply all mutable entries from one automatic category. */
    setCategoryEnabled(category: PluginCategory, enabled: boolean): Promise<MutationReceipt>;
    /** Persist and apply all mutable entries from one package-like group. */
    setPackageEnabled(packageName: string, enabled: boolean): Promise<MutationReceipt>;
    /** List every mcp-client patch row (managed and user-authored). */
    listMcpServersRemote(): Promise<McpServersSnapshot>;
    /** Create or update one manager-owned MCP server row and settle it live. */
    saveMcpServerRemote(input: McpServerInput, enabled: boolean): Promise<McpMutationReceipt>;
    /** Remove one manager-owned MCP server row. */
    removeMcpServerRemote(serverName: string): Promise<McpMutationReceipt>;
    /** Enable or disable one manager-owned MCP server row and settle it live. */
    setMcpServerEnabledRemote(serverName: string, enabled: boolean): Promise<McpMutationReceipt>;
    /** List every skill under the user skill root. */
    listSkillsRemote(): Promise<SkillsSnapshot>;
    /** Enable or disable model invocation for one skill. */
    setSkillModelInvocationRemote(skillName: string, enabled: boolean): Promise<SkillMutationReceipt>;
    private project;
    private change;
    private isManagerAncestor;
    private hasAmbiguousConfigId;
    private waitFor;
    /** 等待 mcp-<serverName> 条目在 Loader 中达到目标启停状态（热应用或判定需重启）。 */
    private waitForMcp;
    private serialize;
}
export default PluginManager;
