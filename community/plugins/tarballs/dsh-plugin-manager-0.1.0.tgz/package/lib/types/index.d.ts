/** Host service for persistent DeepSeek Harness plugin enablement. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
import type { MutationReceipt, PluginCategory, PluginManagerSnapshot } from './types.js';
export type * from './types.js';
/** Plugin manager configuration. */
export interface Config {
    /** Additional local Loader entry ids that cannot be changed from the UI. */
    protectedEntries?: readonly string[];
    /** Maximum time to wait for the existing profile HMR watcher. */
    settleTimeoutMs?: number;
}
/** Loader-validated configuration for profile-owned manager settings. */
export declare const Config: z.ZodObject<{
    protectedEntries: z.ZodDefault<z.ZodArray<z.ZodString>>;
    settleTimeoutMs: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
/** Persistent plugin management Remote for a trusted Harness Web client. */
export declare class PluginManager extends TypertRemoteService {
    static inject: string[];
    private readonly protectedIds;
    private readonly location;
    private readonly settleTimeoutMs;
    private mutationTail;
    constructor(ctx: Context, config?: Config);
    /** Read the current Loader without maintaining a second lifecycle cache. */
    list(): PluginManagerSnapshot;
    /** Persist and apply one entry's desired enablement. */
    setEnabled(entryId: string, enabled: boolean): Promise<MutationReceipt>;
    /** Persist and apply all mutable entries from one automatic category. */
    setCategoryEnabled(category: PluginCategory, enabled: boolean): Promise<MutationReceipt>;
    /** Persist and apply all mutable entries from one package-like group. */
    setPackageEnabled(packageName: string, enabled: boolean): Promise<MutationReceipt>;
    private project;
    private change;
    private isManagerAncestor;
    private hasAmbiguousConfigId;
    private waitFor;
    private serialize;
}
export default PluginManager;
