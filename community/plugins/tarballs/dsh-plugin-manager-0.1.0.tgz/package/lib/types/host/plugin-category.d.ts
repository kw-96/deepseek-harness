import type { PluginCategory } from '../types.js';
export declare const OFFICIAL_CATEGORY = "official";
export declare const THIRD_PARTY_CATEGORY = "third-party";
export declare const AUTOMATIC_CATEGORIES: readonly ["official", "third-party"];
/** Classify every package root against the checked-in official registry. */
export declare function pluginCategory(packageName: string): PluginCategory;
/**
 * Read a third-party package's `dsh.pluginManager.group` declaration when it
 * matches the group-id shape. Official groups come from the checked-in index,
 * so a publisher declaration here only affects third-party entries.
 */
export declare function declaredGroup(packageName: string, profileDirectory: string): string | null;
/**
 * Read a third-party package's `description` field for the UI caption.
 * Official descriptions come from the checked-in index, so this lookup only
 * runs for third-party roots and is a best-effort hint that never affects
 * enablement.
 */
export declare function packageDescription(packageName: string, profileDirectory: string): string | null;
