/**
 * MCP 服务行的 profile patch 持久化：只维护带本管家标记的
 * `@deepseek-ai/dsh-mcp-client` 行，用户手写行只读展示、绝不改写。
 * @module dsh-plugin-manager/mcp-servers
 */
import { type ProfileLocation } from './profile-patches.js';
import type { McpMutationReceipt, McpServerInput, McpServersSnapshot } from '../types.js';
/** 由服务名推导稳定 patch 行 id。 */
export declare function mcpConfigId(serverName: string): string;
/** 列出 profile 中全部 mcp-client 行（含用户手写行）。 */
export declare function listMcpServers(location: ProfileLocation): Promise<McpServersSnapshot>;
/** 新增或更新一条本管家维护的 MCP 服务行。 */
export declare function saveMcpServer(location: ProfileLocation, input: McpServerInput, enabled: boolean): Promise<McpMutationReceipt>;
/** 删除一条本管家维护的 MCP 服务行。 */
export declare function removeMcpServer(location: ProfileLocation, serverName: string): Promise<McpMutationReceipt>;
/** 启停一条本管家维护的 MCP 服务行。 */
export declare function setMcpServerEnabled(location: ProfileLocation, serverName: string, enabled: boolean): Promise<McpMutationReceipt>;
