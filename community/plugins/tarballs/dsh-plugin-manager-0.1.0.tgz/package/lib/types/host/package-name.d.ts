/** Derive the package-like root used to group module subpath entries. */
export declare function packageRoot(moduleName: string): string;
