import { type Document } from 'yaml';
export declare const OWNER_MARKER = "Managed by dsh-plugin-manager. Remove this row to return control to higher-level configuration.";
/** Profile patch location inferred from the running Loader tree. */
export interface ProfileLocation {
    readonly directory: string;
    readonly filename: string;
    readonly profileName: string;
}
/** Resolve and validate the running profile directory from a Loader file URL. */
export declare function profileLocation(baseUrl: string): ProfileLocation;
export declare function readDocument(filename: string): Promise<Document.Parsed>;
/** Store one explicit desired enablement without changing user-authored patches. */
export declare function writeDesiredState(location: ProfileLocation, configId: string, moduleName: string, enabled: boolean): Promise<void>;
export declare function atomicWrite(filename: string, content: string): Promise<void>;
