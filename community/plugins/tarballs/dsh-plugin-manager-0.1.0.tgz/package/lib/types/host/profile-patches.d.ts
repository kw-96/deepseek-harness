/** Profile patch location inferred from the running Loader tree. */
export interface ProfileLocation {
    readonly directory: string;
    readonly filename: string;
    readonly profileName: string;
}
/** Resolve and validate the running profile directory from a Loader file URL. */
export declare function profileLocation(baseUrl: string): ProfileLocation;
/** Store one explicit desired enablement without changing user-authored patches. */
export declare function writeDesiredState(location: ProfileLocation, configId: string, moduleName: string, enabled: boolean): Promise<void>;
