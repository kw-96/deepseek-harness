/**
 * Skills 管理：扫描用户技能根（$DSH_HOME/skills）列出技能，并通过编辑
 * SKILL.md 前言的 disable-model-invocation 标记启停模型调用。编辑只改
 * 标记行，其余前言与正文保持原字节。
 * @module dsh-plugin-manager/skills
 */
import type { SkillMutationReceipt, SkillsSnapshot } from '../types.js';
/** 用户技能根：与 skill-filesystem 的 user-dsh 根一致。 */
export declare function userSkillsRoot(): string;
/** 列出用户技能根中的全部技能。 */
export declare function listSkills(): Promise<SkillsSnapshot>;
/**
 * 启停一个技能的模型调用：把前言标记设为对应值（缺行则插入），
 * 其余前言键与正文保持不变。
 */
export declare function setSkillModelInvocation(skillName: string, enabled: boolean): Promise<SkillMutationReceipt>;
