/**
 * 官方插件（dsh-e 到 dsh-l）的简体中文说明。
 * 插件管理页在 zh-CN 语言下优先显示这里的中文说明，缺失时回退英文原文。
 */
export declare const OFFICIAL_E_L: {
    readonly '@deepseek-ai/dsh-e2b': "DeepSeek Harness 提供方适配器共享的 E2B 沙箱生命周期";
    readonly '@deepseek-ai/dsh-experimental-agent-team': "隐式根 Agent 团队名册、持久同伴邮箱与共享任务 DAG";
    readonly '@deepseek-ai/dsh-experimental-agent-team-profile': "在 dsh-base 之上启用 Agent 团队的私有配置组合层";
    readonly '@deepseek-ai/dsh-experimental-agent-team-web-profile': "Agent 团队 Remote 与 UI 插件的私有 Web 配置层";
    readonly '@deepseek-ai/dsh-experimental-client-ui-agent-team': "Web Agent 团队名册、任务看板与队友导航";
    readonly '@deepseek-ai/dsh-experimental-inspector': "供 Host 调试与 Client Runtime 检查的实验性跨域 CDP 枢纽";
    readonly '@deepseek-ai/dsh-experimental-tool-agent-team': "基于 ctx.agentTeams 的受限模型 Agent 团队工具";
    readonly '@deepseek-ai/dsh-experimental-webworker-packer': "浏览器运行时基础 VFS 镜像与有序数据叠加归档的构建期打包器";
    readonly '@deepseek-ai/dsh-experimental-webworker-runtime': "仅浏览器 Harness 运行时：内存 VFS、模块转换与加载器、postMessage 隧道与专用 Web Worker 装配，附让宿主树原样运行的 Node 兼容层";
    readonly '@deepseek-ai/dsh-file-reference': "文件引用发现契约与共享 @file 语法";
    readonly '@deepseek-ai/dsh-file-reference-local': "带边界模糊索引的本地文件系统 ctx.fileReferences 提供方";
    readonly '@deepseek-ai/dsh-fs': "DeepSeek Harness 抽象文件系统能力接口（ctx.fs）：词汇类型、FileSystem 服务（文本 IO 与可选版本守卫原子变更）与 fs/* 策略事件词汇";
    readonly '@deepseek-ai/dsh-fs-e2b': "DeepSeek Harness 的 E2B 文件系统实现";
    readonly '@deepseek-ai/dsh-fs-local': "DeepSeek Harness 文件系统接口（ctx.fs）的本地文件系统实现";
    readonly '@deepseek-ai/dsh-fs-observation-policy': "DeepSeek Harness 文件上下文策略插件：通过 fs/* 事件门在 ctx.fs 提供方接口上附加观察状态、编辑前读取与版本守卫写/编辑（无服务 API）";
    readonly '@deepseek-ai/dsh-fs-sandbox': "DeepSeek Harness 文件系统接口的沙箱实现：按每次调用的沙箱模式围栏写/编辑（只读拒绝变更，工作区写入限制在工作区与临时根），读取放行";
    readonly '@deepseek-ai/dsh-goal': "DeepSeek Harness 的事件溯源同会话目标状态与生命周期服务";
    readonly '@deepseek-ai/dsh-goal-round-driver': "竞态防护的同会话目标轮次驱动器";
    readonly '@deepseek-ai/dsh-headless': "dsh 一次性组合层：基于 dsh-base 的直接核心 Agent/Session 运行器，无 Host、HTTP 或浏览器层";
    readonly '@deepseek-ai/dsh-home-paths': "DeepSeek Harness 的共享文件系统路径助手";
    readonly '@deepseek-ai/dsh-hook-protocol': "共享 Claude Code / Codex 钩子线协议：匹配引擎、stdin/退出码/stdout 编解码、多钩子合并与 hook/* 会话事件";
    readonly '@deepseek-ai/dsh-hooks-claude-code': "桥接插件：在 DeepSeek Harness 拦截接口上运行 Claude Code hooks.json / 设置钩子配置";
    readonly '@deepseek-ai/dsh-hooks-codex': "桥接插件：在 DeepSeek Harness 拦截接口上运行 Codex hooks.json 钩子配置";
    readonly '@deepseek-ai/dsh-host-apiproxy': "DeepSeek Harness 宿主 API 代理";
    readonly '@deepseek-ai/dsh-host-directory-picker': "DeepSeek Harness Web GUI 宿主的抽象工作区目录选择接口（ctx.directoryPicker）";
    readonly '@deepseek-ai/dsh-host-directory-picker-auto': "目录选择接口的自适应选择器：启动时判断宿主环境，为 Web GUI 宿主挂载原生或浏览后端";
    readonly '@deepseek-ai/dsh-host-directory-picker-browse': "目录选择接口的应用内浏览后端（基于宿主文件系统的列目录/创建原语）";
    readonly '@deepseek-ai/dsh-host-directory-picker-native': "DeepSeek Harness Web GUI 宿主的原生系统选择器后端";
    readonly '@deepseek-ai/dsh-host-frontend-static': "Web 外壳的 SPA dist 服务器：拥有 webserver 回退席位，提供显式索引条目与静态资源（拒绝路径穿越并处理 404）";
    readonly '@deepseek-ai/dsh-host-plugin-inventory': "当前 Cordis Loader 插件状态的只读 Remote 投影";
    readonly '@deepseek-ai/dsh-host-webserver': "Web 路由注册插件：HTTP 与升级路由、索引转换接管与静态 dist 回退；不了解 Harness 概念";
    readonly '@deepseek-ai/dsh-invariants': "包拥有的 DeepSeek Harness 运行时不变式注册服务";
    readonly '@deepseek-ai/dsh-jobs': "DeepSeek Harness 的后台任务注册表（ctx.jobs）：共享 id、所有者隔离、轮询、取消与完成监听，面向长时间运行的工具工作";
    readonly '@deepseek-ai/dsh-jobs-local': "DeepSeek Harness 后台任务注册表接口的进程内实现";
    readonly '@deepseek-ai/dsh-launch-environment': "记录每个值由哪一层提供的不可变 DeepSeek Harness 启动环境";
    readonly '@deepseek-ai/dsh-llm': "DeepSeek Harness 的提供方无关 LLM 服务接口";
    readonly '@deepseek-ai/dsh-llm-deepseek': "DeepSeek Harness LLM 接口的 DeepSeek chat-completions 适配器";
    readonly '@deepseek-ai/dsh-llm-mock-server': "面向 LLM 恢复测试的可脚本化 OpenAI 兼容 HTTP/SSE 故障服务器";
    readonly '@deepseek-ai/dsh-llm-pi-ai': "DeepSeek Harness LLM 接口的 pi-ai 支持适配器（dsh-llm-deepseek 的设计验证孪生）";
    readonly '@deepseek-ai/dsh-llm-replay': "重放 LLM 插件：用录制会话 JSONL 重建的模型分块短路 llm/stream（无密钥快照测试）";
    readonly '@deepseek-ai/dsh-llm-retry': "DeepSeek Harness 按提供方路由的 LLM 请求重试策略";
    readonly '@deepseek-ai/dsh-loader-smoke': "面向无密钥真实 Loader 示例冒烟测试的共享子进程与直接 Agent 测试装置";
    readonly '@deepseek-ai/dsh-lsp': "DeepSeek Harness 的抽象 LSP 能力接口（ctx.lsp）：按品牌 id 与扩展映射键控的语言服务器提供方注册表、与顺序无关的按查询选择、规范化定义/引用/实现/悬停请求与结果、LspError 分类";
    readonly '@deepseek-ai/dsh-lsp-stdio': "DeepSeek Harness LSP 能力接口（ctx.lsp）的通用 stdio 语言服务器提供方：启动已配置服务器、翻译 JSON-RPC、在宿主文件系统命名空间提供临时打开的 goToDefinition/findReferences/goToImplementation/hover 查询";
};
