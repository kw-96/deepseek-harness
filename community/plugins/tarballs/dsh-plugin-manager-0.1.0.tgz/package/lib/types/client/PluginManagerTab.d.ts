import { type ReactNode } from 'react';
import type { MutationReceipt, PluginManagerSnapshot, PluginCategory } from '../types.js';
import { type LocaleKey } from './locales.js';
export interface PluginManagerTabApi {
    readonly list: () => Promise<PluginManagerSnapshot>;
    readonly setEnabled: (entryId: string, enabled: boolean) => Promise<MutationReceipt>;
    readonly setCategoryEnabled: (category: PluginCategory, enabled: boolean) => Promise<MutationReceipt>;
    readonly setPackageEnabled: (packageName: string, enabled: boolean) => Promise<MutationReceipt>;
}
export interface PluginManagerTabProps extends PluginManagerTabApi {
    readonly t: (key: LocaleKey) => string;
    readonly locale: string;
}
/** Searchable plugin management view grouped by source category, then by functional group. */
export declare function PluginManagerTab({ list, setEnabled, setCategoryEnabled, t, locale }: PluginManagerTabProps): ReactNode;
