/**
 * 官方插件（dsh-t 到 dsh-w）的简体中文说明。
 * 插件管理页在 zh-CN 语言下优先显示这里的中文说明，缺失时回退英文原文。
 */
export declare const OFFICIAL_T_W: {
    readonly '@deepseek-ai/dsh-system-prompt': "DeepSeek Harness 的系统提示词组装注册表";
    readonly '@deepseek-ai/dsh-terminal': "DeepSeek Harness 的持久 PTY 会话接口：所有者作用域 id、后端注册表、交互式发送、读取、信号与等待清理";
    readonly '@deepseek-ai/dsh-terminal-bash': "基于 DeepSeek Harness 子进程终端原语的持久终端 PTY 后端";
    readonly '@deepseek-ai/dsh-time-context': "可选持久每步上下文：当前时间与已用时间";
    readonly '@deepseek-ai/dsh-timeout': "零依赖超时/截止原语：clampTimeout、deadline、timeoutOf、TimeoutReason（仅计时与分类，不终止）";
    readonly '@deepseek-ai/dsh-tmux-context': "可选持久每步上下文：本 Agent 的 tmux 窗格与窗口位置";
    readonly '@deepseek-ai/dsh-token-meter': "DeepSeek Harness 的可回放感知令牌测量服务（ctx.tokenMeter）";
    readonly '@deepseek-ai/dsh-tool-ask-user': "基于 ctx.userQuestions 接口的模型 ask_user_question 工具";
    readonly '@deepseek-ai/dsh-tool-bash': "模型 bash 工具：带可选通用后台任务与沙箱升级支持";
    readonly '@deepseek-ai/dsh-tool-bash-persistent': "由 Harness PTY 服务支持的模型所有者作用域持久 Bash 工具";
    readonly '@deepseek-ai/dsh-tool-call-timeout-policy': "工具调用超时策略：tools/execute 包装器，在 exec.signal 上武装每工具截止时间，获胜时返回 TOOL_TIMEOUT";
    readonly '@deepseek-ai/dsh-tool-cordis': "自引用 cordis 工具集：检查实时运行时、挂载与卸载模型编写的插件";
    readonly '@deepseek-ai/dsh-tool-fs': "基于 DeepSeek Harness 文件系统接口（ctx.fs）的模型文件工具（读、写、编辑）";
    readonly '@deepseek-ai/dsh-tool-fs-search': "由内置 ripgrep 二进制（@vscode/ripgrep）支持的模型文件发现工具（glob、grep）";
    readonly '@deepseek-ai/dsh-tool-goal': "带执行时权限检查的模型同会话目标工具";
    readonly '@deepseek-ai/dsh-tool-jobs': "基于 ctx.jobs 注册表的模型后台任务控制工具（job_output、job_list、job_kill）";
    readonly '@deepseek-ai/dsh-tool-lsp': "基于 DeepSeek Harness LSP 能力接口（ctx.lsp）的模型 lsp 工具：一个只读工具，支持 goToDefinition/findReferences/goToImplementation/hover 操作、1 基 UTF-16 光标坐标、有界位置渲染与悬停规范化";
    readonly '@deepseek-ai/dsh-tool-pwsh': "基于 bash 执行接口的模型 pwsh 工具";
    readonly '@deepseek-ai/dsh-tool-pwsh-persistent': "由 Harness PTY 服务支持的模型所有者作用域持久 PowerShell 工具";
    readonly '@deepseek-ai/dsh-tool-ralph': "基于工作流与 Subagent 接口的模型全新 Agent Ralph 循环";
    readonly '@deepseek-ai/dsh-tool-session-query': "工作区授权的模型会话历史搜索、追踪与事件读取工具";
    readonly '@deepseek-ai/dsh-tool-skill': "DeepSeek Harness 的模型技能加载工具";
    readonly '@deepseek-ai/dsh-tool-str-replace-editor': "基于 Harness 文件系统服务的模型查看、创建、字面替换与行插入工具";
    readonly '@deepseek-ai/dsh-tool-subagent': "基于 ctx.subagents 接口的模型 Subagent 委托工具";
    readonly '@deepseek-ai/dsh-tool-subagent-control': "基于 ctx.subagents 续接的全局命名 send_message、interrupt_agent 与 list_agents 工具";
    readonly '@deepseek-ai/dsh-tool-subagent-report': "Subagent 报告工具";
    readonly '@deepseek-ai/dsh-tool-terminal': "六个模型持久 PTY 工具：所有者隔离与通用后台任务集成";
    readonly '@deepseek-ai/dsh-tool-todo': "基于 DeepSeek Harness 事件溯源会话日志的模型 todo_write 工具";
    readonly '@deepseek-ai/dsh-tool-web': "基于 DeepSeek Harness Web 能力接口（ctx.web）的模型 Web 工具（web_search、web_fetch）";
    readonly '@deepseek-ai/dsh-tool-workflow': "模型工作流工具：在 ctx.workflowEngine 上运行 JavaScript 编排脚本";
    readonly '@deepseek-ai/dsh-tools': "DeepSeek Harness 的工具注册表与执行管线";
    readonly '@deepseek-ai/dsh-typert-generator': "TypeScript 项目分析器与模型驱动 Typert 工件生成器";
    readonly '@deepseek-ai/dsh-typert-loader': "生成的 Typert 包贡献的加载器集成";
    readonly '@deepseek-ai/dsh-typert-protocol': "与编译器无关的 Remote 元数据与 Typert 提供方协议";
    readonly '@deepseek-ai/dsh-typert-registry': "生成的包反射与 Zod 模式的运行时注册表";
    readonly '@deepseek-ai/dsh-user-approval': "DeepSeek Harness 的用户审批接口（ctx.approval）：一次性权限决策分发到组合的回答者（经 approval/request 瀑布），默认失败即拒绝";
    readonly '@deepseek-ai/dsh-user-questions': "DeepSeek Harness 的抽象用户提问接口（ctx.userQuestions）：Agent 运行期间向人类提问";
    readonly '@deepseek-ai/dsh-util-crypto': "零依赖浏览器安全 UUID 与字节编码助手";
    readonly '@deepseek-ai/dsh-util-workspace-path': "浏览器安全的 Workspace 路径与显示助手";
    readonly '@deepseek-ai/dsh-web': "DeepSeek Harness 的抽象 Web 访问能力接口（ctx.web）：搜索/抓取提供方注册表、与注册顺序无关的选择、请求/结果词汇与 WebError 分类";
    readonly '@deepseek-ai/dsh-web-app': "dsh 浏览器界面组合层：dsh-base 之上的 Web 补丁层加运行时胶水插件（前端 dist 服务、Web 界面提示词、bash 运行时变量、URL 行）";
    readonly '@deepseek-ai/dsh-web-fetch-http': "DeepSeek Harness Web 能力接口（ctx.web）的匿名公共 HTTP(S) 抓取提供方";
    readonly '@deepseek-ai/dsh-web-frontend': "Web 应用入口：基于 @deepseek-ai/dsh-client-web 外壳库的 vite 构建";
    readonly '@deepseek-ai/dsh-web-search-deepseek': "DeepSeek Harness Web 能力接口（ctx.web）的 DeepSeek 搜索提供方（经 Anthropic 兼容 API 的原生 web_search）";
    readonly '@deepseek-ai/dsh-web-search-exa': "DeepSeek Harness Web 能力接口（ctx.web）的 Exa 搜索提供方";
    readonly '@deepseek-ai/dsh-web-search-perplexity': "DeepSeek Harness Web 能力接口（ctx.web）的 Perplexity 搜索提供方";
    readonly '@deepseek-ai/dsh-webhook': "一发即弃 Webhook 规则运行时：创建 Workspace 支持的 DeepSeek Harness 会话";
    readonly '@deepseek-ai/dsh-webhook-github': "DeepSeek Harness Webhook 运行时的签名 GitHub HTTP Webhook 适配器";
    readonly '@deepseek-ai/dsh-win32-process': "DeepSeek Harness Windows 沙箱的低层 Win32 进程、stdio 与 Job Object 原语";
    readonly '@deepseek-ai/dsh-workflow': "工作流能力接口：ctx.workflowEngine 服务、运行词汇与 workflow/* 事件";
    readonly '@deepseek-ai/dsh-workflow-worker-thread': "worker-thread 工作流引擎：在宿主事件循环外执行模型编写的编排脚本，把 agent() 调用桥回 ctx.subagents";
    readonly '@deepseek-ai/dsh-workspace': "DeepSeek Harness 的工作区实体注册表（ctx.workspaceRegistry）：基于域数据形式的持久工作区记录与会话挂接校验";
};
