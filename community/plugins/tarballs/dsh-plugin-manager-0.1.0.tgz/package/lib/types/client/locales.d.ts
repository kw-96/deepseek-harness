/** Simplified Chinese copy for the plugin manager. */
export declare const zh: {
    readonly localeId: "zh-CN";
    readonly tab: "已安装";
    readonly title: "插件管理";
    readonly profile: "当前配置";
    readonly search: "搜索插件或条目";
    readonly refresh: "刷新插件状态";
    readonly loading: "正在读取插件...";
    readonly error: "暂时无法读取插件。";
    readonly retry: "重试";
    readonly empty: "暂无可显示的插件。";
    readonly emptySearch: "没有匹配的插件。";
    readonly enabledCount: "已启用";
    readonly enablePackage: "启用整个包";
    readonly disablePackage: "停用整个包";
    readonly enableEntry: "启用插件";
    readonly disableEntry: "停用插件";
    readonly enableCategory: "启用组内可修改插件";
    readonly disableCategory: "停用组内可修改插件";
    readonly protected: "受保护";
    readonly pending: "等待依赖";
    readonly loadingPhase: "加载中";
    readonly active: "运行中";
    readonly failed: "加载失败";
    readonly unloading: "正在停用";
    readonly stopped: "已停用";
    readonly operationFailed: "操作未完全完成";
    readonly restartRequired: "状态已保存，重启当前配置后生效";
    readonly runtimeSwitch: "尝试即时切换";
    readonly categoryOfficial: "官方";
    readonly categoryThirdParty: "第三方";
    readonly entriesCount: "个插件";
};
export type LocaleKey = keyof typeof zh;
/** English copy checked against the Chinese source keys. */
export declare const en: Record<LocaleKey, string>;
/** Bilingual functional-group labels keyed by group id. Unknown ids render as-is. */
export declare const GROUP_LABELS: Readonly<Record<string, {
    readonly zh: string;
    readonly en: string;
}>>;
