/** 全部插件包名到简体中文说明的映射。 */
export declare const PACKAGE_DESCRIPTIONS: Readonly<Record<string, string>>;
/**
 * 取插件包的简体中文说明；没有映射时返回 undefined。
 * @param packageName npm 包名
 * @returns 中文说明或 undefined
 */
export declare function packageDescriptionZh(packageName: string): string | undefined;
