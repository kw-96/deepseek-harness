/** Strict Typert Remote contribution shared by the Host registry and Web client. */
import type { RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
import type { McpMutationReceipt, McpServerInput, McpServersSnapshot, MutationReceipt, PluginCategory, PluginManagerSnapshot, SkillMutationReceipt, SkillsSnapshot } from './types.js';
export declare const TYPERT_REMOTE: TypertRemoteContribution;
/** Host Typert artifact loaded from the package's `./typert` export. */
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: readonly [{
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }];
    model: {
        services: never[];
        events: never[];
        objects: never[];
    };
};
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteMap {
        'pluginManager/list': () => Promise<RemoteResult<PluginManagerSnapshot>>;
        'pluginManager/setEnabled': (entryId: string, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
        'pluginManager/setCategoryEnabled': (category: PluginCategory, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
        'pluginManager/setPackageEnabled': (packageName: string, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
        'pluginManager/listMcpServers': () => Promise<RemoteResult<McpServersSnapshot>>;
        'pluginManager/saveMcpServer': (input: McpServerInput, enabled: boolean) => Promise<RemoteResult<McpMutationReceipt>>;
        'pluginManager/removeMcpServer': (serverName: string) => Promise<RemoteResult<McpMutationReceipt>>;
        'pluginManager/setMcpServerEnabled': (serverName: string, enabled: boolean) => Promise<RemoteResult<McpMutationReceipt>>;
        'pluginManager/listSkills': () => Promise<RemoteResult<SkillsSnapshot>>;
        'pluginManager/setSkillModelInvocation': (skillName: string, enabled: boolean) => Promise<RemoteResult<SkillMutationReceipt>>;
    }
    interface TypertRemoteNamespaceMap {
        pluginManager: {
            list: () => Promise<RemoteResult<PluginManagerSnapshot>>;
            setEnabled: (entryId: string, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
            setCategoryEnabled: (category: PluginCategory, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
            setPackageEnabled: (packageName: string, enabled: boolean) => Promise<RemoteResult<MutationReceipt>>;
            listMcpServers: () => Promise<RemoteResult<McpServersSnapshot>>;
            saveMcpServer: (input: McpServerInput, enabled: boolean) => Promise<RemoteResult<McpMutationReceipt>>;
            removeMcpServer: (serverName: string) => Promise<RemoteResult<McpMutationReceipt>>;
            setMcpServerEnabled: (serverName: string, enabled: boolean) => Promise<RemoteResult<McpMutationReceipt>>;
            listSkills: () => Promise<RemoteResult<SkillsSnapshot>>;
            setSkillModelInvocation: (skillName: string, enabled: boolean) => Promise<RemoteResult<SkillMutationReceipt>>;
        };
    }
}
export default TYPERT_REMOTE;
