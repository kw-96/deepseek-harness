import type { CodexMcpManager } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface McpPanelProps {
    mcpManager: CodexMcpManager | undefined;
    t: TFn;
}
export declare function McpPanel({ mcpManager, t }: McpPanelProps): import("react").JSX.Element;
export {};
