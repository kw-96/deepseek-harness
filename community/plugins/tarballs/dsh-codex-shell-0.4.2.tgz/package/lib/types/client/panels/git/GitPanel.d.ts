import type { CodexApi } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface GitPanelProps {
    api: CodexApi;
    t: TFn;
    cwd?: string | undefined;
}
/**
 * Git 面板组件。
 * @param api codexShell API 面
 * @param t 文案函数
 * @param cwd 会话工作目录
 */
export declare function GitPanel({ api, t, cwd }: GitPanelProps): React.ReactNode;
export {};
