/** Git 面板的已暂存/更改分组列表：状态徽标 + 悬停显隐操作。 */
import type { TFn } from '../../faces.js';
import { type GitEntryLike } from './support.js';
interface GitFileListProps {
    staged: readonly GitEntryLike[];
    changes: readonly GitEntryLike[];
    clean: boolean;
    onShowDiff: (path: string, staged: boolean) => void;
    onStage: (path: string) => void;
    onUnstage: (path: string) => void;
    onDiscard: (path: string) => void;
    t: TFn;
}
/**
 * 文件分组列表组件。
 * @param props 分组条目与各行操作回调
 */
export declare function GitFileList(props: GitFileListProps): React.ReactNode;
export {};
