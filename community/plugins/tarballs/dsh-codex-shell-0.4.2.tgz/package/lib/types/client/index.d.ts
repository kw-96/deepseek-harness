/**
 * dsh-codex-shell 浏览器入口：挂载 codexShell Remote 并注册界面 ——
 * 遮蔽 sidebar.workspaces 的 Codex 式工作区浏览器、侧栏页脚的添加工作区
 * 入口、停靠进宿主 details 第三列的右侧工作台面板、以及会话头的面板
 * 开合按钮。面板开合通过 ctx.layout 与宿主第三列双向同步。
 *
 * 对宿主编译采用本地结构面（faces.ts）而非宿主编排类型线；运行时的
 * 槽位核心仍会对每个名字做加载期强校验。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * 挂载 Remote 并注册全部 codex-shell 界面。
 * @param ctx - 客户端根上下文。
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
