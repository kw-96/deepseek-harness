import type { CodexMarketplace, CodexPluginManager } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
export interface PluginsPanelProps {
    pluginManager: CodexPluginManager | undefined;
    marketplace: CodexMarketplace | undefined;
    t: TFn;
    locale: string;
}
export declare function PluginsPanel({ pluginManager, marketplace, t, locale }: PluginsPanelProps): import("react").JSX.Element;
