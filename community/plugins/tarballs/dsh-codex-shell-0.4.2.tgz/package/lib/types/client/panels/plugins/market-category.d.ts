/**
 * 市场插件的本地分类词表。与市场包（@ruihuahe/dsh-plugin-marketplace）的
 * 分类词表保持一致；跨包只共享远端数据（category 字符串），不共享代码。
 */
/** 分组展示顺序；未知分类排在 other 之后按字典序。 */
export declare const MARKET_CATEGORY_ORDER: readonly string[];
/** 分类 id → 本地化显示名。 */
export declare const MARKET_CATEGORY_LABELS: Readonly<Record<string, {
    'zh-CN': string;
    en: string;
}>>;
/** 按当前界面语言取分类显示名；未知分类回退为分类 id 本身。 */
export declare function marketCategoryLabel(category: string, locale: string): string;
/** 按分类分组条目，保持既定展示顺序；未知分类归入 other。 */
export declare function groupMarketEntries<T extends {
    category: string;
}>(entries: readonly T[]): readonly {
    category: string;
    entries: T[];
}[];
