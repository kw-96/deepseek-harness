/** 侧栏树体：Codex 式安静排布 —— 细字工作区标题、单行会话、未分组/
 * 归档区与搜索结果态。纯渲染层，状态与动作全部来自 WorkspaceBrowser。 */
import type { SessionMetaStore } from './session-meta.js';
import type { SearchResultLike, SessionId, SessionListStateLike, TFn, WorkspaceViewLike } from './faces.js';
/** 分组投影结果（浏览器 useMemo 产出）。 */
export interface GroupsModel {
    grouped: {
        workspace: WorkspaceViewLike;
        sessions: SessionId[];
    }[];
    ungrouped: SessionId[];
    archived: SessionId[];
}
export interface BrowserTreeProps {
    groups: GroupsModel;
    list: SessionListStateLike;
    collapsed: ReadonlySet<string>;
    collapsedSubagents: ReadonlySet<string>;
    searching: boolean;
    searchItems: readonly SearchResultLike[];
    searchLoading: boolean;
    renaming: string | null;
    renameDraft: string;
    onToggleGroup: (key: string) => void;
    onOpen: (sessionId: SessionId) => void;
    onWorkspaceMenu: (event: React.MouseEvent, workspaceId: string) => void;
    onSessionMenu: (event: React.MouseEvent, sessionId: SessionId) => void;
    onToggleSubagents: (key: string) => void;
    setRenameDraft: (value: string) => void;
    commitRename: (sessionId: SessionId) => void;
    commitWorkspaceRename: (workspaceId: string) => void;
    meta: SessionMetaStore;
    t: TFn;
}
/** 渲染树体：搜索态、空态与分组树。 */
export declare function BrowserTree(props: BrowserTreeProps): React.ReactNode;
