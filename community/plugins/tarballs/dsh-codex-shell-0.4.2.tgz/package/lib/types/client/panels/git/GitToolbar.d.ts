/** Git 面板顶部工具栏：分支切换、变更摘要、刷新/拉取/推送与更多菜单。 */
import type { TFn } from '../../faces.js';
interface GitToolbarProps {
    branch: string | null;
    ahead: number;
    behind: number;
    changed: number;
    branches: readonly string[];
    currentBranch: string | null;
    busy: boolean;
    onCheckout: (branch: string) => void;
    onFetch: () => void;
    onPull: () => void;
    onPush: () => void;
    onStageAll: () => void;
    onUnstageAll: () => void;
    onRefresh: () => void;
    t: TFn;
}
/**
 * Git 工具栏组件。
 * @param props 分支/计数/分支列表与各操作回调
 */
export declare function GitToolbar(props: GitToolbarProps): React.ReactNode;
export {};
