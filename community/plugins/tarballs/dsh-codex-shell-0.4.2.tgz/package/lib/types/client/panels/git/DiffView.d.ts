/** 内联差异视图：路径头 + 逐行着色的 unified diff 文本。 */
import type { TFn } from '../../faces.js';
interface DiffViewProps {
    path: string;
    text: string;
    onClose: () => void;
    t: TFn;
}
/**
 * 差异视图组件。
 * @param path 展示在头部的文件路径
 * @param text diff 原始文本
 * @param onClose 关闭回调
 * @param t 文案函数
 */
export declare function DiffView({ path, text, onClose, t }: DiffViewProps): React.ReactNode;
export {};
