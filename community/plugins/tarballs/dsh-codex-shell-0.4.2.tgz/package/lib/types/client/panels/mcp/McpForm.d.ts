import type { McpServerInputLike, McpServerLike } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface McpFormProps {
    t: TFn;
    /** null 表示新增；否则用现有行预填。 */
    initial: McpServerLike | null;
    busy: boolean;
    onCancel: () => void;
    onSave: (input: McpServerInputLike, enabled: boolean) => void;
}
export declare function McpForm({ t, initial, busy, onCancel, onSave }: McpFormProps): import("react").JSX.Element;
export {};
