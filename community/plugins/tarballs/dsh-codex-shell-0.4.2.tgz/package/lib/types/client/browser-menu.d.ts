/** 侧栏行操作菜单（工作区/会话）：… 按钮派发，固定定位弹出面板。 */
import type { SessionId, TFn } from './faces.js';
export interface BrowserMenuState {
    x: number;
    y: number;
    sessionId?: SessionId;
    workspaceId?: string;
    isWorkspace: boolean;
}
/** 菜单派发的全部动作（由浏览器组件闭包提供）。 */
export interface BrowserMenuActions {
    startSessionInWorkspace(workspaceId: string): void;
    renameWorkspace(workspaceId: string): void;
    deleteWorkspace(workspaceId: string): void;
    forkSession(sessionId: SessionId): void;
    renameSession(sessionId: SessionId): void;
    archiveSession(sessionId: SessionId): void;
    copyCwd(sessionId: SessionId): void;
    copyId(sessionId: SessionId): void;
    copyLink(sessionId: SessionId): void;
    openNewWindow(sessionId: SessionId): void;
}
export interface BrowserMenuProps {
    state: BrowserMenuState | null;
    onDismiss: () => void;
    actions: BrowserMenuActions;
    t: TFn;
}
/** 渲染工作区或会话的操作菜单；空状态返回 null。 */
export declare function BrowserMenu({ state, onDismiss, actions, t }: BrowserMenuProps): React.ReactNode;
