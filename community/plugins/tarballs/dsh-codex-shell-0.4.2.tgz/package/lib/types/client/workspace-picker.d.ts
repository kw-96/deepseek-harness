/** 添加工作区入口（sidebar.footer.action）：页脚按钮 + 居中弹窗。
 * 目录浏览基于 codexShell remote 的 fsList；原生 directoryFlow 槽声明
 * 始终由被遮蔽的原生浏览器持有，插件不能渲染它，故自带轻量选择流程。 */
import type { FsListResponse } from 'dsh-codex-shell/types';
import type { SelectorHook, SessionListStateLike, TFn, WorkspaceViewLike } from './faces.js';
export interface AddWorkspaceInjected {
    fsList: (path: string) => Promise<FsListResponse>;
    createWorkspace: (input: {
        path: string;
    }) => Promise<WorkspaceViewLike>;
}
export interface AddWorkspaceProps extends AddWorkspaceInjected {
    wide: boolean;
    useSessions: SelectorHook<SessionListStateLike>;
    t: TFn;
}
/** 页脚“添加工作区”按钮与居中选择弹窗。 */
export declare function AddWorkspaceAction({ wide, useSessions, fsList, createWorkspace, t }: AddWorkspaceProps): import("react").JSX.Element;
