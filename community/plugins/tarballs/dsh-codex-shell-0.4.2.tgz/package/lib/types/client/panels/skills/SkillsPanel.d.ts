import type { CodexSkillsManager } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface SkillsPanelProps {
    skillsManager: CodexSkillsManager | undefined;
    t: TFn;
}
export declare function SkillsPanel({ skillsManager, t }: SkillsPanelProps): import("react").JSX.Element;
export {};
