import type { InventoryEntryLike } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface InventoryViewProps {
    entries: readonly InventoryEntryLike[] | null;
    selectedId: string | null;
    onSelect: (id: string | null) => void;
    onToggle: (entry: InventoryEntryLike) => void;
    busyId: string | null;
    t: TFn;
}
export declare function InventoryView({ entries, selectedId, onSelect, onToggle, busyId, t }: InventoryViewProps): import("react").JSX.Element;
export {};
