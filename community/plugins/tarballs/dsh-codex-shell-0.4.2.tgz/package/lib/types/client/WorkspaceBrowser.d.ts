import type { SessionMetaStore } from './session-meta.js';
import type { SearchResultLike, SelectorHook, SessionId, SessionListStateLike, TFn, WorkspaceSnapshotLike } from './faces.js';
/** 注入共享面（镜像原生 WorkspaceBrowser 动作）。 */
export interface CodexBrowserInjected {
    startSession: (workspaceId?: string) => void;
    open: (sessionId: SessionId) => void;
    searchSessions: (query: string, signal: AbortSignal) => Promise<{
        items: readonly SearchResultLike[];
        hasMore: boolean;
    }>;
    searchResultLimit: number;
    renameSession: (sessionId: SessionId, title: string) => Promise<void>;
    forkSession: (sessionId: SessionId) => void;
    renameWorkspace: (workspaceId: string, title: string) => Promise<void>;
    deleteWorkspace: (workspaceId: string) => Promise<void>;
    insertWorkspaceBefore: (workspaceId: string, beforeWorkspaceId?: string) => Promise<void>;
    archiveSession: (sessionId: SessionId) => Promise<void>;
    insertSessionBefore: (workspaceId: string, sessionId: SessionId, beforeSessionId?: SessionId) => Promise<void>;
    meta: SessionMetaStore;
}
export interface CodexBrowserProps extends CodexBrowserInjected {
    wide: boolean;
    expandSidebar: () => void;
    useSessions: SelectorHook<SessionListStateLike>;
    useWorkspaces: SelectorHook<WorkspaceSnapshotLike>;
    t: TFn;
}
export declare function CodexBrowser(props: CodexBrowserProps): import("react").JSX.Element;
