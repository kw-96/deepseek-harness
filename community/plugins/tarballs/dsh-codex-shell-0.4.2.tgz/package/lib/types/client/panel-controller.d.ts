/** 右侧停靠面板的开合状态与激活标签页，浏览器本地持久化。 */
export type PanelKind = 'files' | 'git' | 'projects' | 'plugins' | 'mcp' | 'skills' | 'commands' | 'summary' | 'browser';
export interface PanelState {
    open: boolean;
    tab: PanelKind;
}
/**
 * 面板可见性与激活标签页控制器。首次激活默认展开（三栏工作区直接呈现），
 * 用户手动开合后的偏好写入 localStorage。纯状态类：宿主 details 列的实际
 * 开合由注入的 setColumnOpen 回调驱动，本类不感知布局服务。
 */
export declare class PanelController {
    private readonly listeners;
    private state;
    constructor();
    getSnapshot(): PanelState;
    subscribe(listener: () => void): () => void;
    /** 切换面板开合；指定标签页时若已在该页则关闭，否则打开并切页。 */
    toggle(tab?: PanelKind): PanelState;
    /** 打开面板（可切页）；返回最新状态供调用方同步布局列。 */
    open(tab?: PanelKind): PanelState;
    /** 关闭面板；返回最新状态供调用方同步布局列。 */
    close(): PanelState;
    private commit;
    dispose(): void;
}
/** 面板状态响应式镜像。 */
export declare function usePanelState(panel: PanelController): [PanelState, PanelController];
