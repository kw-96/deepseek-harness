import type { MarketEntryLike } from '../../RightPanel.js';
import type { TFn } from '../../faces.js';
interface MarketViewProps {
    entries: readonly MarketEntryLike[] | null;
    selectedId: string | null;
    onSelect: (id: string | null) => void;
    onInstall: (entry: MarketEntryLike) => void;
    busyId: string | null;
    t: TFn;
    locale: string;
}
export declare function MarketView({ entries, selectedId, onSelect, onInstall, busyId, t, locale }: MarketViewProps): import("react").JSX.Element;
export {};
