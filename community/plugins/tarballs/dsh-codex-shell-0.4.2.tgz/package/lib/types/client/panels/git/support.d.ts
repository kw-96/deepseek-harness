/** Git 面板的纯逻辑：状态字母推导、差异着色、路径筛选与相对时间。 */
import type { TFn } from '../../faces.js';
/** 与宿主 GitStatusResponse.entries 对应的本地条目面。 */
export interface GitEntryLike {
    path: string;
    origPath: string | null;
    xy: string;
}
/** 单字母文件状态码（VSCode 风格）。 */
export type StatusLetter = 'M' | 'A' | 'D' | 'R' | 'C' | 'U' | '?' | '!' | ' ';
/**
 * 从 porcelain-v2 XY 码推导单字母状态。
 * @param entry 状态条目
 * @param index true 取索引侧（暂存），false 取工作区侧（未暂存）
 * @returns 状态字母；无变化时为空格
 */
export declare function statusLetter(entry: GitEntryLike, index: boolean): StatusLetter;
/** 是否未跟踪（xy === '??'）。 */
export declare function isUntracked(entry: GitEntryLike): boolean;
/** 展示路径：重命名条目显示「原路径 → 新路径」。 */
export declare function displayPath(entry: GitEntryLike): string;
/** 路径筛选：大小写不敏感的包含匹配，空白查询放行全部。 */
export declare function matchesFilter(path: string, query: string): boolean;
export type DiffLineKind = 'add' | 'del' | 'meta' | 'hunk' | 'context';
export interface DiffLine {
    kind: DiffLineKind;
    text: string;
}
/**
 * 把 unified diff 文本拆成带类别的行，供着色渲染。
 * @param text diff 原始文本
 * @returns 逐行类别与内容
 */
export declare function parseDiff(text: string): readonly DiffLine[];
/**
 * git 日志日期到「刚刚 / n 分钟前 / n 小时前 / n 天前」的相对时间。
 * @param t 文案函数
 * @param iso `%ai` 格式的提交时间
 */
export declare function timeAgo(t: TFn, iso: string): string;
