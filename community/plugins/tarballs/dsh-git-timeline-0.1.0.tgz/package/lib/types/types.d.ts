/** gitPanel Remote 的线上数据形态与本地类型。 */
import { z } from 'zod';
/** 一条 porcelain-v2 状态条目（重命名带原路径）。 */
export declare const gitEntryValue: z.ZodReadonly<z.ZodObject<{
    path: z.ZodString;
    origPath: z.ZodNullable<z.ZodString>;
    xy: z.ZodString;
}, z.core.$strip>>;
/** 一条提交（图视图需要的父提交一并带出）。 */
export declare const gitCommitValue: z.ZodReadonly<z.ZodObject<{
    hash: z.ZodString;
    shortHash: z.ZodString;
    parents: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    subject: z.ZodString;
    author: z.ZodString;
    date: z.ZodString;
    refs: z.ZodString;
}, z.core.$strip>>;
export declare const gitStatusValue: z.ZodReadonly<z.ZodObject<{
    repo: z.ZodBoolean;
    root: z.ZodNullable<z.ZodString>;
    error: z.ZodNullable<z.ZodString>;
    branch: z.ZodNullable<z.ZodString>;
    upstream: z.ZodNullable<z.ZodString>;
    ahead: z.ZodNumber;
    behind: z.ZodNumber;
    staged: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        origPath: z.ZodNullable<z.ZodString>;
        xy: z.ZodString;
    }, z.core.$strip>>>>;
    changes: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        origPath: z.ZodNullable<z.ZodString>;
        xy: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitLogValue: z.ZodReadonly<z.ZodObject<{
    repo: z.ZodBoolean;
    root: z.ZodNullable<z.ZodString>;
    error: z.ZodNullable<z.ZodString>;
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        hash: z.ZodString;
        shortHash: z.ZodString;
        parents: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        subject: z.ZodString;
        author: z.ZodString;
        date: z.ZodString;
        refs: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitDiffValue: z.ZodReadonly<z.ZodObject<{
    text: z.ZodString;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const gitCommitFileValue: z.ZodReadonly<z.ZodObject<{
    path: z.ZodString;
    origPath: z.ZodNullable<z.ZodString>;
    status: z.ZodString;
}, z.core.$strip>>;
export declare const gitCommitDetailValue: z.ZodReadonly<z.ZodObject<{
    repo: z.ZodBoolean;
    root: z.ZodNullable<z.ZodString>;
    error: z.ZodNullable<z.ZodString>;
    commit: z.ZodNullable<z.ZodReadonly<z.ZodObject<{
        hash: z.ZodString;
        shortHash: z.ZodString;
        parents: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        subject: z.ZodString;
        author: z.ZodString;
        date: z.ZodString;
        refs: z.ZodString;
    }, z.core.$strip>>>;
    files: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        origPath: z.ZodNullable<z.ZodString>;
        status: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitMessageTextValue: z.ZodReadonly<z.ZodObject<{
    message: z.ZodString;
}, z.core.$strip>>;
export declare const gitBranchesValue: z.ZodReadonly<z.ZodObject<{
    repo: z.ZodBoolean;
    names: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    error: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>;
export declare const gitIdentityValue: z.ZodReadonly<z.ZodObject<{
    name: z.ZodNullable<z.ZodString>;
    email: z.ZodNullable<z.ZodString>;
    origin: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>;
export declare const gitActionValue: z.ZodReadonly<z.ZodObject<{
    detail: z.ZodString;
}, z.core.$strip>>;
export declare const gitCommitResultValue: z.ZodReadonly<z.ZodObject<{
    shortHash: z.ZodNullable<z.ZodString>;
    detail: z.ZodString;
}, z.core.$strip>>;
export declare const gitMessageValue: z.ZodReadonly<z.ZodObject<{
    message: z.ZodString;
    provider: z.ZodString;
    model: z.ZodString;
}, z.core.$strip>>;
/** 一条工作区状态条目。 */
export interface GitEntry {
    path: string;
    origPath: string | null;
    xy: string;
}
/** 一条提交记录（含父提交，供泳道图使用）。 */
export interface GitCommit {
    hash: string;
    shortHash: string;
    parents: readonly string[];
    subject: string;
    author: string;
    date: string;
    refs: string;
}
export interface GitStatusResponse {
    repo: boolean;
    root: string | null;
    error: string | null;
    branch: string | null;
    upstream: string | null;
    ahead: number;
    behind: number;
    staged: readonly GitEntry[];
    changes: readonly GitEntry[];
}
export interface GitLogResponse {
    repo: boolean;
    root: string | null;
    error: string | null;
    entries: readonly GitCommit[];
}
export interface GitDiffResponse {
    text: string;
    truncated: boolean;
}
/** 一条提交里被改动的文件（单字母状态）。 */
export interface GitCommitFile {
    path: string;
    origPath: string | null;
    status: string;
}
/** 一条提交的详情：元信息 + 改动文件清单。 */
export interface GitCommitDetail {
    repo: boolean;
    root: string | null;
    error: string | null;
    commit: GitCommit | null;
    files: readonly GitCommitFile[];
}
/** 上一条提交的完整信息（`提交(修改)` 预填用）。 */
export interface GitMessageText {
    message: string;
}
/** 本地分支清单。 */
export interface GitBranches {
    repo: boolean;
    names: readonly string[];
    error: string | null;
}
export interface GitIdentity {
    name: string | null;
    email: string | null;
    /** 生效值来自哪个配置文件；读不到时为 null。 */
    origin: string | null;
}
/** 写操作回执：`detail` 是给界面用的简短说明（多为 git 输出的尾行）。 */
export interface GitActionResponse {
    detail: string;
}
export interface GitCommitResponse {
    shortHash: string | null;
    detail: string;
}
/** 模型生成的提交信息与它使用的路由。 */
export interface GitMessageResponse {
    message: string;
    provider: string;
    model: string;
}
