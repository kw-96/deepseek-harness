/** Host half: the gitPanel Remote over ctx.shell (reads + explicit write actions). */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { GitActionResponse, GitBranches, GitCommitDetail, GitCommitResponse, GitDiffResponse, GitIdentity, GitLogResponse, GitMessageResponse, GitMessageText, GitStatusResponse } from './types.js';
export type * from './types.js';
/** gitPanel Remote: workspace status, history, write actions, and commit-message generation. */
export declare class GitPanel extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    /** Working-tree status: branch/upstream facts plus the staged and unstaged entry groups. */
    status(cwd: string): Promise<GitStatusResponse>;
    /** Commit history with parent hashes, for the graph (limit defaults to 80). */
    log(cwd: string, limit?: number): Promise<GitLogResponse>;
    /** One file's diff, from the index side when `staged` is set, otherwise the worktree side. */
    diff(cwd: string, path: string, staged: boolean): Promise<GitDiffResponse>;
    /** One commit's metadata and changed files, for the graph row's detail. */
    show(cwd: string, hash: string): Promise<GitCommitDetail>;
    /** One file's diff inside one commit, for the detail row's expansion. */
    showFile(cwd: string, hash: string, path: string): Promise<GitDiffResponse>;
    /** Local branches, most recently committed first. */
    branches(cwd: string): Promise<GitBranches>;
    /** Switch to an existing local branch. */
    checkout(cwd: string, branch: string): Promise<GitActionResponse>;
    /** Create a branch from HEAD and switch to it (name validated by `git check-ref-format`). */
    createBranch(cwd: string, name: string): Promise<GitActionResponse>;
    /** The previous commit's full message, used to prefill an amend. */
    lastMessage(cwd: string): Promise<GitMessageText>;
    /** Discard the worktree changes of the given tracked paths. */
    discard(cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
    /** Stage the given repository-relative paths. */
    stage(cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
    /** Unstage the given repository-relative paths. */
    unstage(cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
    /** Stage every change, including untracked files. */
    stageAll(cwd: string): Promise<GitActionResponse>;
    /** Unstage every staged change. */
    unstageAll(cwd: string): Promise<GitActionResponse>;
    /** Commit the staged changes; `amend` replaces the previous commit (message must be non-empty). */
    commit(cwd: string, message: string, amend: boolean): Promise<GitCommitResponse>;
    /** Push the current branch. */
    push(cwd: string): Promise<GitActionResponse>;
    /** Pull the current branch. */
    pull(cwd: string): Promise<GitActionResponse>;
    /** Fetch every remote and prune stale refs. */
    fetch(cwd: string): Promise<GitActionResponse>;
    /** The signing identity behind commits, plus the config file it comes from. */
    identity(cwd: string): Promise<GitIdentity>;
    /**
     * Write the signing identity, globally or for this repository only.
     * @param cwd - session working directory.
     * @param name - committer name (non-empty).
     * @param email - committer email (non-empty).
     * @param scope - `global` writes the user config, `local` writes this repository's config.
     */
    setIdentity(cwd: string, name: string, email: string, scope: 'global' | 'local'): Promise<GitActionResponse>;
    /** Draft a commit message with the session's own model route. */
    message(sessionId: string, cwd: string): Promise<GitMessageResponse>;
}
export default GitPanel;
