/** 变更列表里的一个分组（已暂存 / 更改），含行内差异与丢弃确认。 */
import type { DiffState, OpenDiff } from '../controller/state.js';
import type { GitEntry } from '../../types.js';
import type { TFn } from '../lib/faces.js';
export interface ChangeGroupProps {
    t: TFn;
    title: string;
    entries: readonly GitEntry[];
    /** 该组的行内操作：`stage` 组显示「暂存 + 丢弃」，`unstage` 组显示「取消暂存」。 */
    verb: 'stage' | 'unstage';
    confirmPath: string | null;
    openDiff: OpenDiff | null;
    diff: DiffState | null;
    onToggle: (entry: GitEntry) => void;
    onToggleAll: () => void;
    onDiscard: (entry: GitEntry) => void;
    onOpenDiff: (entry: GitEntry, staged: boolean) => void;
    onCloseDiff: () => void;
}
/**
 * 单个变更分组。
 * @param props 分组标题、条目与该组的回调
 */
export declare function ChangeGroup(props: ChangeGroupProps): React.ReactNode;
