/** 面板的读取器：把 Remote 读操作收敛成界面状态对象（不持有 React 状态）。 */
import type { GitPanelApi } from '../lib/faces.js';
import type { CommitDetailState, DiffState, OpenCommitFile, OpenDiff } from './state.js';
/** 读取一个文件的差异（索引侧或工作区侧）。 */
export declare function loadDiffState(api: GitPanelApi, cwd: string, target: OpenDiff): Promise<DiffState>;
/** 读取一条提交的详情（元信息 + 改动文件）。 */
export declare function loadCommitState(api: GitPanelApi, cwd: string, hash: string): Promise<CommitDetailState>;
/** 读取某条提交里某个文件的差异。 */
export declare function loadCommitFileState(api: GitPanelApi, cwd: string, target: OpenCommitFile): Promise<DiffState>;
/** 读取本地分支名；失败时回落到空列表并给出错误文本。 */
export declare function loadBranches(api: GitPanelApi, cwd: string): Promise<{
    names: readonly string[];
    error: string | null;
}>;
