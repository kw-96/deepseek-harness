/** 面板里的纯展示逻辑：状态字母、路径拆分、相对时间、分支引用解析。 */
import type { GitEntry } from '../../types.js';
import type { TFn } from './faces.js';
/** 未合并（冲突）条目：XY 含 U，或双方同为 A/D。 */
export declare function isConflict(xy: string): boolean;
/** porcelain 的 XY 状态码转单字母展示；冲突统一显示 `!`。 */
export declare function statusLetter(xy: string): string;
/** 状态字母的类型：冲突 / 改动 / 新增 / 删除，用于配色。 */
export declare function statusKind(xy: string): 'modified' | 'added' | 'deleted' | 'conflict';
/** 拆分路径为「文件名 + 目录」两段（无目录时第二段为空）。 */
export declare function splitPath(path: string): {
    name: string;
    dir: string;
};
/** 条目展示路径：重命名显示「原名 → 新名」。 */
export declare function entryLabel(entry: GitEntry): string;
/** `%ai` 时间转相对时间。 */
export declare function timeAgo(t: TFn, iso: string): string;
/** 一条提交引用徽标。 */
export interface RefBadge {
    label: string;
    kind: 'branch' | 'tag' | 'head';
}
/**
 * 解析 `%D` 装饰（形如 `HEAD -> dev, origin/dev, tag: v1.0`）。
 * @param refs `%D` 原文
 * @param branch 当前分支名（用于标记当前项）
 * @returns 徽标列表
 */
export declare function parseRefs(refs: string, branch: string | null): RefBadge[];
