/**
 * dsh-git-timeline 浏览器入口：挂载 gitPanel Remote，并向宿主官方右栏
 * （ui-sidebar-right）注册一个页面型标签「Git」——完整 Git 面板：
 * 变更提交（含模型生成提交信息）、提交图与远程同步。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * 挂载 Remote 并注册右栏标签类型。
 * @param ctx - 客户端根上下文。
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
