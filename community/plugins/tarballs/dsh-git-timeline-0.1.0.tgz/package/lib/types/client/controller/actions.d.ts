/** 面板动作的纯实现：Remote 调用的组合与前置校验，供控制器调用。 */
import type { GitEntry } from '../../types.js';
import type { CommitAction } from './state.js';
import type { GitPanelApi, TFn } from '../lib/faces.js';
/** 动作执行所需的上下文。 */
export interface ActionContext {
    api: GitPanelApi;
    cwd: string;
    t: TFn;
}
/**
 * 执行一次提交；按动作附加修补、拉取与推送。
 * @param ctx 动作上下文
 * @param message 提交信息（不允许空）
 * @param action 提交方式
 * @returns 给界面显示的说明（含新短哈希）
 */
export declare function runCommit(ctx: ActionContext, message: string, action: CommitAction): Promise<string>;
/** 暂存或取消暂存一个条目。 */
export declare function runToggleStage(ctx: ActionContext, entry: GitEntry, verb: 'stage' | 'unstage'): Promise<string>;
/** 丢弃一个已跟踪条目的工作区改动。 */
export declare function runDiscard(ctx: ActionContext, entry: GitEntry): Promise<string>;
/** 全部暂存 / 全部取消暂存。 */
export declare function runToggleAll(ctx: ActionContext, verb: 'stage' | 'unstage'): Promise<string>;
/** 抓取 / 拉取 / 推送。 */
export declare function runRemote(ctx: ActionContext, task: 'fetch' | 'pull' | 'push'): Promise<string>;
/** 切换分支。 */
export declare function runCheckout(ctx: ActionContext, branch: string): Promise<string>;
/** 写入 git 身份（全局或本仓库）。 */
export declare function runSetIdentity(ctx: ActionContext, name: string, email: string, scope: 'global' | 'local'): Promise<string>;
/** 新建并切换到分支。 */
export declare function runCreateBranch(ctx: ActionContext, name: string): Promise<string>;
/** 用当前会话的模型起草提交信息。 */
export declare function draftMessage(api: GitPanelApi, sessionId: string, cwd: string | undefined): Promise<string>;
/** 取上一条提交信息；失败时返回空串（预填失败不应打断提交）。 */
export declare function previousMessage(api: GitPanelApi, cwd: string): Promise<string>;
