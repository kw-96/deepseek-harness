/** 泳道图：由提交的父指针推导每行的泳道与贯穿列。 */
import type { GitCommit } from '../../types.js';
/** 图上最多绘制的泳道数，超出后归到最后一条。 */
export declare const MAX_LANES = 5;
/** 泳道配色（VSCode 风格的五色循环）。 */
export declare const LANE_COLORS: readonly string[];
/** 一行图：提交、它所在的泳道、该行需要绘制的泳道列。 */
export interface GraphRow {
    commit: GitCommit;
    /** 提交节点所在的泳道（已按 MAX_LANES 收敛）。 */
    lane: number;
    /** 本行纵向贯穿的泳道列（含提交所在的泳道）。 */
    columns: readonly number[];
    /** 合并提交（父提交多于一个）。 */
    merge: boolean;
}
/** 泳道配色索引。 */
export declare function laneColor(lane: number): string;
/**
 * 计算提交历史的泳道。
 *
 * 规则沿用常见 Git 图算法：先看哪条泳道正等待该提交（多条则折叠为合并），
 * 否则新开一条；随后首父留在当前泳道，其余父各占一条空闲泳道。
 * @param commits 按时间倒序的提交（`git log` 的顺序）
 * @param maxLanes 绘制上限
 * @returns 每行的泳道信息
 */
export declare function computeGraph(commits: readonly GitCommit[], maxLanes?: number): GraphRow[];
/** 泳道列的最大宽度（像素/列）。 */
export declare const LANE_WIDTH = 12;
