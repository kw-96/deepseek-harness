/** Changes 区：提交信息框（含模型生成）、提交方式按钮组、变更分组列表。 */
import type { GitEntry, GitStatusResponse } from '../../types.js';
import type { CommitAction, DiffState, OpenDiff } from '../controller/state.js';
import type { TFn } from '../lib/faces.js';
export interface ChangesProps {
    t: TFn;
    status: GitStatusResponse | null;
    message: string;
    onMessage: (value: string) => void;
    generating: boolean;
    onGenerate: () => void;
    action: CommitAction;
    onAction: (action: CommitAction) => void;
    busy: boolean;
    onCommit: () => void;
    onStage: (entry: GitEntry) => void;
    onUnstage: (entry: GitEntry) => void;
    onDiscard: (entry: GitEntry) => void;
    onStageAll: () => void;
    onUnstageAll: () => void;
    openDiff: OpenDiff | null;
    diff: DiffState | null;
    onOpenDiff: (entry: GitEntry, staged: boolean) => void;
    onCloseDiff: () => void;
}
/**
 * Changes 区。
 * @param props 状态、提交信息与全部回调
 */
export declare function Changes(props: ChangesProps): React.ReactNode;
