/** 面板与宿主的同步：首次加载与「会话写入 → 重读状态」的自动刷新。 */
import type { WorkspaceChangeFace } from '../lib/faces.js';
export interface UsePanelSyncOptions {
    sessionId: string;
    cwd: string | undefined;
    files: WorkspaceChangeFace | undefined;
    /** 全量刷新（状态 + 历史 + 身份），依赖变化时重跑首次加载。 */
    refresh: () => Promise<void>;
    /** 只重读工作区状态与展开中的差异。 */
    refreshStatus: () => Promise<void>;
    onError: (message: string) => void;
}
/**
 * 挂载面板的两次同步：进入时全量读取；会话写入时去抖重读状态。
 * @param options 会话、工作目录、变更流与两个刷新回调
 */
export declare function usePanelSync(options: UsePanelSyncOptions): void;
