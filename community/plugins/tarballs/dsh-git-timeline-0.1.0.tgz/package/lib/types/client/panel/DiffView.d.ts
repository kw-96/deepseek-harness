/** 行内差异视图：变更列表里展开当前文件的差异（工作区 / 索引侧 / 某条提交）。 */
import type { DiffState } from '../controller/state.js';
import type { TFn } from '../lib/faces.js';
/** 差异的作用域：决定头部显示的侧别标签。 */
export type DiffScope = 'staged' | 'worktree' | 'commit';
export interface DiffViewProps {
    t: TFn;
    path: string;
    scope: DiffScope;
    state: DiffState;
    onClose: () => void;
}
/**
 * 差异视图（嵌在列表内，不占新区域）。
 * @param props 目标文件、作用域、差异状态与关闭回调
 */
export declare function DiffView({ t, path, scope, state, onClose }: DiffViewProps): React.ReactNode;
