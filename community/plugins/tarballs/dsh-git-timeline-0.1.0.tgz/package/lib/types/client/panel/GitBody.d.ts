/** Git 面板标签体：Changes 区（上半） + Graph 区（下半） + 固定底部栏。 */
import type { GitBodyRuntimeProps, GitPanelApi, TFn, WorkspaceChangeFace } from '../lib/faces.js';
export interface GitBodyInjected {
    api: GitPanelApi;
    /** 会话文件变更流（可选）：把自动刷新挂在真实写入上。 */
    files?: WorkspaceChangeFace;
}
export interface GitBodyProps extends GitBodyRuntimeProps, GitBodyInjected {
    t: TFn;
}
/**
 * Git 面板标签体。
 * @param props 会话运行时 props、注入的 git 面与文案
 */
export declare function GitBody({ sessionId, useSessions, t, api, files }: GitBodyProps): React.ReactNode;
