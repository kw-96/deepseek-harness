/** Git 面板底部栏（固定）：分支切换、刷新、工作区名与 Git 账号（可配置）。 */
import type { GitIdentity } from '../../types.js';
import type { TFn } from '../lib/faces.js';
export interface BottomBarProps {
    t: TFn;
    branch: string | null;
    ahead: number;
    behind: number;
    identity: GitIdentity | null;
    workspaceName: string;
    busy: boolean;
    branchNames: readonly string[];
    branchMenuOpen: boolean;
    onToggleBranchMenu: () => void;
    onCheckout: (branch: string) => void;
    onCreateBranch: (name: string) => void;
    onSaveIdentity: (name: string, email: string, scope: 'global' | 'local') => void;
    onRefresh: () => void;
}
/**
 * 面板底部状态条。
 * @param props 分支/身份信息、切换分支与保存身份的入口
 */
export declare function BottomBar(props: BottomBarProps): React.ReactNode;
