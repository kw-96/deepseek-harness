/** 分支切换器的状态与动作（底部栏消费）。 */
import type { GitPanelApi, TFn } from '../lib/faces.js';
export interface BranchMenuState {
    branchMenuOpen: boolean;
    branchNames: readonly string[];
    toggleBranchMenu: () => void;
    closeBranchMenu: () => void;
    checkoutBranch: (branch: string) => void;
    createBranch: (name: string) => void;
}
/**
 * 组装底部栏的分支切换器。
 * @param options 工作目录、注入的 git 面、动作执行器与错误上报
 * @returns 分支菜单的状态与回调
 */
export declare function useBranchMenu(options: {
    cwd: string | undefined;
    api: GitPanelApi;
    t: TFn;
    run: (operation: () => Promise<string>) => Promise<void>;
    onError: (message: string) => void;
}): BranchMenuState;
