/** 提交详情：Graph 列表里展开一条提交的元信息、改动文件与单文件差异。 */
import type { CommitDetailState, DiffState, OpenCommitFile } from '../controller/state.js';
import type { TFn } from '../lib/faces.js';
export interface CommitDetailProps {
    t: TFn;
    hash: string;
    state: CommitDetailState;
    openFile: OpenCommitFile | null;
    fileDiff: DiffState | null;
    onToggleFile: (hash: string, path: string) => void;
    onClose: () => void;
}
/**
 * 提交详情视图（嵌在 Graph 列表中）。
 * @param props 目标提交、详情状态、展开的文件差异与关闭回调
 */
export declare function CommitDetail(props: CommitDetailProps): React.ReactNode;
