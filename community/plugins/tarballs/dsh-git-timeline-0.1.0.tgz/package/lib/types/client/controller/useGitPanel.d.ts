/** Git 面板控制器：Remote 读取、动作执行、差异与提交详情的状态机。 */
import type { GitPanelController, UseGitPanelOptions } from './state.js';
/**
 * 组装面板的读取、动作与展开状态。
 * @param options 会话、工作目录、文案与注入的 git 面
 * @returns 界面可直接消费的状态与回调
 */
export declare function useGitPanel(options: UseGitPanelOptions): GitPanelController;
