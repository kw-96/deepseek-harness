/** Graph 区：工具栏（定位/抓取/拉取/推送/刷新）与提交泳道列表。 */
import type { GitLogResponse } from '../../types.js';
import type { CommitDetailState, DiffState, OpenCommitFile } from '../controller/state.js';
import type { TFn } from '../lib/faces.js';
export interface GraphProps {
    t: TFn;
    log: GitLogResponse | null;
    branch: string | null;
    busy: boolean;
    /** 递增即触发「跳到当前历史记录项」。 */
    locateSignal: number;
    /** 展开中的提交哈希（null 表示未展开）。 */
    openCommit: string | null;
    detail: CommitDetailState | null;
    /** 提交详情里展开的文件差异。 */
    openFile: OpenCommitFile | null;
    fileDiff: DiffState | null;
    onOpenCommit: (hash: string) => void;
    onCloseDetail: () => void;
    onToggleFile: (hash: string, path: string) => void;
    onLocate: () => void;
    onFetch: () => void;
    onPull: () => void;
    onPush: () => void;
    onRefresh: () => void;
}
/**
 * Graph 区。
 * @param props 历史、分支与工具栏回调
 */
export declare function Graph(props: GraphProps): React.ReactNode;
