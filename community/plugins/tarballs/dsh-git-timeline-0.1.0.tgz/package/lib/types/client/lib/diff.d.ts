/** 差异文本按行分类，供着色渲染（与 Git 面板的行内差异视图共用）。 */
export type DiffLineKind = 'add' | 'del' | 'hunk' | 'meta' | 'context';
export interface DiffLine {
    kind: DiffLineKind;
    text: string;
}
/**
 * 把 unified diff 拆成带类别的行。
 * @param text diff 原文
 * @returns 逐行类别与内容
 */
export declare function parseDiffLines(text: string): DiffLine[];
