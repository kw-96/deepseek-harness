/** 提交历史：带父提交的 log 读取（供 Graph 泳道使用）。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitCommit, GitCommitDetail, GitCommitFile, GitLogResponse, GitMessageText } from '../types.js';
/**
 * 解析 `--format=%h%x1f%H%x1f%P%x1f%s%x1f%an%x1f%ai%x1f%D` 的输出。
 * @param raw 原始 stdout
 * @returns 提交列表
 */
export declare function parseLog(raw: string): GitCommit[];
/**
 * 读取提交历史。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param limit 条数上限（默认 80）
 */
export declare function readLog(shell: ShellExecutor, cwd: string, limit?: number): Promise<GitLogResponse>;
/**
 * 读取上一条提交的完整信息（「提交(修改)」预填输入框）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 */
export declare function readLastMessage(shell: ShellExecutor, cwd: string): Promise<GitMessageText>;
/**
 * 解析 `diff-tree --name-status -z` 的 `状态\0路径\0…` 帧序列。
 *
 * 重命名/复制会多带一个原路径帧（`R100\0旧\0新\0`）；本插件不传 `-M`，
 * 正常只会出现 A/M/D/T，这里仍按完整语义解析。
 * @param raw 原始输出
 * @returns 改动文件列表
 */
export declare function parseNameStatus(raw: string): GitCommitFile[];
/**
 * 读取一条提交的详情（元信息 + 改动文件清单），供 Graph 列表展开。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param hash 提交哈希
 */
export declare function readCommit(shell: ShellExecutor, cwd: string, hash: string): Promise<GitCommitDetail>;
