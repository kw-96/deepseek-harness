/** 分支：本地分支清单、切换与新建。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitActionResponse, GitBranches } from '../types.js';
/**
 * 列出本地分支（按最近提交时间倒序，与分支切换器的常见顺序一致）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 */
export declare function readBranches(shell: ShellExecutor, cwd: string): Promise<GitBranches>;
/** 切换分支（`git checkout <branch>`）。 */
export declare function checkout(shell: ShellExecutor, cwd: string, branch: string): Promise<GitActionResponse>;
/** 新建并切换到分支（`git checkout -b <name>`）；先做 `check-ref-format` 校验。 */
export declare function createBranch(shell: ShellExecutor, cwd: string, name: string): Promise<GitActionResponse>;
