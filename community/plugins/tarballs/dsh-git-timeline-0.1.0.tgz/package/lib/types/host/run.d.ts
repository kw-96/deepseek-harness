/** 在 ctx.shell 上执行 git：统一引号、超时与错误上抛。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
export declare const GIT_TIMEOUT_MS = 30000;
/** 网络类操作（fetch/pull/push）的超时上限。 */
export declare const GIT_NETWORK_TIMEOUT_MS = 120000;
export interface GitOutcome {
    stdout: string;
    stderr: string;
}
/**
 * 执行一条 git 命令。
 * @param shell shell 执行器
 * @param cwd 工作目录
 * @param args 参数（自动加引号）
 * @param timeoutMs 超时
 * @returns stdout / stderr 文本
 */
export declare function git(shell: ShellExecutor, cwd: string, args: readonly string[], timeoutMs?: number): Promise<GitOutcome>;
/** 目标目录所属仓库根（绝对路径）；不在仓库内时返回 null。 */
export declare function repoRoot(shell: ShellExecutor, cwd: string): Promise<string | null>;
/**
 * 把用户输入规范成仓库根相对路径：绝对路径取其相对根的部分，相对路径按
 * 仓库根解释。
 * @param root 仓库根（绝对路径）
 * @param input 用户输入或列表给出的路径
 */
export declare function repoRelative(root: string, input: string): string;
/** 取 git 输出的最后一行非空文本，作为写操作的回执说明。 */
export declare function lastLine(text: string): string;
