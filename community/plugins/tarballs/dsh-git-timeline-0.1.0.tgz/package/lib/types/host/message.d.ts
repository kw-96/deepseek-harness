/**
 * 用当前会话的模型生成提交信息。
 *
 * 路由取自会话日志里最后一条 `request/header`（`session.requestHeader().config`），
 * 因此用的就是「当前会话正在使用的模型」；这是一次性辅助请求，不写回会话转写。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitMessageResponse } from '../types.js';
/**
 * 生成一条提交信息。
 * @param ctx 宿主上下文（需要 llm 与 agents 服务）
 * @param shell shell 执行器
 * @param sessionId 当前会话
 * @param cwd 会话工作目录
 * @returns 提交信息与所用路由
 */
export declare function generateCommitMessage(ctx: Context, shell: ShellExecutor, sessionId: string, cwd: string): Promise<GitMessageResponse>;
