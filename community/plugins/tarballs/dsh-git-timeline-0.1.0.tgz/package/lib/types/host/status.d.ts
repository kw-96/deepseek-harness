/** 工作区状态、差异与身份：porcelain-v2 解析与只读读取。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitDiffResponse, GitEntry, GitStatusResponse } from '../types.js';
/** porcelain-v2 的解析结果。 */
export interface PorcelainStatus {
    branch: string | null;
    upstream: string | null;
    ahead: number;
    behind: number;
    entries: GitEntry[];
}
/**
 * 解析 `git status --porcelain=v2 --branch -z`。
 *
 * `-z` 下的重命名/复制条目把原路径放在**下一个 NUL 帧**（不是 TAB），
 * 因此这里按索引遍历并消费该帧。
 * @param raw 原始输出（`\0` 分帧）
 * @returns 分支/上下游与条目列表
 */
export declare function parsePorcelainV2(raw: string): PorcelainStatus;
/**
 * 把条目拆成暂存侧与工作区侧：`??` 只算工作区，`MM` 两侧都算。
 * @param entries porcelain 条目
 */
export declare function splitEntries(entries: readonly GitEntry[]): {
    staged: GitEntry[];
    changes: GitEntry[];
};
/**
 * 读取工作区状态；非仓库与失败都以字段回传。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 */
export declare function readStatus(shell: ShellExecutor, cwd: string): Promise<GitStatusResponse>;
/**
 * 读取差异文本（默认未暂存；`staged` 为真时读索引侧）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param options 目标路径、暂存侧与字节上限
 */
export declare function readDiff(shell: ShellExecutor, cwd: string, options?: {
    paths?: readonly string[];
    staged?: boolean;
    maxBytes?: number;
}): Promise<GitDiffResponse>;
/**
 * 读取一条提交里某个文件的差异（`git show --patch`，首个提交也适用）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param hash 提交哈希
 * @param path 仓库根相对路径
 * @param maxBytes 字节上限
 */
export declare function readCommitDiff(shell: ShellExecutor, cwd: string, hash: string, path: string, maxBytes?: number): Promise<GitDiffResponse>;
