/** 写操作：暂存、取消暂存、提交（含修补）、推送、拉取、抓取。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitActionResponse, GitCommitResponse } from '../types.js';
/**
 * 暂存指定路径（`git add -- <paths>`）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param paths 仓库根相对路径
 */
export declare function stage(shell: ShellExecutor, cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
/**
 * 取消暂存指定路径（`git restore --staged -- <paths>`）。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param paths 仓库根相对路径
 */
export declare function unstage(shell: ShellExecutor, cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
/** 暂存全部改动（含未跟踪文件）。 */
export declare function stageAll(shell: ShellExecutor, cwd: string): Promise<GitActionResponse>;
/** 取消暂存全部改动。 */
export declare function unstageAll(shell: ShellExecutor, cwd: string): Promise<GitActionResponse>;
/**
 * 丢弃工作区改动（恢复为 HEAD 内容）。
 *
 * 只作用于已跟踪路径：未跟踪文件不会被删除（界面也不给它入口），
 * 避免误删刚生成、还没纳入版本控制的文件。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param paths 仓库根相对路径
 */
export declare function discard(shell: ShellExecutor, cwd: string, paths: readonly string[]): Promise<GitActionResponse>;
/**
 * 提交暂存内容；`amend` 为真时修补上一条提交。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param message 提交信息（必须非空）
 * @param amend 是否 `--amend`
 */
export declare function commit(shell: ShellExecutor, cwd: string, message: string, amend: boolean): Promise<GitCommitResponse>;
/** 推送当前分支。 */
export declare function push(shell: ShellExecutor, cwd: string): Promise<GitActionResponse>;
/** 拉取当前分支（`--no-edit` 避免打开编辑器）。 */
export declare function pull(shell: ShellExecutor, cwd: string): Promise<GitActionResponse>;
/** 从所有远程抓取并清理陈旧引用。 */
export declare function fetch(shell: ShellExecutor, cwd: string): Promise<GitActionResponse>;
