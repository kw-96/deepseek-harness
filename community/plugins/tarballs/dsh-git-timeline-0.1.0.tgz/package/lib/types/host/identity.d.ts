/** Git 身份：读取生效署名与来源，并支持写入。 */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { GitActionResponse, GitIdentity } from '../types.js';
/** 解析 `git var GIT_COMMITTER_IDENT` 的输出（`Name <email> 时间 时区`）。 */
export declare function parseIdent(text: string): {
    name: string | null;
    email: string | null;
};
/**
 * 读取生效的 git 身份。
 *
 * 先按配置项读取（能拿到来源文件）；两者都为空时再问一次 git 自己会用的
 * 署名（`git var GIT_COMMITTER_IDENT`），以覆盖只写了其中一个键的情况。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 */
export declare function readIdentity(shell: ShellExecutor, cwd: string): Promise<GitIdentity>;
/**
 * 写入 git 身份。
 * @param shell shell 执行器
 * @param cwd 会话工作目录
 * @param name 署名（非空）
 * @param email 邮箱（非空）
 * @param scope `global` 写用户级配置，`local` 只写当前仓库
 */
export declare function writeIdentity(shell: ShellExecutor, cwd: string, name: string, email: string, scope: 'global' | 'local'): Promise<GitActionResponse>;
