/**
 * 新建会话页的项目选择器（遮蔽宿主 `conversation.hero.workspace`）：
 * 列出项目（置顶 → 最近 → 其余）与未分组工作区，并提供「新建项目…」。
 * 选中项目时：单工作区直接开会话；多工作区先展开工作树让用户选一个；
 * 没有归属工作区的项目禁用并说明原因。弹层内容在 hero-menu。
 */
import { type RefObject } from 'react';
import type { FsListResponse, ProjectView } from 'dsh-codex-left/types';
import type { SelectorHook, SessionListStateLike, TFn, WorkspaceSnapshotLike } from '../faces.js';
import type { BrowserPrefsStore } from '../state/prefs.js';
export interface ProjectPickerInjected {
    listProjects: () => Promise<{
        projects: readonly ProjectView[];
    }>;
    prefs: BrowserPrefsStore;
    createWorkspace: (input: {
        path: string;
    }) => Promise<{
        workspaceId: string;
        path: string;
    }>;
    createProject: (name: string, roots?: readonly string[]) => Promise<{
        project: ProjectView;
    }>;
    fsList: (path: string) => Promise<FsListResponse>;
}
export interface ProjectPickerProps extends ProjectPickerInjected {
    /** 宿主 hero 的弹出开关（点击工作区 chip 切换）。 */
    open: boolean;
    /** chip 元素：弹层的定位锚点。 */
    anchorRef?: RefObject<HTMLElement | null> | undefined;
    /** 宿主已选中的工作区（列表打勾）。 */
    selectedId?: string | undefined;
    onPick: (workspaceId: string) => void;
    onClose: () => void;
    useWorkspaces: SelectorHook<WorkspaceSnapshotLike>;
    useSessions: SelectorHook<SessionListStateLike>;
    t: TFn;
}
/** 渲染项目选择弹层（含工作树二级选择与新建项目入口）。 */
export declare function ProjectPicker(props: ProjectPickerProps): import("react").JSX.Element | null;
