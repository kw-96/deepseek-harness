/**
 * 「管理工作树」弹窗：编辑项目的目录 roots（工作树）。
 * 每个 root 对应一个目录；目录已注册为工作区时额外标注，未注册的目录
 * 会在会话归并/新建时按需补建工作区。
 */
import type { FsListResponse, ProjectView } from 'dsh-codex-left/types';
import type { TFn, WorkspaceViewLike } from '../../faces.js';
export interface ProjectWorktreesProps {
    /** 要管理的项目；null 表示关闭。 */
    project: ProjectView | null;
    workspaces: readonly WorkspaceViewLike[];
    fsList: (path: string) => Promise<FsListResponse>;
    onSave: (projectId: string, roots: readonly string[]) => Promise<void>;
    onClose: () => void;
    t: TFn;
}
/** 渲染工作树管理弹窗；未选中项目时返回 null。 */
export declare function ProjectWorktreesModal(props: ProjectWorktreesProps): import("react").JSX.Element | null;
