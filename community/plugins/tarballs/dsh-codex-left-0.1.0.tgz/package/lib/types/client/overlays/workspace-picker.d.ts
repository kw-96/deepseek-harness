/** 添加工作区居中弹窗（挂在侧栏页脚槽位，只渲染弹窗不渲染按钮；
 * 打开入口为标题栏「+」与桌面标题栏 File → Open Workspace）。
 * 目录浏览基于 codexShell remote 的 fsList；原生 directoryFlow 槽声明
 * 始终由被遮蔽的原生浏览器持有，插件不能渲染它，故自带轻量选择流程。 */
import type { FsListResponse } from 'dsh-codex-left/types';
import type { SelectorHook, SessionListStateLike, TFn, WorkspaceViewLike } from '../faces.js';
export interface AddWorkspaceInjected {
    fsList: (path: string) => Promise<FsListResponse>;
    createWorkspace: (input: {
        path: string;
    }) => Promise<WorkspaceViewLike>;
}
export interface AddWorkspaceProps extends AddWorkspaceInjected {
    useSessions: SelectorHook<SessionListStateLike>;
    t: TFn;
}
/** 居中“添加工作区”弹窗（页脚槽位只承载弹窗，无可见按钮）。 */
export declare function AddWorkspaceAction({ useSessions, fsList, createWorkspace, t }: AddWorkspaceProps): import("react").JSX.Element;
