/**
 * 目录浏览视图（弹窗内复用）：路径输入 + 上级/刷新 + 子目录列表。
 * 数据来自 codexShell remote 的 fsList；当前路径变化时通过 onSelect 回传。
 */
import type { FsListResponse } from 'dsh-codex-left/types';
import type { TFn } from '../../faces.js';
export interface DirectoryBrowseProps {
    fsList: (path: string) => Promise<FsListResponse>;
    /** 首次挂载时列出的目录。 */
    initialPath: string;
    /** 当前选中目录变化（输入、进入子目录、返回上级）时回调。 */
    onSelect: (path: string) => void;
    t: TFn;
}
/** 渲染目录浏览视图。 */
export declare function DirectoryBrowse({ fsList, initialPath, onSelect, t }: DirectoryBrowseProps): import("react").JSX.Element;
