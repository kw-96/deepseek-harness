export interface ProfileLocation {
    readonly directory: string;
    readonly profileName: string;
}
export declare function profileLocation(baseUrl: string): ProfileLocation;
export declare function installedDependencies(directory: string): Promise<Readonly<Record<string, string>>>;
