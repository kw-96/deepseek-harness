import { type CatalogDocument } from '../manifest.js';
export interface CatalogCollectorConfig {
    readonly githubTopic?: string;
    readonly githubApiUrl?: string;
    readonly rawGithubUrl?: string;
    readonly npmRegistryUrl?: string;
    readonly requestTimeoutMs?: number;
    readonly githubRepositoryBatchSize?: number;
    readonly githubRepositoryLimit?: number;
    readonly githubToken?: string;
    readonly previousCatalog?: CatalogDocument;
    readonly incrementalSince?: string;
}
type Fetcher = typeof fetch;
/** Build-time GitHub and npm scanner. Runtime marketplace code never calls this collector. */
export declare class CatalogCollector {
    private readonly githubTopic;
    private readonly githubApiUrl;
    private readonly rawGithubUrl;
    private readonly npmRegistryUrl;
    private readonly timeoutMs;
    private readonly repositoryBatchSize;
    private readonly repositoryLimit;
    private readonly githubToken;
    private readonly previousCatalog;
    private readonly incrementalSince;
    private readonly fetcher;
    constructor(config?: CatalogCollectorConfig, fetcher?: Fetcher);
    collect(): Promise<CatalogDocument>;
    private discoverRepositories;
    private readRepository;
    private validateManifest;
    private admittedEntry;
    private packageEntry;
    private verifyNpmReference;
    private rejectPackageConflicts;
    private withCarriedCoverageWarning;
    private readGithubTree;
    private request;
    private readJson;
    private readGithubJson;
    private candidateIssue;
    private errorMessage;
}
export {};
