import type { MarketplaceInstallTarget } from './installer.js';
/** Stable authorization key for the exact npm artifact admitted by the catalog. */
export declare function installTargetKey(target: MarketplaceInstallTarget): string;
