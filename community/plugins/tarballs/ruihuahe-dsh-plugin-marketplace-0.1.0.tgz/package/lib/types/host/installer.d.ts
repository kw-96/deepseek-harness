import type { InstallReceipt } from '../types.js';
import type { ProfileLocation } from './profile.js';
export interface CommandResult {
    readonly exitCode: number;
    readonly stdout: string;
    readonly stderr: string;
}
export type CommandRunner = (arguments_: readonly string[], cwd: string) => Promise<CommandResult>;
export interface MarketplaceInstallTarget {
    readonly packageName: string;
    readonly version: string;
}
/** Execute the current Node-based dsh launcher without shell interpolation. */
export declare function currentDshRunner(timeoutMs?: number): CommandRunner;
/** Serialized exact-version npm installation through the official dsh plugin boundary. */
export declare class MarketplaceInstaller {
    private readonly runner;
    private tail;
    constructor(runner?: CommandRunner);
    install(plugin: MarketplaceInstallTarget, location: ProfileLocation, dependencies: Readonly<Record<string, string>>): Promise<InstallReceipt>;
    private serialize;
}
