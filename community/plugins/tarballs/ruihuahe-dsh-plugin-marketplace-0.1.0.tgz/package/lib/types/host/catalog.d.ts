import { type CatalogEntry } from '../manifest.js';
import { type DiscoveryWarning, type MarketplaceSnapshot } from '../types.js';
export interface CatalogServiceConfig {
    readonly catalogUrl?: string;
    readonly cacheFile: string;
    readonly requestTimeoutMs?: number;
}
export interface CatalogState {
    readonly entries: readonly CatalogEntry[];
    readonly warnings: readonly DiscoveryWarning[];
    readonly stale: boolean;
    readonly generatedAt: string | null;
    readonly fetchedAt: string;
}
type Fetcher = typeof fetch;
/** Runtime boundary for one generated marketplace catalog plus a last-known-good cache. */
export declare class CatalogService {
    private readonly catalogUrl;
    private readonly cacheFile;
    private readonly timeoutMs;
    private readonly fetcher;
    private etag;
    private document;
    private state;
    private cacheLoaded;
    constructor(config: CatalogServiceConfig, fetcher?: Fetcher);
    list(refresh?: boolean): Promise<CatalogState>;
    private fromDocument;
    private request;
    private warning;
    private readCache;
    private loadCacheOnce;
    private writeCache;
}
export declare function snapshotWithProfile(state: CatalogState, profileName: string, dependencies: Readonly<Record<string, string>>): MarketplaceSnapshot;
export {};
