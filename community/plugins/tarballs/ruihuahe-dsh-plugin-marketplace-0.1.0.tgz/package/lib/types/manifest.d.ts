import { z } from 'zod';
export declare const npmPackageNameSchema: z.ZodString;
export declare const exactVersionSchema: z.ZodString;
/** A repository child path is always relative and cannot escape its checkout. */
export declare function isSafePackagePath(value: string): boolean;
export declare const localizedTextSchema: z.ZodObject<{
    'zh-CN': z.ZodString;
    en: z.ZodString;
}, z.core.$strict>;
/**
 * Generic package metadata used to discover a candidate. This intentionally
 * does not define a marketplace-owned plugin manifest: installability is
 * established from the published npm artifact and repository ownership.
 */
export declare const packageManifestSchema: z.ZodObject<{
    name: z.ZodString;
    version: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    keywords: z.ZodOptional<z.ZodArray<z.ZodString>>;
    license: z.ZodOptional<z.ZodString>;
    homepage: z.ZodOptional<z.ZodString>;
    dsh: z.ZodOptional<z.ZodObject<{
        bundle: z.ZodOptional<z.ZodObject<{
            patch: z.ZodString;
        }, z.core.$loose>>;
    }, z.core.$loose>>;
}, z.core.$loose>;
export declare const catalogIssueCodeSchema: z.ZodEnum<{
    "repository-unavailable": "repository-unavailable";
    "manifest-unavailable": "manifest-unavailable";
    "manifest-invalid": "manifest-invalid";
    "package-unpublished": "package-unpublished";
    "package-invalid": "package-invalid";
    "repository-mismatch": "repository-mismatch";
    "package-conflict": "package-conflict";
}>;
export declare const catalogAvailabilitySchema: z.ZodEnum<{
    installable: "installable";
    unavailable: "unavailable";
}>;
export declare const catalogCompatibilitySchema: z.ZodEnum<{
    declared: "declared";
    unverified: "unverified";
}>;
export declare const catalogEntrySchema: z.ZodObject<{
    id: z.ZodString;
    repositoryFullName: z.ZodString;
    repositoryUrl: z.ZodString;
    packageName: z.ZodNullable<z.ZodString>;
    version: z.ZodNullable<z.ZodString>;
    displayName: z.ZodObject<{
        'zh-CN': z.ZodString;
        en: z.ZodString;
    }, z.core.$strict>;
    summary: z.ZodObject<{
        'zh-CN': z.ZodString;
        en: z.ZodString;
    }, z.core.$strict>;
    keywords: z.ZodArray<z.ZodString>;
    license: z.ZodNullable<z.ZodString>;
    repositoryDirectory: z.ZodNullable<z.ZodString>;
    homepage: z.ZodNullable<z.ZodString>;
    manifestUrl: z.ZodNullable<z.ZodString>;
    availability: z.ZodEnum<{
        installable: "installable";
        unavailable: "unavailable";
    }>;
    compatibility: z.ZodEnum<{
        declared: "declared";
        unverified: "unverified";
    }>;
    issueCode: z.ZodNullable<z.ZodEnum<{
        "repository-unavailable": "repository-unavailable";
        "manifest-unavailable": "manifest-unavailable";
        "manifest-invalid": "manifest-invalid";
        "package-unpublished": "package-unpublished";
        "package-invalid": "package-invalid";
        "repository-mismatch": "repository-mismatch";
        "package-conflict": "package-conflict";
    }>>;
    issue: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const catalogWarningSchema: z.ZodObject<{
    code: z.ZodString;
    message: z.ZodString;
}, z.core.$strict>;
export declare const catalogDocumentSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<2>;
    generatedAt: z.ZodString;
    entries: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        repositoryFullName: z.ZodString;
        repositoryUrl: z.ZodString;
        packageName: z.ZodNullable<z.ZodString>;
        version: z.ZodNullable<z.ZodString>;
        displayName: z.ZodObject<{
            'zh-CN': z.ZodString;
            en: z.ZodString;
        }, z.core.$strict>;
        summary: z.ZodObject<{
            'zh-CN': z.ZodString;
            en: z.ZodString;
        }, z.core.$strict>;
        keywords: z.ZodArray<z.ZodString>;
        license: z.ZodNullable<z.ZodString>;
        repositoryDirectory: z.ZodNullable<z.ZodString>;
        homepage: z.ZodNullable<z.ZodString>;
        manifestUrl: z.ZodNullable<z.ZodString>;
        availability: z.ZodEnum<{
            installable: "installable";
            unavailable: "unavailable";
        }>;
        compatibility: z.ZodEnum<{
            declared: "declared";
            unverified: "unverified";
        }>;
        issueCode: z.ZodNullable<z.ZodEnum<{
            "repository-unavailable": "repository-unavailable";
            "manifest-unavailable": "manifest-unavailable";
            "manifest-invalid": "manifest-invalid";
            "package-unpublished": "package-unpublished";
            "package-invalid": "package-invalid";
            "repository-mismatch": "repository-mismatch";
            "package-conflict": "package-conflict";
        }>>;
        issue: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>>;
    warnings: z.ZodArray<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type PackageManifest = z.infer<typeof packageManifestSchema>;
export type CatalogEntry = z.infer<typeof catalogEntrySchema>;
export type CatalogDocument = z.infer<typeof catalogDocumentSchema>;
/** Normalize common npm/GitHub repository spellings to a stable HTTPS URL. */
export declare function canonicalGithubRepository(value: string): string | null;
