import type { RemoteResult, TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
import type { InstallReceipt, MarketplaceSnapshot } from './types.js';
export declare const TYPERT_REMOTE: TypertRemoteContribution;
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    invocations: readonly [{
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }, {
        id: string;
        service: string;
        namespace: string;
        method: string;
        invocation: {
            kind: "direct";
        };
        parameters: readonly {
            name: string;
            wire: string;
            source: "json";
            codec: {
                mode: "strict";
                typeSymbol: string;
                schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
            };
        }[];
        result: {
            mode: "strict";
            typeSymbol: string;
            schema: z.ZodType<unknown, unknown, z.core.$ZodTypeInternals<unknown, unknown>>;
        };
    }];
    model: {
        services: never[];
        events: never[];
        objects: never[];
    };
};
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteMap {
        'marketplace/list': (refresh: boolean) => Promise<RemoteResult<MarketplaceSnapshot>>;
        'marketplace/installPlugin': (packageName: string, version: string) => Promise<RemoteResult<InstallReceipt>>;
    }
    interface TypertRemoteNamespaceMap {
        marketplace: {
            list: (refresh: boolean) => Promise<RemoteResult<MarketplaceSnapshot>>;
            installPlugin: (packageName: string, version: string) => Promise<RemoteResult<InstallReceipt>>;
        };
    }
}
export default TYPERT_REMOTE;
