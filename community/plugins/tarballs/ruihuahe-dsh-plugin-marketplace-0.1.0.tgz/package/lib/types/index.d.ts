import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { InstallReceipt, MarketplaceSnapshot } from './types.js';
export type * from './types.js';
export * from './manifest.js';
export interface Config {
    readonly catalogUrl?: string;
    readonly requestTimeoutMs?: number;
    readonly installTimeoutMs?: number;
}
/** Independent discovery and installation service for the active DSH profile. */
export declare class PluginMarketplace extends TypertRemoteService {
    static inject: string[];
    private readonly location;
    private readonly catalog;
    private readonly installer;
    private latest;
    constructor(ctx: Context, config?: Config);
    list(refresh: boolean): Promise<MarketplaceSnapshot>;
    install(packageName: string, version: string): Promise<InstallReceipt>;
    private project;
}
export default PluginMarketplace;
