/**
 * 市场插件分类：按条目关键词离线派生一个功能分类，供列表分组与详情展示使用。
 * 分类是派生态而非存储态——目录数据（catalog v2）不新增字段，也不触发重新联网扫描。
 * @module @ruihuahe/dsh-plugin-marketplace/category
 */
/** 市场插件的功能分类 id，同时是展示分组与排序依据。 */
export type CatalogCategory = 'agent' | 'tool' | 'ui' | 'mcp' | 'skill' | 'llm' | 'workflow' | 'memory' | 'web' | 'cost' | 'security' | 'plugin-manager' | 'other';
/** 界面分组展示顺序（other 兜底不参与展示排序）。 */
export declare const CATEGORY_DISPLAY_ORDER: readonly CatalogCategory[];
/**
 * 按关键词打分派生分类：命中数最多者胜出，同分按分类优先级破平，零命中归入 other。
 * @param keywords - 目录条目携带的关键词（发布者/仓库主题）。
 * @returns 派生的功能分类 id。
 */
export declare function deriveCategory(keywords: readonly string[]): CatalogCategory;
/** 分类的本地化显示名（界面按 locale 选取）。 */
export declare const CATEGORY_LABELS: Readonly<Record<CatalogCategory, {
    'zh-CN': string;
    en: string;
}>>;
