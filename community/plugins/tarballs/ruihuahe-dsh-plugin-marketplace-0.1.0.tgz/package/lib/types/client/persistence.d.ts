import { type Dispatch, type SetStateAction } from 'react';
export type PersistFieldKind = 'normal' | 'sensitive' | 'transient';
export type PersistPolicy<T> = {
    key: string;
    kind: PersistFieldKind;
    scopeId?: string;
    defaultValue: T;
    serializer?: (value: T) => string;
    deserializer?: (raw: string) => T;
};
/** Failure-safe state persistence for non-sensitive marketplace preferences. */
export declare function usePersistedState<T>(policy: PersistPolicy<T>): [T, Dispatch<SetStateAction<T>>];
