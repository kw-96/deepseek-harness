import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.pluginMarketplace': LocaleKey;
    }
}
export declare const inject: string[];
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
export { PluginMarketplaceTab } from './PluginMarketplaceTab.js';
export type { PluginMarketplaceTabApi, PluginMarketplaceTabProps } from './PluginMarketplaceTab.js';
