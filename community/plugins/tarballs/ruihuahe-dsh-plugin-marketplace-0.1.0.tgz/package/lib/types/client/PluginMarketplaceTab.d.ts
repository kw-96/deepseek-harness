import { type ReactNode } from 'react';
import { type InstallReceipt, type MarketplaceSnapshot } from '../types.js';
import type { LocaleKey } from './locales.js';
export interface PluginMarketplaceTabApi {
    readonly list: (refresh: boolean) => Promise<MarketplaceSnapshot>;
    readonly install: (packageName: string, version: string) => Promise<InstallReceipt>;
}
export interface PluginMarketplaceTabProps extends PluginMarketplaceTabApi {
    readonly t: (key: LocaleKey) => string;
    readonly locale: string;
}
/** Compact generated-catalog browser and exact-version install surface. */
export declare function PluginMarketplaceTab({ list, install, t, locale }: PluginMarketplaceTabProps): ReactNode;
