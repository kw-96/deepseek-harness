/** Filesystem operations behind the codexShell Remote, built on ctx.fs. */
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { FsListResponse, FsReadResponse } from '../types.js';
/** List one directory through the fs service. */
export declare function listDirectory(fs: FileSystem, path: string): Promise<FsListResponse>;
/** Read one file as text through the fs service, with size caps. */
export declare function readTextFile(fs: FileSystem, path: string, maxBytes?: number): Promise<FsReadResponse>;
/** Write one file through the fs service. */
export declare function writeTextFile(fs: FileSystem, path: string, content: string): Promise<{
    ok: true;
}>;
/** Recursive filename search under one root; skips VCS/dependency directories. */
export declare function searchNames(fs: FileSystem, root: string, query: string): Promise<{
    matches: readonly {
        path: string;
        isDir: boolean;
    }[];
    truncated: boolean;
}>;
