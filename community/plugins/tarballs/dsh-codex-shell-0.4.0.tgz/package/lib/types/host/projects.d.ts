/** Per-workspace additional project directories, persisted under the DSH home. */
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { ProjectDirsResponse } from '../types.js';
/** Read one workspace's additional directories (empty when absent). */
export declare function projectDirs(fs: FileSystem, workspaceId: string): Promise<ProjectDirsResponse>;
/** Replace one workspace's additional directories with a validated list. */
export declare function projectSetDirs(fs: FileSystem, workspaceId: string, next: readonly string[]): Promise<ProjectDirsResponse>;
/** Add one directory; reject duplicates or a full list. */
export declare function projectAddDir(fs: FileSystem, workspaceId: string, path: string): Promise<{
    dirs: readonly string[];
    rejected: string | null;
}>;
