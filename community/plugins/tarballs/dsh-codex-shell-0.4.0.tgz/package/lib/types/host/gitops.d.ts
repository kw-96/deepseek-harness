/** Git operations behind the codexShell Remote, built on ctx.shell. */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { FsContentSearchResponse, GitLogResponse, GitStatusResponse } from '../types.js';
/** Porcelain-v2 status with -z framing. */
export declare function gitStatus(shell: ShellExecutor, cwd: string): Promise<GitStatusResponse>;
/** Decorated short log (subject/author/date/refs per commit). */
export declare function gitLog(shell: ShellExecutor, cwd: string, count?: number): Promise<GitLogResponse>;
/** Diff text: staged toggle or one file (plain, no pager). */
export declare function gitDiff(shell: ShellExecutor, cwd: string, path?: string, staged?: boolean): Promise<{
    text: string;
}>;
export declare function gitStage(shell: ShellExecutor, cwd: string, path?: string): Promise<{
    ok: true;
}>;
export declare function gitUnstage(shell: ShellExecutor, cwd: string, path?: string): Promise<{
    ok: true;
}>;
export declare function gitDiscard(shell: ShellExecutor, cwd: string, path: string): Promise<{
    ok: true;
}>;
export declare function gitCommit(shell: ShellExecutor, cwd: string, message: string): Promise<{
    ok: true;
}>;
export declare function gitBranches(shell: ShellExecutor, cwd: string): Promise<{
    current: string | null;
    names: readonly string[];
}>;
export declare function gitCheckout(shell: ShellExecutor, cwd: string, branch: string): Promise<{
    ok: true;
}>;
/** Content search through ripgrep when available; graceful empty result otherwise. */
export declare function searchContent(shell: ShellExecutor, root: string, query: string): Promise<FsContentSearchResponse>;
