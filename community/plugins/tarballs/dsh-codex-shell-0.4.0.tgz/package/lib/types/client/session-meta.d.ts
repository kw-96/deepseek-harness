/** Per-session pin/unread meta plus pinned summary notes, shared inside the plugin. */
export interface SessionMeta {
    pinned: boolean;
    unread: boolean;
}
export interface PinnedNote {
    id: string;
    text: string;
    at: number;
}
/**
 * A tiny store for row decorations and pinned summaries. Created in apply and
 * handed to registrants through their inject faces: local state per hook, so
 * cross-component updates are driven by the browser's refresh events instead
 * of a bespoke subscription bus.
 */
export declare class SessionMetaStore {
    private metas;
    constructor();
    meta(sessionId: string): SessionMeta;
    set(sessionId: string, patch: Partial<SessionMeta>): SessionMeta;
    notes(sessionId: string): readonly PinnedNote[];
    addNote(sessionId: string, text: string): void;
    removeNote(sessionId: string, id: string): void;
}
/** Reactive wrapper for one session's meta row. */
export declare function useSessionMeta(store: SessionMetaStore | undefined, sessionId: string | undefined): [SessionMeta, (patch: Partial<SessionMeta>) => void];
/** Reactive wrapper for one session's pinned notes. */
export declare function useSessionNotes(store: SessionMetaStore | undefined, sessionId: string | undefined): [readonly PinnedNote[], (text: string) => void, (id: string) => void];
