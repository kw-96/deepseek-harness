import type { PanelKind } from './panel-controller.js';
import type { TFn } from './faces.js';
/** 一条可切换的面板标签。 */
export interface TabBarTab {
    id: PanelKind;
    label: string;
    icon: React.ReactNode;
}
interface TabBarProps {
    tabs: readonly TabBarTab[];
    activeId: PanelKind;
    onSelect: (id: PanelKind) => void;
    onClose: () => void;
    t: TFn;
}
/**
 * 标签条组件。
 * @param tabs 全部标签（按展示优先级排列，前 5 个为主标签）
 * @param activeId 当前激活标签
 * @param onSelect 选择标签回调
 * @param onClose 关闭整个面板回调
 * @param t 文案函数
 */
export declare function TabBar({ tabs, activeId, onSelect, onClose, t }: TabBarProps): React.ReactNode;
export {};
