import type { SessionMetaStore } from './session-meta.js';
import type { HostObservableLike, RenderSlotFn, SearchResultLike, SelectorHook, SessionId, SessionListStateLike, TFn, WorkspaceSnapshotLike, WorkspaceViewLike } from './faces.js';
/** Injected share for the browser (mirrors the native WorkspaceBrowser actions). */
export interface CodexBrowserInjected {
    hooks: {
        directoryFlow: HostObservableLike<boolean>;
        hostInfo: HostObservableLike<unknown>;
    };
    startSession: (workspaceId?: string) => void;
    open: (sessionId: SessionId) => void;
    searchSessions: (query: string, signal: AbortSignal) => Promise<{
        items: readonly SearchResultLike[];
        hasMore: boolean;
    }>;
    searchResultLimit: number;
    renameSession: (sessionId: SessionId, title: string) => Promise<void>;
    forkSession: (sessionId: SessionId) => void;
    renameWorkspace: (workspaceId: string, title: string) => Promise<void>;
    deleteWorkspace: (workspaceId: string) => Promise<void>;
    insertWorkspaceBefore: (workspaceId: string, beforeWorkspaceId?: string) => Promise<void>;
    archiveSession: (sessionId: SessionId) => Promise<void>;
    insertSessionBefore: (workspaceId: string, sessionId: SessionId, beforeSessionId?: SessionId) => Promise<void>;
    createWorkspace: (input: {
        path: string;
    }) => Promise<WorkspaceViewLike>;
    meta: SessionMetaStore;
}
export interface CodexBrowserProps {
    wide: boolean;
    expandSidebar: () => void;
    useSessions: SelectorHook<SessionListStateLike>;
    useWorkspaces: SelectorHook<WorkspaceSnapshotLike>;
    useDirectoryFlow: () => boolean;
    useHostInfo: () => unknown;
    renderSlot: RenderSlotFn;
    startSession: (workspaceId?: string) => void;
    open: (sessionId: SessionId) => void;
    searchSessions: CodexBrowserInjected['searchSessions'];
    searchResultLimit: number;
    renameSession: CodexBrowserInjected['renameSession'];
    forkSession: CodexBrowserInjected['forkSession'];
    renameWorkspace: CodexBrowserInjected['renameWorkspace'];
    deleteWorkspace: CodexBrowserInjected['deleteWorkspace'];
    insertWorkspaceBefore: CodexBrowserInjected['insertWorkspaceBefore'];
    archiveSession: CodexBrowserInjected['archiveSession'];
    insertSessionBefore: CodexBrowserInjected['insertSessionBefore'];
    createWorkspace: CodexBrowserInjected['createWorkspace'];
    meta: SessionMetaStore;
    t: TFn;
}
export declare function CodexBrowser(props: CodexBrowserProps): import("react").JSX.Element;
