/** Embedded plugin manager: runtime inventory (enable/disable) + market install. */
import type { CodexMarketplace, CodexPluginManager } from '../RightPanel.js';
import type { TFn } from '../faces.js';
interface PluginsPanelProps {
    pluginManager: CodexPluginManager | undefined;
    marketplace: CodexMarketplace | undefined;
    t: TFn;
}
export declare function PluginsPanel({ pluginManager, marketplace, t }: PluginsPanelProps): import("react").JSX.Element;
export {};
