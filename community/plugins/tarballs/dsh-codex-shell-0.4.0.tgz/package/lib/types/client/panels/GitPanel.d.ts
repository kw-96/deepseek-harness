/** Git status/changes/diff/commit/branches/log tab for the Codex panel. */
import type { CodexApi } from '../RightPanel.js';
import type { TFn } from '../faces.js';
interface GitPanelProps {
    api: CodexApi;
    t: TFn;
    cwd?: string | undefined;
}
export declare function GitPanel({ api, t, cwd }: GitPanelProps): import("react").JSX.Element;
export {};
