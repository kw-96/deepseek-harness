/** Shared open/close controller for the right-edge panel and pinned summary. */
export type PanelKind = 'files' | 'git' | 'projects' | 'plugins' | 'commands' | 'summary' | 'browser';
export interface PanelState {
    open: boolean;
    tab: PanelKind;
}
/**
 * Panel visibility plus the active tab, persisted per browser. Plain class
 * created in apply and handed to registrants through inject faces; components
 * mirror it into local state through {@link usePanelState}.
 */
export declare class PanelController {
    private readonly listeners;
    private state;
    constructor();
    getSnapshot(): PanelState;
    subscribe(listener: () => void): () => void;
    toggle(tab?: PanelKind): void;
    open(tab?: PanelKind): void;
    close(): void;
    private commit;
    dispose(): void;
}
/** Reactive panel state mirror for components. */
export declare function usePanelState(panel: PanelController): [PanelState, PanelController];
