/** Embedded browser tab: URL bar + same-frame iframe. */
import type { TFn } from '../faces.js';
interface BrowserPanelProps {
    t: TFn;
}
export declare function BrowserPanel({ t }: BrowserPanelProps): import("react").JSX.Element;
export {};
