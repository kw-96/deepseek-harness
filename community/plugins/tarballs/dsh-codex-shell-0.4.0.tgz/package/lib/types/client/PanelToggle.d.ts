/** Conversation-header utility button toggling the Codex right panel. */
import type { SessionMetaStore } from './session-meta.js';
import { PanelController } from './panel-controller.js';
import type { TFn } from './faces.js';
export interface PanelToggleInjected {
    panel: PanelController;
    meta: SessionMetaStore;
}
export interface PanelToggleProps extends PanelToggleInjected {
    t: TFn;
}
export declare function PanelToggle({ panel, t }: PanelToggleProps): import("react").JSX.Element;
