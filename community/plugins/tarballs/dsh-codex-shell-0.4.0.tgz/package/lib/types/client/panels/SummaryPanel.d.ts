/** Pinned summary notes tab: key conclusions persisted per session. */
import type { SessionId, TFn } from '../faces.js';
import type { SessionMetaStore } from '../session-meta.js';
interface SummaryPanelProps {
    meta: SessionMetaStore;
    sessionId?: SessionId | undefined;
    t: TFn;
}
export declare function SummaryPanel({ meta, sessionId, t }: SummaryPanelProps): import("react").JSX.Element;
export {};
