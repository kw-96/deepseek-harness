/** Command-history tab: the session's user prompts, newest first. */
import type { SessionId, TFn } from '../faces.js';
import type { CommandPrompt } from '../RightPanel.js';
interface CommandsPanelProps {
    history: (sessionId: SessionId) => Promise<readonly CommandPrompt[]>;
    sessionId?: SessionId | undefined;
    t: TFn;
}
export declare function CommandsPanel({ history, sessionId, t }: CommandsPanelProps): import("react").JSX.Element;
export {};
