/**
 * Browser entry for dsh-codex-shell: mounts the codexShell Remote and
 * registers the Codex-styled sidebar browser, the right-edge panel overlay,
 * and the conversation-header toggle.
 *
 * Compiles against local structural faces (see faces.ts) instead of the
 * harness client type lines, which move faster than community plugins; the
 * runtime slot core still validates every name fail-loud at load.
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * Mount the Remote contribution and register all codex-shell surfaces.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
