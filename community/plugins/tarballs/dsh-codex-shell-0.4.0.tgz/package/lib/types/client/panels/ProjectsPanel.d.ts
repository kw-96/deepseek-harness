/** Additional-directory project management tab (dsh-codex-project parity). */
import type { CodexApi } from '../RightPanel.js';
import type { TFn } from '../faces.js';
interface ProjectsPanelProps {
    api: CodexApi;
    t: TFn;
    workspaceId?: string | undefined;
    workspacePath?: string | undefined;
}
export declare function ProjectsPanel({ api, t, workspaceId, workspacePath }: ProjectsPanelProps): import("react").JSX.Element;
export {};
