/** File tree + text preview + save, rooted at the session workspace. */
import type { CodexApi } from '../RightPanel.js';
import type { SessionMetaStore } from '../session-meta.js';
import type { SessionId, TFn } from '../faces.js';
interface FilesPanelProps {
    api: CodexApi;
    t: TFn;
    cwd?: string | undefined;
    workspaceTitle: string;
    sessionId?: SessionId | undefined;
    meta: SessionMetaStore;
}
declare function parentOf(path: string): string;
declare function displayName(path: string): string;
export declare function FilesPanel({ api, t, cwd, workspaceTitle, sessionId, meta }: FilesPanelProps): import("react").JSX.Element;
/** Stable import surface for panels that only need listing helpers. */
export { parentOf, displayName };
