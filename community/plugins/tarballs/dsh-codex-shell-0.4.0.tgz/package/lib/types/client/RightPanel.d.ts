/**
 * Right-edge Codex panel (shell.overlay occupant): tabbed files/git/projects/
 * plugins/commands/summary/browser surface, floating over the conversation.
 */
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { FsContentSearchResponse, FsListResponse, FsNameSearchResponse, FsReadResponse, GitBranchesResponse, GitDiffResponse, GitLogResponse, GitStatusResponse, ProjectAddDirResponse, ProjectDirsResponse } from 'dsh-codex-shell/types';
import type { SessionMetaStore } from './session-meta.js';
import { PanelController } from './panel-controller.js';
import type { SelectorHook, SessionId, SessionListStateLike, TFn, WorkspaceSnapshotLike } from './faces.js';
/** Host-facing API surface the panel tabs consume. */
export interface CodexApi {
    fsList: (path: string) => Promise<FsListResponse>;
    fsRead: (path: string, maxBytes?: number) => Promise<FsReadResponse>;
    fsWrite: (path: string, content: string) => Promise<{
        ok: true;
    }>;
    fsSearchName: (root: string, query: string) => Promise<FsNameSearchResponse>;
    fsSearchContent: (root: string, query: string) => Promise<FsContentSearchResponse>;
    gitStatus: (cwd: string) => Promise<GitStatusResponse>;
    gitLog: (cwd: string, count?: number) => Promise<GitLogResponse>;
    gitDiff: (cwd: string, path?: string, staged?: boolean) => Promise<GitDiffResponse>;
    gitStage: (cwd: string, path?: string) => Promise<{
        ok: true;
    }>;
    gitUnstage: (cwd: string, path?: string) => Promise<{
        ok: true;
    }>;
    gitDiscard: (cwd: string, path: string) => Promise<{
        ok: true;
    }>;
    gitCommit: (cwd: string, message: string) => Promise<{
        ok: true;
    }>;
    gitBranches: (cwd: string) => Promise<GitBranchesResponse>;
    gitCheckout: (cwd: string, branch: string) => Promise<{
        ok: true;
    }>;
    projectDirs: (workspaceId: string) => Promise<ProjectDirsResponse>;
    projectSetDirs: (workspaceId: string, dirs: readonly string[]) => Promise<ProjectDirsResponse>;
    projectAddDir: (workspaceId: string, path: string) => Promise<ProjectAddDirResponse>;
}
/** One inventory row projected from the plugin-manager remote. */
export interface InventoryEntryLike {
    entryId: string;
    packageName: string;
    category: string;
    description: string | null;
    enabled: boolean;
    protected: boolean;
    protectionReason: string | null;
}
export interface InventorySnapshotLike {
    entries: readonly InventoryEntryLike[];
}
/** Optional plugin-manager bundle face, probed at render time. */
export interface CodexPluginManager {
    list: () => Promise<RemoteResult<InventorySnapshotLike>>;
    setEnabled: (entryId: string, enabled: boolean) => Promise<RemoteResult<{
        snapshot: InventorySnapshotLike;
    }>>;
}
/** One installable market entry projected from the marketplace remote. */
export interface MarketEntryLike {
    displayName: {
        'zh-CN': string;
        en: string;
    };
    packageName: string | null;
    version: string | null;
    availability: string;
}
export interface MarketSnapshotLike {
    entries: readonly MarketEntryLike[];
}
/** Optional marketplace bundle face, probed at render time. */
export interface CodexMarketplace {
    list: (refresh: boolean) => Promise<RemoteResult<MarketSnapshotLike>>;
    installPlugin: (packageName: string, version: string) => Promise<RemoteResult<unknown>>;
}
/** One durable user prompt pulled from the session history. */
export interface CommandPrompt {
    seq: number;
    text: string;
}
export interface CodexPanelInjected {
    panel: PanelController;
    meta: SessionMetaStore;
    api: CodexApi;
    pluginManager: CodexPluginManager | undefined;
    marketplace: CodexMarketplace | undefined;
    history: (sessionId: SessionId) => Promise<readonly CommandPrompt[]>;
}
export interface CodexRightPanelProps extends CodexPanelInjected {
    useSessions: SelectorHook<SessionListStateLike>;
    useWorkspaces: SelectorHook<WorkspaceSnapshotLike>;
    t: TFn;
}
export declare function CodexRightPanel({ panel, meta, api, pluginManager, marketplace, history, useSessions, useWorkspaces, t, }: CodexRightPanelProps): import("react").JSX.Element | null;
