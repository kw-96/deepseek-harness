/** Shared wire types for the dsh-codex-shell Host Remote. */
import { z } from 'zod';
export type FsEntryKind = 'file' | 'directory' | 'other';
/** One direct child of a directory listing. */
export interface FsListEntry {
    name: string;
    kind: FsEntryKind;
    size: number | null;
}
export declare const fsListEntry: z.ZodReadonly<z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
    size: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>>;
export declare const fsListValue: z.ZodReadonly<z.ZodObject<{
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
        size: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const fsReadValue: z.ZodReadonly<z.ZodObject<{
    kind: z.ZodUnion<readonly [z.ZodLiteral<"missing">, z.ZodLiteral<"binary">, z.ZodLiteral<"text">]>;
    content: z.ZodString;
    size: z.ZodNumber;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const fsNameSearchValue: z.ZodReadonly<z.ZodObject<{
    matches: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        isDir: z.ZodBoolean;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const fsContentSearchValue: z.ZodReadonly<z.ZodObject<{
    matches: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        line: z.ZodNumber;
        content: z.ZodString;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const codexOk: z.ZodReadonly<z.ZodObject<{
    ok: z.ZodLiteral<true>;
}, z.core.$strip>>;
export declare const gitStatusValue: z.ZodReadonly<z.ZodObject<{
    isRepo: z.ZodBoolean;
    branch: z.ZodNullable<z.ZodString>;
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        xy: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitLogEntry: z.ZodReadonly<z.ZodObject<{
    hash: z.ZodString;
    subject: z.ZodString;
    author: z.ZodString;
    date: z.ZodString;
    refs: z.ZodString;
}, z.core.$strip>>;
export declare const gitLogValue: z.ZodReadonly<z.ZodObject<{
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        hash: z.ZodString;
        subject: z.ZodString;
        author: z.ZodString;
        date: z.ZodString;
        refs: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitBranchValue: z.ZodReadonly<z.ZodObject<{
    current: z.ZodNullable<z.ZodString>;
    names: z.ZodReadonly<z.ZodArray<z.ZodString>>;
}, z.core.$strip>>;
export declare const projectDirsValue: z.ZodReadonly<z.ZodObject<{
    dirs: z.ZodReadonly<z.ZodArray<z.ZodString>>;
}, z.core.$strip>>;
export declare const projectAddValue: z.ZodReadonly<z.ZodObject<{
    dirs: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    rejected: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>;
/** Directory listing request/response. */
export interface FsListRequest {
    path: string;
}
export interface FsListResponse {
    entries: readonly FsListEntry[];
    truncated: boolean;
}
/** Read request/response. */
export interface FsReadRequest {
    path: string;
    maxBytes?: number;
}
export interface FsReadResponse {
    kind: 'missing' | 'binary' | 'text';
    content: string;
    size: number;
    truncated: boolean;
}
export interface FsWriteRequest {
    path: string;
    content: string;
}
export interface FsWriteResponse {
    ok: true;
}
export interface FsNameSearchRequest {
    root: string;
    query: string;
}
export interface FsNameSearchResponse {
    matches: readonly {
        path: string;
        isDir: boolean;
    }[];
    truncated: boolean;
}
export interface FsContentSearchRequest {
    root: string;
    query: string;
}
export interface FsContentSearchResponse {
    matches: readonly {
        path: string;
        line: number;
        content: string;
    }[];
    truncated: boolean;
}
export interface GitStatusRequest {
    cwd: string;
}
export interface GitStatusResponse {
    isRepo: boolean;
    branch: string | null;
    entries: readonly {
        path: string;
        xy: string;
    }[];
}
export interface GitLogRequest {
    cwd: string;
    count?: number;
}
export interface GitLogResponse {
    entries: readonly {
        hash: string;
        subject: string;
        author: string;
        date: string;
        refs: string;
    }[];
}
export interface GitDiffRequest {
    cwd: string;
    path?: string;
    staged?: boolean;
}
export interface GitDiffResponse {
    text: string;
}
export interface GitSimpleRequest {
    cwd: string;
    path?: string;
}
export interface GitSimpleResponse {
    ok: true;
}
export interface GitCommitRequest {
    cwd: string;
    message: string;
}
export interface GitCommitResponse {
    ok: true;
}
export interface GitBranchesRequest {
    cwd: string;
}
export interface GitBranchesResponse {
    current: string | null;
    names: readonly string[];
}
export interface GitCheckoutRequest {
    cwd: string;
    branch: string;
}
export interface GitCheckoutResponse {
    ok: true;
}
export interface ProjectDirsRequest {
    workspaceId: string;
}
export interface ProjectDirsResponse {
    dirs: readonly string[];
}
export interface ProjectSetDirsRequest {
    workspaceId: string;
    dirs: readonly string[];
}
export interface ProjectSetDirsResponse {
    dirs: readonly string[];
}
export interface ProjectAddDirRequest {
    workspaceId: string;
    path: string;
}
export interface ProjectAddDirResponse {
    dirs: readonly string[];
    rejected: string | null;
}
