/** Host service for the dsh-codex-shell integrated Codex-style workspace shell. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { FsContentSearchResponse, FsListResponse, FsNameSearchResponse, FsReadResponse, GitBranchesResponse, GitDiffResponse, GitLogResponse, GitStatusResponse, ProjectAddDirResponse, ProjectDirsResponse } from './types.js';
export type * from './types.js';
/** codexShell Remote: filesystem, git, and per-workspace project directories for the Web shell. */
export declare class CodexShell extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    fsList(path: string): Promise<FsListResponse>;
    fsRead(path: string, maxBytes?: number): Promise<FsReadResponse>;
    fsWrite(path: string, content: string): Promise<{
        ok: true;
    }>;
    fsSearchName(root: string, query: string): Promise<FsNameSearchResponse>;
    fsSearchContent(root: string, query: string): Promise<FsContentSearchResponse>;
    gitStatus(cwd: string): Promise<GitStatusResponse>;
    gitLog(cwd: string, count?: number): Promise<GitLogResponse>;
    gitDiff(cwd: string, path?: string, staged?: boolean): Promise<GitDiffResponse>;
    gitStage(cwd: string, path?: string): Promise<{
        ok: true;
    }>;
    gitUnstage(cwd: string, path?: string): Promise<{
        ok: true;
    }>;
    gitDiscard(cwd: string, path: string): Promise<{
        ok: true;
    }>;
    gitCommit(cwd: string, message: string): Promise<{
        ok: true;
    }>;
    gitBranches(cwd: string): Promise<GitBranchesResponse>;
    gitCheckout(cwd: string, branch: string): Promise<{
        ok: true;
    }>;
    projectDirs(workspaceId: string): Promise<ProjectDirsResponse>;
    projectSetDirs(workspaceId: string, dirs: readonly string[]): Promise<ProjectDirsResponse>;
    projectAddDir(workspaceId: string, path: string): Promise<ProjectAddDirResponse>;
}
export default CodexShell;
