# dsh-codex-shell DESIGN.md

Brand contract for the codex-shell surfaces. Every component derives from
these tokens; no hardcoded hex outside this file and `styles.module.css`
token definitions.

## Mood

Codex app: dark, dense, calm. One warm-orange accent that marks the current
selection and primary actions. Hairline borders, layered surfaces, quiet
motion.

## Color tokens

| Token | Value | Use |
|---|---|---|
| `--cx-bg` | #0f1115 | canvas (sidebar root) |
| `--cx-panel-bg` | #141821 | right panel surface |
| `--cx-card-bg` | rgba(255,255,255,.03) | cards, note blocks |
| `--cx-fg` | #e8eaed | primary text |
| `--cx-fg-dim` | #aab0b8 | row text, secondary |
| `--cx-fg-tertiary` | #6b7280 | sublines, placeholders, meta |
| `--cx-line` | rgba(255,255,255,.07) | hairline borders |
| `--cx-accent` | #ef7648 | current rail, primary buttons, focus, running |
| `--cx-current` | rgba(239,118,72,.13) | current-row tint |
| `--cx-hover` | rgba(255,255,255,.06) | hover fills |
| `--cx-input` | rgba(255,255,255,.045) | inputs |
| `--cx-dot-done` | #3fb974 | completed sessions |
| `--cx-warn` | #d9a63d | warn states |
| `--cx-error` | #f06a6a | destructive actions, errors |

All tokens keep a `--dsw-*` fallback so the plugin follows the host theme.

## Typography

- Section header: 10.5px / 650 / letter-spacing .08em / uppercase
- Session title: 13px / 500; subline: 11px / 450 tertiary
- Subagent row: 12px / 450, tertiary, indented 16px with a 1px connector
- Panel body: 12.5px; code: 12px mono, line-height 1.55
- Menu items: 12.5px

## Shape, space, motion

- Radii: 8px rows/inputs · 10px cards/menus · 12px panels
- Spacing: 4px grid; row padding 6px/8px; group gap 10px
- Motion: 0.12s ease (color/background) · 0.18s cubic-bezier(.2,.8,.2,1)
  (panel slide) · 1.6s ease-in-out (running pulse)
- Current row: 2.5px accent left rail + tint; actions reveal on hover
- Focus-visible: 2px accent outline offset 2 on every control

## Semantic states

Running = accent pulse dot · completed = green dot · idle = hollow dot ·
archived = hollow dim · unread = accent badge · pinned = accent pin glyph.

## Rules

- Never redeclare `sidebar.workspaces.directoryFlow` (native owner keeps it).
- Style only through CSS Modules + `--cx-*`; never touch host globals.
- Destructive actions (discard, delete) are red and confirm first.
