/** Shared wire types for the dsh-codex-shell Host Remote. */
import { z } from 'zod';
export type FsEntryKind = 'file' | 'directory' | 'other';
/** One direct child of a directory listing. */
export interface FsListEntry {
    name: string;
    kind: FsEntryKind;
    size: number | null;
}
export declare const fsListEntry: z.ZodReadonly<z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
    size: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>>;
export declare const fsListValue: z.ZodReadonly<z.ZodObject<{
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
        size: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const fsReadValue: z.ZodReadonly<z.ZodObject<{
    kind: z.ZodUnion<readonly [z.ZodLiteral<"missing">, z.ZodLiteral<"binary">, z.ZodLiteral<"text">]>;
    content: z.ZodString;
    size: z.ZodNumber;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
/** 文件名 / 内容搜索的可选开关与路径过滤。 */
export interface FsSearchOptions {
    matchCase?: boolean;
    matchWholeWord?: boolean;
    useRegex?: boolean;
    include?: string;
    exclude?: string;
}
export declare const fsSearchOptions: z.ZodReadonly<z.ZodObject<{
    matchCase: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    matchWholeWord: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    useRegex: z.ZodOptional<z.ZodOptional<z.ZodBoolean>>;
    include: z.ZodOptional<z.ZodOptional<z.ZodString>>;
    exclude: z.ZodOptional<z.ZodOptional<z.ZodString>>;
}, z.core.$strip>>;
export declare const fsNameSearchValue: z.ZodReadonly<z.ZodObject<{
    matches: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        isDir: z.ZodBoolean;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const fsContentSearchValue: z.ZodReadonly<z.ZodObject<{
    matches: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        line: z.ZodNumber;
        content: z.ZodString;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const codexOk: z.ZodReadonly<z.ZodObject<{
    ok: z.ZodLiteral<true>;
}, z.core.$strip>>;
export declare const gitStatusValue: z.ZodReadonly<z.ZodObject<{
    isRepo: z.ZodBoolean;
    branch: z.ZodNullable<z.ZodString>;
    upstream: z.ZodNullable<z.ZodString>;
    ahead: z.ZodNumber;
    behind: z.ZodNumber;
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        path: z.ZodString;
        origPath: z.ZodNullable<z.ZodString>;
        xy: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitLogEntry: z.ZodReadonly<z.ZodObject<{
    hash: z.ZodString;
    subject: z.ZodString;
    author: z.ZodString;
    date: z.ZodString;
    refs: z.ZodString;
}, z.core.$strip>>;
export declare const gitLogValue: z.ZodReadonly<z.ZodObject<{
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        hash: z.ZodString;
        subject: z.ZodString;
        author: z.ZodString;
        date: z.ZodString;
        refs: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const gitBranchValue: z.ZodReadonly<z.ZodObject<{
    current: z.ZodNullable<z.ZodString>;
    names: z.ZodReadonly<z.ZodArray<z.ZodString>>;
}, z.core.$strip>>;
export declare const projectDirsValue: z.ZodReadonly<z.ZodObject<{
    dirs: z.ZodReadonly<z.ZodArray<z.ZodString>>;
}, z.core.$strip>>;
export declare const projectViewValue: z.ZodReadonly<z.ZodObject<{
    projectId: z.ZodString;
    name: z.ZodString;
    roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>>;
export declare const projectListValue: z.ZodReadonly<z.ZodObject<{
    projects: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        projectId: z.ZodString;
        name: z.ZodString;
        roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const projectValue: z.ZodReadonly<z.ZodObject<{
    project: z.ZodReadonly<z.ZodObject<{
        projectId: z.ZodString;
        name: z.ZodString;
        roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>>;
export declare const projectDeleteValue: z.ZodReadonly<z.ZodObject<{
    deleted: z.ZodBoolean;
}, z.core.$strip>>;
export declare const projectAddValue: z.ZodReadonly<z.ZodObject<{
    dirs: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    rejected: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>;
export declare const terminalStatusValue: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
    kind: z.ZodLiteral<"running">;
}, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
    kind: z.ZodLiteral<"exited">;
    exitCode: z.ZodNullable<z.ZodNumber>;
    signal: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>]>>;
export declare const terminalOpenOptions: z.ZodReadonly<z.ZodObject<{
    cwd: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    shellDialect: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"bash">, z.ZodLiteral<"pwsh">]>>;
    cols: z.ZodOptional<z.ZodNumber>;
    rows: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>>;
export declare const terminalOpenValue: z.ZodReadonly<z.ZodObject<{
    terminalId: z.ZodString;
    output: z.ZodString;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    name: z.ZodOptional<z.ZodString>;
    origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
}, z.core.$strip>>;
export declare const terminalListEntryValue: z.ZodReadonly<z.ZodObject<{
    terminalId: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
}, z.core.$strip>>;
export declare const terminalListValue: z.ZodReadonly<z.ZodObject<{
    terminals: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        terminalId: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
            kind: z.ZodLiteral<"running">;
        }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
            kind: z.ZodLiteral<"exited">;
            exitCode: z.ZodNullable<z.ZodNumber>;
            signal: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>]>>;
        origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const terminalSendValue: z.ZodReadonly<z.ZodObject<{
    output: z.ZodString;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    waitReason: z.ZodString;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const terminalReadValue: z.ZodReadonly<z.ZodObject<{
    output: z.ZodString;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const terminalFollowValue: z.ZodReadonly<z.ZodObject<{
    seq: z.ZodNumber;
    chunk: z.ZodString;
}, z.core.$strip>>;
export declare const terminalOkValue: z.ZodReadonly<z.ZodObject<{
    ok: z.ZodLiteral<true>;
}, z.core.$strip>>;
/** Directory listing request/response. */
export interface FsListRequest {
    path: string;
}
export interface FsListResponse {
    entries: readonly FsListEntry[];
    truncated: boolean;
}
/** Read request/response. */
export interface FsReadRequest {
    path: string;
    maxBytes?: number;
}
export interface FsReadResponse {
    kind: 'missing' | 'binary' | 'text';
    content: string;
    size: number;
    truncated: boolean;
}
export interface FsWriteRequest {
    path: string;
    content: string;
}
export interface FsWriteResponse {
    ok: true;
}
export interface FsNameSearchRequest {
    root: string;
    query: string;
    options?: FsSearchOptions;
}
export interface FsNameSearchResponse {
    matches: readonly {
        path: string;
        isDir: boolean;
    }[];
    truncated: boolean;
}
export interface FsContentSearchRequest {
    root: string;
    query: string;
    options?: FsSearchOptions;
}
export interface FsContentSearchResponse {
    matches: readonly {
        path: string;
        line: number;
        content: string;
    }[];
    truncated: boolean;
}
export interface GitStatusRequest {
    cwd: string;
}
export interface GitStatusResponse {
    isRepo: boolean;
    branch: string | null;
    upstream: string | null;
    ahead: number;
    behind: number;
    entries: readonly {
        path: string;
        origPath: string | null;
        xy: string;
    }[];
}
export interface GitLogRequest {
    cwd: string;
    count?: number;
}
export interface GitLogResponse {
    entries: readonly {
        hash: string;
        subject: string;
        author: string;
        date: string;
        refs: string;
    }[];
}
export interface GitDiffRequest {
    cwd: string;
    path?: string;
    staged?: boolean;
}
export interface GitDiffResponse {
    text: string;
}
export interface GitSimpleRequest {
    cwd: string;
    path?: string;
}
export interface GitSimpleResponse {
    ok: true;
}
export interface GitCommitRequest {
    cwd: string;
    message: string;
}
export interface GitCommitResponse {
    ok: true;
}
export interface GitBranchesRequest {
    cwd: string;
}
export interface GitBranchesResponse {
    current: string | null;
    names: readonly string[];
}
export interface GitCheckoutRequest {
    cwd: string;
    branch: string;
}
export interface GitCheckoutResponse {
    ok: true;
}
export interface ProjectDirsRequest {
    workspaceId: string;
}
export interface ProjectDirsResponse {
    dirs: readonly string[];
}
export interface ProjectSetDirsRequest {
    workspaceId: string;
    dirs: readonly string[];
}
export interface ProjectSetDirsResponse {
    dirs: readonly string[];
}
export interface ProjectAddDirRequest {
    workspaceId: string;
    path: string;
}
export interface ProjectAddDirResponse {
    dirs: readonly string[];
    rejected: string | null;
}
export interface ProjectView {
    projectId: string;
    name: string;
    roots: readonly string[];
    createdAt: string;
    updatedAt: string;
}
export interface ProjectListResponse {
    projects: readonly ProjectView[];
}
export interface ProjectCreateRequest {
    name: string;
    roots?: readonly string[];
}
export interface ProjectValue {
    project: ProjectView;
}
export interface ProjectRenameRequest {
    projectId: string;
    name: string;
}
export interface ProjectSetRootsRequest {
    projectId: string;
    roots: readonly string[];
}
export interface ProjectDeleteRequest {
    projectId: string;
}
export interface ProjectDeleteResponse {
    deleted: boolean;
}
export interface TerminalOpenOptions {
    cwd?: string;
    name?: string;
    shellDialect?: 'bash' | 'pwsh';
    cols?: number;
    rows?: number;
}
export interface TerminalOpenResponse {
    terminalId: string;
    output: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    name?: string;
    origin: 'ui' | 'agent';
}
export interface TerminalListEntry {
    terminalId: string;
    name?: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    origin: 'ui' | 'agent';
}
export interface TerminalListResponse {
    terminals: readonly TerminalListEntry[];
}
export interface TerminalSendResponse {
    output: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    waitReason: string;
    truncated: boolean;
}
export interface TerminalReadResponse {
    output: string;
    truncated: boolean;
}
/** One interactive bottom-terminal output frame. */
export interface TerminalFollowFrame {
    seq: number;
    chunk: string;
}
export interface TerminalWriteResponse {
    ok: true;
}
export interface TerminalResizeResponse {
    ok: true;
}
