/** 会话头工具按钮：一键开合右侧 Codex 面板并同步宿主 details 列。 */
import type { SessionMetaStore } from './session-meta.js';
import { PanelController } from './panel-controller.js';
import type { TFn } from './faces.js';
export interface PanelToggleInjected {
    panel: PanelController;
    meta: SessionMetaStore;
    /** 同步宿主 details 列开合（layout.openDetails / closeDetails）。 */
    setColumnOpen: (open: boolean) => void;
    /** 同步宿主 bottom 行开合。 */
    setBottomOpen: (open: boolean) => void;
}
export interface PanelToggleProps extends PanelToggleInjected {
    t: TFn;
}
export declare function PanelToggle({ panel, setColumnOpen, setBottomOpen, t }: PanelToggleProps): import("react").JSX.Element;
