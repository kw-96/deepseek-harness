import type { SessionMetaStore } from './session-meta.js';
import { type BrowserPrefsStore } from './sidebar/prefs.js';
import type { SearchResultLike, SelectorHook, SessionId, SessionListStateLike, TFn, WorkspaceSnapshotLike } from './faces.js';
/** 注入共享面。 */
export interface CodexBrowserInjected {
    startSession: (workspaceId?: string) => void;
    open: (sessionId: SessionId) => void;
    searchSessions: (query: string, signal: AbortSignal) => Promise<{
        items: readonly SearchResultLike[];
        hasMore: boolean;
    }>;
    searchResultLimit: number;
    renameSession: (sessionId: SessionId, title: string) => Promise<void>;
    forkSession: (sessionId: SessionId) => void;
    renameWorkspace: (workspaceId: string, title: string) => Promise<void>;
    deleteWorkspace: (workspaceId: string) => Promise<void>;
    insertWorkspaceBefore: (workspaceId: string, beforeWorkspaceId?: string) => Promise<void>;
    archiveSession: (sessionId: SessionId) => Promise<void>;
    insertSessionBefore: (workspaceId: string, sessionId: SessionId, beforeSessionId?: SessionId) => Promise<void>;
    attachSession: (workspaceId: string, sessionId: SessionId) => Promise<void>;
    moveSession: (workspaceId: string, sessionId: SessionId) => Promise<void>;
    detachSession: (workspaceId: string, sessionId: SessionId) => Promise<void>;
    openWorkspacePath: (path: string) => Promise<void>;
    openTerminalForSession: (sessionId: SessionId, cwd?: string) => Promise<void>;
    exportSessionMarkdown: (sessionId: SessionId) => Promise<string | null>;
    canExportMarkdown: boolean;
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
}
export interface CodexBrowserProps extends CodexBrowserInjected {
    wide: boolean;
    expandSidebar: () => void;
    useSessions: SelectorHook<SessionListStateLike>;
    useWorkspaces: SelectorHook<WorkspaceSnapshotLike>;
    t: TFn;
}
/** Codex 侧栏浏览器根组件。 */
export declare function CodexBrowser(props: CodexBrowserProps): import("react").JSX.Element;
