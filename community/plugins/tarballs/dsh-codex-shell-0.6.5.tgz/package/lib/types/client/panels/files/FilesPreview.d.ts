/** 文件面板底部文本预览与保存。 */
import type { TFn } from '../../faces.js';
export interface FilesPreviewState {
    path: string | null;
    kind: 'missing' | 'binary' | 'text';
    content: string;
    truncated: boolean;
    dirty: boolean;
    saving: boolean;
}
export interface FilesPreviewProps {
    preview: FilesPreviewState;
    onChange: (next: FilesPreviewState) => void;
    onSave: () => void;
    onClose: () => void;
    t: TFn;
}
/**
 * 文件预览区。
 * @param props 预览状态与保存/关闭回调
 */
export declare function FilesPreview({ preview, onChange, onSave, onClose, t }: FilesPreviewProps): React.ReactNode;
