/** 文件面板搜索栏：收起快搜 / 展开 VS Code 风格高级选项。 */
import type { TFn } from '../../faces.js';
import type { FilesSearchForm } from './useFilesSearch.js';
export interface FilesSearchBarProps {
    form: FilesSearchForm;
    onChange: (next: FilesSearchForm) => void;
    onReplaceAll: () => void;
    replaceBusy: boolean;
    t: TFn;
}
/**
 * 文件搜索表单。
 * @param props 表单状态与回调
 */
export declare function FilesSearchBar({ form, onChange, onReplaceAll, replaceBusy, t }: FilesSearchBarProps): React.ReactNode;
