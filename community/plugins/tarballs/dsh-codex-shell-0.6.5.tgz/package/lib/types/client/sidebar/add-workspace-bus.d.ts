/**
 * 添加工作区弹窗触发总线：标题栏「+」与页脚入口共用同一打开器。
 */
type Opener = () => void;
/** 注册打开器（页脚 AddWorkspaceAction 挂载时调用）。 */
export declare function registerAddWorkspaceOpener(next: Opener | null): void;
/** 请求打开添加工作区弹窗；未注册时无操作。 */
export declare function requestAddWorkspaceOpen(): void;
export {};
