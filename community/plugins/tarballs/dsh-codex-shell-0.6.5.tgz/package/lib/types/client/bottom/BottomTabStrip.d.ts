/** Cursor-style tab strip with shell new menu. */
import type { TFn } from '../faces.js';
import type { BottomTab, ShellDialect } from './useBottomTerminals.js';
interface BottomTabStripProps {
    tabs: readonly BottomTab[];
    activeId: string | null;
    onSelect: (id: string) => void;
    onClose: (id: string) => void;
    onCreate: (dialect: ShellDialect) => void;
    t: TFn;
}
/** 底栏 tab 条：切换、关闭、按方言新建。 */
export declare function BottomTabStrip({ tabs, activeId, onSelect, onClose, onCreate, t, }: BottomTabStripProps): React.ReactNode;
export {};
