/**
 * 项目行悬停信息侧弹窗：名称、会话数、绝对路径、编辑入口。
 */
import type { TFn } from '../faces.js';
export interface ProjectInfoProps {
    title: string;
    path: string;
    sessionCount: number;
    pinned: boolean;
    onRename: () => void;
    onTogglePin: () => void;
    t: TFn;
}
/** 工作区悬停信息卡。 */
export declare function ProjectInfoCard(props: ProjectInfoProps): React.ReactNode;
