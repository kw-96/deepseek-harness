/**
 * 侧栏行操作菜单外壳：固定定位 + 派发会话/工作区菜单体。
 */
import type { SessionId, TFn, WorkspaceViewLike } from './faces.js';
import { type SessionMenuActions } from './sidebar/session-menu.js';
import { type WorkspaceMenuActions } from './sidebar/workspace-menu.js';
export interface BrowserMenuState {
    x: number;
    y: number;
    sessionId?: SessionId;
    workspaceId?: string;
    isWorkspace: boolean;
}
export interface BrowserMenuProps {
    state: BrowserMenuState | null;
    onDismiss: () => void;
    sessionActions: ((sessionId: SessionId) => SessionMenuActions) | null;
    workspaceActions: ((workspaceId: string) => WorkspaceMenuActions) | null;
    workspaces: readonly WorkspaceViewLike[];
    sessionWorkspaceId: (sessionId: SessionId) => string | undefined;
    sessionCwd: (sessionId: SessionId) => string | undefined;
    t: TFn;
}
/** 渲染工作区或会话操作菜单；空状态返回 null。 */
export declare function BrowserMenu(props: BrowserMenuProps): React.ReactNode;
