/** 文件树 + 可收起/展开的工作区搜索，根目录为会话工作区。 */
import type { CodexApi } from '../../RightPanel.js';
import type { SessionMetaStore } from '../../session-meta.js';
import type { SessionId, TFn } from '../../faces.js';
interface FilesPanelProps {
    api: CodexApi;
    t: TFn;
    cwd?: string | undefined;
    workspaceTitle: string;
    sessionId?: SessionId | undefined;
    meta: SessionMetaStore;
}
/**
 * 右侧文件面板。
 * @param props API、文案与会话工作目录
 */
export declare function FilesPanel({ api, t, cwd, workspaceTitle }: FilesPanelProps): React.ReactNode;
export {};
