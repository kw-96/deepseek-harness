/** 文件面板搜索状态：防抖调用文件名与内容搜索，并支持字面量批量替换。 */
import type { CodexApi } from '../../RightPanel.js';
import type { FsSearchOptions } from 'dsh-codex-shell/types';
export interface FilesSearchForm {
    query: string;
    replace: string;
    include: string;
    exclude: string;
    matchCase: boolean;
    matchWholeWord: boolean;
    useRegex: boolean;
    expanded: boolean;
}
export interface FilesSearchState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    nameMatches: readonly {
        path: string;
        isDir: boolean;
    }[];
    contentMatches: readonly {
        path: string;
        line: number;
        content: string;
    }[];
    truncated: boolean;
    error: string | null;
    replaceMessage: string | null;
}
/**
 * 把表单映射为 Host 搜索选项。
 * @param form 搜索表单
 */
export declare function toSearchOptions(form: FilesSearchForm): FsSearchOptions;
/**
 * 文件面板搜索 hook。
 * @param api codexShell API
 * @param root 工作区根路径
 * @param form 搜索表单
 * @returns 搜索状态与字面量替换动作
 */
export declare function useFilesSearch(api: CodexApi, root: string, form: FilesSearchForm): {
    search: FilesSearchState;
    replaceAll: () => Promise<void>;
};
