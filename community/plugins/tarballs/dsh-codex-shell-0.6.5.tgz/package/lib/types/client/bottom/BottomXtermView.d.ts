/** Single-tab xterm view: follow / write / resize; stays mounted when hidden. */
import '@xterm/xterm/css/xterm.css';
import type { CodexApi } from '../RightPanel.js';
import type { TFn } from '../faces.js';
import type { BottomTab } from './useBottomTerminals.js';
interface BottomXtermViewProps {
    api: CodexApi;
    sessionId: string;
    tab: BottomTab;
    active: boolean;
    t: TFn;
    onBusy?: (message: string) => void;
}
/** 单个底栏 tab 的 xterm 宿主；非活跃时仍 follow，仅隐藏 DOM。 */
export declare function BottomXtermView({ api, sessionId, tab, active, t, onBusy, }: BottomXtermViewProps): React.ReactNode;
export {};
