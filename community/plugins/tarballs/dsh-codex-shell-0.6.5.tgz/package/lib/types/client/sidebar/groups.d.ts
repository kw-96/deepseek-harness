/**
 * 侧栏分组投影：按整理/排序偏好产出 grouped / flat / archived。
 */
import type { SessionMetaStore } from '../session-meta.js';
import type { BrowserPrefsStore, OrganizeMode, SortMode } from './prefs.js';
import type { SessionId, SessionListStateLike, WorkspaceViewLike } from '../faces.js';
import type { GroupsModel } from '../browser-tree.js';
export interface BuildGroupsInput {
    list: SessionListStateLike;
    workspaces: readonly WorkspaceViewLike[];
    archivedIds: readonly SessionId[];
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
    organize: OrganizeMode;
    sort: SortMode;
}
/** 按偏好构建侧栏分组模型。 */
export declare function buildGroupsModel(input: BuildGroupsInput): GroupsModel;
