/**
 * 侧栏会话行（Codex 式）：标题 + 悬停显露相对时间与置顶/归档/更多；
 * 置顶/未读角标常驻；运行中会话点亮点。
 */
import type { SessionMetaStore } from './session-meta.js';
import type { SessionId, TFn } from './faces.js';
/** 一条嵌套子代理行的持久事实。 */
export interface SubagentLike {
    id: SessionId;
    title: string;
    current: boolean;
    running: boolean;
}
export interface SessionRowProps {
    sessionId: SessionId;
    title: string;
    timeLabel: string;
    cwd?: string | undefined;
    current: boolean;
    running: boolean;
    archived: boolean;
    subagents: readonly SubagentLike[];
    expanded: boolean;
    onToggleSubagents: () => void;
    renaming: boolean;
    renameDraft: string;
    setRenameDraft: (value: string) => void;
    commitRename: () => void;
    onOpen: () => void;
    onMenu: (event: React.MouseEvent) => void;
    onArchive: () => void;
    draggable: boolean;
    onDragStart?: (event: React.DragEvent) => void;
    onDragOver?: (event: React.DragEvent) => void;
    onDrop?: (event: React.DragEvent) => void;
    meta: SessionMetaStore;
    open: (sessionId: SessionId) => void;
    t: TFn;
}
/** 一条顶层会话行 + 其子代理子树。 */
export declare function SessionRow(props: SessionRowProps): React.ReactNode;
