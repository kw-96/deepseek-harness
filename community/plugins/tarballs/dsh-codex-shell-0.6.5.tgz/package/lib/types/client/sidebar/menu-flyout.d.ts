/**
 * 可嵌套菜单原语：主项、禁用项、悬停展开的子菜单飞出层。
 */
import type { TFn } from '../faces.js';
export interface MenuItemProps {
    label: string;
    icon?: React.ReactNode;
    danger?: boolean;
    disabled?: boolean;
    disabledReason?: string;
    onClick?: () => void;
    trailing?: React.ReactNode;
}
/** 单条菜单项；禁用时显示 title 说明原因。 */
export declare function MenuItem(props: MenuItemProps): React.ReactNode;
export interface SubmenuProps {
    label: string;
    icon?: React.ReactNode;
    children: React.ReactNode;
    t: TFn;
}
/** 点击或悬停均可展开的右侧子菜单。 */
export declare function Submenu(props: SubmenuProps): React.ReactNode;
/** 菜单分隔线。 */
export declare function MenuSep(): React.ReactNode;
