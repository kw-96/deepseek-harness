/**
 * 项目（工作区）更多菜单：置顶/编辑/资源管理器/归档组内会话/移除；
 * 「创建永久工作树」禁用并说明。
 */
import type { TFn } from '../faces.js';
/** 工作区菜单动作。 */
export interface WorkspaceMenuActions {
    togglePin(): void;
    rename(): void;
    openInExplorer(): void;
    archiveAllSessions(): void;
    deleteWorkspace(): void;
    startSession(): void;
    pinned: boolean;
}
export interface WorkspaceMenuProps {
    actions: WorkspaceMenuActions;
    t: TFn;
}
/** 渲染工作区菜单内容。 */
export declare function WorkspaceMenuBody(props: WorkspaceMenuProps): React.ReactNode;
