/** 文件搜索结果列表：文件名命中与内容命中分组展示。 */
import type { TFn } from '../../faces.js';
import type { FilesSearchState } from './useFilesSearch.js';
export interface FilesSearchResultsProps {
    search: FilesSearchState;
    root: string;
    onOpen: (path: string, isDir: boolean) => void;
    t: TFn;
    replaceLabel: string | null;
}
/**
 * 将相对路径解析为绝对路径（内容搜索常返回仓内相对路径）。
 * @param root 工作区根
 * @param path 命中路径
 */
export declare function resolveHitPath(root: string, path: string): string;
/**
 * 搜索结果面板。
 * @param props 搜索状态与打开回调
 */
export declare function FilesSearchResults({ search, root, onOpen, t, replaceLabel, }: FilesSearchResultsProps): React.ReactNode;
