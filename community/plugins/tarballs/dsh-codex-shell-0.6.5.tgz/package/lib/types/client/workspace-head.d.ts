/**
 * 工作区（项目）标题行：折叠、重命名、悬停更多/重命名、信息侧弹窗。
 */
import type { TFn } from './faces.js';
export interface WorkspaceHeadProps {
    label: string;
    path: string;
    sessionCount: number;
    pinned: boolean;
    collapsed: boolean;
    renaming: boolean;
    renameDraft: string;
    setRenameDraft: (value: string) => void;
    commitRename: () => void;
    onToggle: () => void;
    onMenu: (event: React.MouseEvent) => void;
    onBeginRename: () => void;
    onTogglePin: () => void;
    t: TFn;
}
/** 项目行头部。 */
export declare function WorkspaceHead(props: WorkspaceHeadProps): React.ReactNode;
