/**
 * 侧栏整理/排序偏好与项目置顶：独立于 SessionMeta 的 localStorage 仓。
 */
/** 侧栏整理：按项目分组，或扁平单列表。 */
export type OrganizeMode = 'byProject' | 'flat';
/** 聊天排序：置顶优先 / 最近更新 / 手动拖拽。 */
export type SortMode = 'pinnedFirst' | 'recent' | 'manual';
/**
 * 侧栏浏览器偏好仓。
 * 与 SessionMeta 分键，避免 meta 版本迁移误伤整理偏好。
 */
export declare class BrowserPrefsStore {
    private data;
    constructor();
    /** 当前整理模式。 */
    get organize(): OrganizeMode;
    /** 当前排序模式。 */
    get sort(): SortMode;
    /** 某工作区是否本地置顶。 */
    workspacePinned(workspaceId: string): boolean;
    /** 写入整理模式。 */
    setOrganize(mode: OrganizeMode): void;
    /** 写入排序模式。 */
    setSort(mode: SortMode): void;
    /** 切换工作区本地置顶。 */
    setWorkspacePinned(workspaceId: string, pinned: boolean): void;
    private persist;
}
/** 订阅偏好变更（组件内本地快照）。 */
export declare function useBrowserPrefs(store: BrowserPrefsStore): [
    {
        organize: OrganizeMode;
        sort: SortMode;
    },
    (patch: Partial<{
        organize: OrganizeMode;
        sort: SortMode;
    }>) => void
];
