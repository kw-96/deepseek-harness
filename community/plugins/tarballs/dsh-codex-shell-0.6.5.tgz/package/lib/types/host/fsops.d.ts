/** Filesystem operations behind the codexShell Remote, built on ctx.fs. */
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { FsListResponse, FsNameSearchResponse, FsReadResponse, FsSearchOptions } from '../types.js';
/** List one directory through the fs service. */
export declare function listDirectory(fs: FileSystem, path: string): Promise<FsListResponse>;
/** Read one file as text through the fs service, with size caps. */
export declare function readTextFile(fs: FileSystem, path: string, maxBytes?: number): Promise<FsReadResponse>;
/** Write one file through the fs service. */
export declare function writeTextFile(fs: FileSystem, path: string, content: string): Promise<{
    ok: true;
}>;
/**
 * 递归按文件名搜索；跳过依赖/VCS 目录，并应用可选大小写与路径过滤。
 * @param fs 文件系统服务
 * @param root 搜索根目录
 * @param query 文件名子串
 * @param options 大小写与 include/exclude
 */
export declare function searchNames(fs: FileSystem, root: string, query: string, options?: FsSearchOptions): Promise<FsNameSearchResponse>;
