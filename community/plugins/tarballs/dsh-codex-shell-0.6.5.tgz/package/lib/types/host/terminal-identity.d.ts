/** UI vs Agent terminal naming helpers for the bottom panel. */
/** Classify a PTY by its owner-local name prefix. */
export declare function terminalOrigin(name: string | undefined): 'ui' | 'agent';
/**
 * Mint the next unused UI tab name for one dialect.
 * @param taken - names already reserved or published for this owner.
 * @param dialect - shell dialect encoded in the name.
 */
export declare function mintUiTerminalName(taken: ReadonlySet<string>, dialect: 'bash' | 'pwsh'): string;
