/** Git operations behind the codexShell Remote, built on ctx.shell. */
import type { ShellExecutor } from '@deepseek-ai/dsh-shell';
import type { FsContentSearchResponse, FsSearchOptions, GitLogResponse, GitStatusResponse } from '../types.js';
/** 一条 porcelain-v2 状态条目（重命名带原路径）。 */
export interface PorcelainEntry {
    path: string;
    origPath: string | null;
    xy: string;
}
/** porcelain-v2 解析结果：分支/上下游计数 + 条目列表。 */
export interface PorcelainStatus {
    branch: string | null;
    upstream: string | null;
    ahead: number;
    behind: number;
    entries: PorcelainEntry[];
}
/**
 * 把 `git status --porcelain=v2 -z --branch` 输出解析成结构化状态。
 * 覆盖三类条目帧（`1 `/`2 `/`u ` 变更与未合并、`? ` 未跟踪），并读取
 * `# branch.head/upstream/ab` 头帧。
 * @param raw 原始输出（含 \0 分帧）
 * @returns 结构化状态
 */
export declare function parsePorcelainV2(raw: string): PorcelainStatus;
/** Porcelain-v2 status with -z framing. */
export declare function gitStatus(shell: ShellExecutor, cwd: string): Promise<GitStatusResponse>;
/** Decorated short log (subject/author/date/refs per commit). */
export declare function gitLog(shell: ShellExecutor, cwd: string, count?: number): Promise<GitLogResponse>;
/** Diff text: staged toggle or one file (plain, no pager). */
export declare function gitDiff(shell: ShellExecutor, cwd: string, path?: string, staged?: boolean): Promise<{
    text: string;
}>;
export declare function gitStage(shell: ShellExecutor, cwd: string, path?: string): Promise<{
    ok: true;
}>;
export declare function gitUnstage(shell: ShellExecutor, cwd: string, path?: string): Promise<{
    ok: true;
}>;
export declare function gitDiscard(shell: ShellExecutor, cwd: string, path: string): Promise<{
    ok: true;
}>;
export declare function gitCommit(shell: ShellExecutor, cwd: string, message: string): Promise<{
    ok: true;
}>;
export declare function gitBranches(shell: ShellExecutor, cwd: string): Promise<{
    current: string | null;
    names: readonly string[];
}>;
export declare function gitCheckout(shell: ShellExecutor, cwd: string, branch: string): Promise<{
    ok: true;
}>;
/** 抓取全部远程（含清理已删除的远端分支）。 */
export declare function gitFetch(shell: ShellExecutor, cwd: string): Promise<{
    ok: true;
}>;
/** 拉取并 fast-forward 合并当前分支。 */
export declare function gitPull(shell: ShellExecutor, cwd: string): Promise<{
    ok: true;
}>;
/** 推送当前分支到已配置的上游。 */
export declare function gitPush(shell: ShellExecutor, cwd: string): Promise<{
    ok: true;
}>;
/** 暂存全部改动（含未跟踪文件）。 */
export declare function gitStageAll(shell: ShellExecutor, cwd: string): Promise<{
    ok: true;
}>;
/** 取消全部暂存（索引重置回 HEAD）。 */
export declare function gitUnstageAll(shell: ShellExecutor, cwd: string): Promise<{
    ok: true;
}>;
/**
 * 通过 `git grep` 做内容搜索；失败时返回空结果。
 * @param shell shell 执行器
 * @param root 仓库工作目录
 * @param query 搜索串
 * @param options 大小写/整词/正则与路径过滤
 */
export declare function searchContent(shell: ShellExecutor, root: string, query: string, options?: FsSearchOptions): Promise<FsContentSearchResponse>;
