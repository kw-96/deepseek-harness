/** 逗号分隔的简易 glob：支持 `*`、`?`、`**`，路径统一为正斜杠。 */
/** 把路径统一成 `/` 分隔，便于与 VS Code 式 glob 对齐。 */
export declare function normalizePosix(path: string): string;
/** 拆分包含/排除输入为独立 glob 片段。 */
export declare function splitGlobs(raw: string | undefined): readonly string[];
/**
 * 判断相对路径是否命中包含/排除规则。
 * @param relativePath 相对工作区根的路径
 * @param include 包含 glob（空表示全部）
 * @param exclude 排除 glob
 */
export declare function pathAllowed(relativePath: string, include: string | undefined, exclude: string | undefined): boolean;
/**
 * 为 `git grep` 构造 pathspec（include 正选 + `:(exclude)`）。
 * @returns 追加在 `--` 之后的 pathspec 列表；无过滤时为 `['.']`
 */
export declare function grepPathspecs(include: string | undefined, exclude: string | undefined): readonly string[];
