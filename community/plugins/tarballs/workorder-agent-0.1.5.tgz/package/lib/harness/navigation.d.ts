/**
 * 侧边栏入口脚本，不含 script 标签，供 webserver/index-inject 使用。
 *
 * 入口渲染在官方侧边栏的页脚动作容器里（与「检查更新」「远程访问」同一排）：
 * 宽态是图标 + 文字胶囊，轨道态是单独的图标按钮；宽度形态跟着同排动作的
 * `data-wide` 走，不自己判断断点。
 *
 * `mount()` 只能在该属性真的要变时写 `data-wide`：observer 也在监听它，
 * 同值写入仍会派发 attribute 记录，会让 observer 与 `mount()` 互相触发成死循环。
 * @returns 可内联的经典脚本正文
 */
export declare function controlPanelNavigationScript(): string;
/**
 * 将控制面入口注入 HTML，供测试与兼容旧索引变换调用。
 * @param html 原始 HTML
 * @returns 注入侧边栏脚本后的 HTML
 */
export declare function injectControlPanelNavigation(html: string): string;
