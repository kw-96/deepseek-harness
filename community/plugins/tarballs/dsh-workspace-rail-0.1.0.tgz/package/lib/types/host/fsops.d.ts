/** Filesystem operations behind the codexShell Remote, built on ctx.fs. */
import type { FileSystem } from '@deepseek-ai/dsh-fs';
import type { FsListResponse } from '../types.js';
/** List one directory through the fs service (the workspace picker's browse step). */
export declare function listDirectory(fs: FileSystem, path: string): Promise<FsListResponse>;
