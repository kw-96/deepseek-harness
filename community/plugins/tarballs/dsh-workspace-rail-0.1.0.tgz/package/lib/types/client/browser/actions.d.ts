/**
 * 浏览器动作构造：会话/工作区菜单的动作与其依赖装配。
 * 组件在渲染时调用这些工厂，工厂闭包读取当时的快照与偏好；
 * 项目相关的动作与归并在 project-actions。
 */
import type { ProjectView, SessionId, SessionListStateLike, TFn, WorkspaceViewLike } from '../faces.js';
import type { SessionMetaStore } from '../state/session-meta.js';
import type { BrowserPrefsStore } from '../state/prefs.js';
import type { SessionMenuActions } from '../overlays/session-menu.js';
import type { WorkspaceMenuActions } from '../overlays/workspace-menu.js';
import type { CodexBrowserProps } from './browser-types.js';
import type { RenameController } from './use-browser-effects.js';
/** 动作工厂共享的依赖：当次渲染的快照、仓、注入回调与局部状态写入。 */
export interface BrowserActionDeps {
    list: SessionListStateLike;
    workspaces: readonly WorkspaceViewLike[];
    projects: readonly ProjectView[];
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
    t: TFn;
    /** 关闭菜单。 */
    closeMenu: () => void;
    /** 触发一次重渲染（置顶/未读等本地装饰改变后）。 */
    bump: () => void;
    refreshProjects: () => Promise<void>;
    beginSessionRename: (sessionId: SessionId, title: string) => void;
    beginWorkspaceRename: (workspaceId: string, title: string) => void;
    setWorktreeProjectId: (projectId: string | null) => void;
    startSession: (workspaceId?: string) => void;
    forkSession: (sessionId: SessionId) => void;
    renameSession: (sessionId: SessionId, title: string) => Promise<void>;
    renameWorkspace: (workspaceId: string, title: string) => Promise<void>;
    renameProject: (projectId: string, name: string) => Promise<{
        project: ProjectView;
    }>;
    deleteProject: (projectId: string) => Promise<{
        deleted: boolean;
    }>;
    deleteWorkspace: (workspaceId: string) => Promise<void>;
    archiveSession: (sessionId: SessionId) => Promise<void>;
    moveSession: (workspaceId: string, sessionId: SessionId) => Promise<void>;
    detachSession: (workspaceId: string, sessionId: SessionId) => Promise<void>;
    createWorkspace: (input: {
        path: string;
    }) => Promise<{
        workspaceId: string;
        path: string;
    }>;
    setProjectRoots: (projectId: string, roots: readonly string[]) => Promise<{
        project: ProjectView;
    }>;
    openWorkspacePath: (path: string) => Promise<void>;
    openTerminalForSession: (sessionId: SessionId, cwd?: string) => Promise<void>;
    hasTerminal: () => boolean;
    exportSessionMarkdown: (sessionId: SessionId) => Promise<string | null>;
    canExportMarkdown: boolean;
}
/** 装配动作依赖：组件属性 + 当次渲染的快照 + 局部状态写入。 */
export interface ActionDepsInput {
    props: CodexBrowserProps;
    list: SessionListStateLike;
    workspaces: readonly WorkspaceViewLike[];
    projects: readonly ProjectView[];
    rename: RenameController;
    closeMenu: () => void;
    bump: () => void;
    refreshProjects: () => Promise<void>;
    setWorktreeProjectId: (projectId: string | null) => void;
}
/**
 * 由组件属性与当次渲染状态装配动作依赖。
 * @param input - 属性、快照、重命名控制器与局部状态写入。
 * @returns 供三个动作工厂共享的依赖包。
 */
export declare function buildActionDeps(input: ActionDepsInput): BrowserActionDeps;
/**
 * 会话「更多」菜单的动作。
 * @param deps - 动作依赖。
 * @param sessionId - 目标会话。
 */
export declare function buildSessionActions(deps: BrowserActionDeps, sessionId: SessionId): SessionMenuActions;
/**
 * 工作区行「更多」菜单的动作。
 * @param deps - 动作依赖。
 * @param workspaceId - 目标工作区。
 */
export declare function buildWorkspaceActions(deps: BrowserActionDeps, workspaceId: string): WorkspaceMenuActions;
