/**
 * 侧栏工作区/会话浏览器：Codex 式搜索、项目标题栏、分组树与浮层装配。
 * 契约在 browser-types，动作在 actions/project-actions，副作用与重命名状态在
 * use-browser-effects，外壳在 chrome，分组渲染件在 parts/tree-parts。
 */
import type { CodexBrowserProps } from './browser-types.js';
export type { CodexBrowserInjected, CodexBrowserProps } from './browser-types.js';
/** Codex 侧栏浏览器根组件。 */
export declare function CodexBrowser(props: CodexBrowserProps): import("react").JSX.Element;
