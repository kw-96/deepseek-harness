/** 树体的展示件：项目组、工作区组、归档/未分组桶、搜索结果与空态。 */
import type { ProjectView, SearchResultLike, SessionId, SessionListStateLike, TFn, WorkspaceViewLike } from '../../faces.js';
/** 会话行渲染器：由树体提供（含重命名、拖拽与菜单绑定）。 */
export type RowRenderer = (sessionId: SessionId, archived?: boolean, workspaceId?: string) => React.ReactNode;
/** 归档桶与未分组桶共用的折叠标题行。 */
export declare function BucketGroup(props: {
    label: string;
    rows: readonly SessionId[];
    collapsed: boolean;
    archived?: boolean;
    onToggle: () => void;
    renderRow: RowRenderer;
}): React.ReactNode;
/** 工作区组：名称行（可重命名、置顶、菜单）与组内会话行。 */
export declare function WorkspaceGroup(props: {
    workspace: WorkspaceViewLike;
    sessions: readonly SessionId[];
    list: SessionListStateLike;
    collapsed: boolean;
    pinned: boolean;
    renaming: boolean;
    renameDraft: string;
    setRenameDraft: (value: string) => void;
    commitRename: () => void;
    onToggle: () => void;
    onMenu: (event: React.MouseEvent) => void;
    onBeginRename: () => void;
    onTogglePin: () => void;
    renderRow: RowRenderer;
    t: TFn;
}): React.ReactNode;
/** 项目组：项目名称行（文件夹图标 + 名称 + 运行标记 + 动作按钮）与组内会话行。 */
export declare function ProjectGroup(props: {
    project: ProjectView;
    sessionRows: React.ReactNode;
    workspaceId: string | undefined;
    collapsed: boolean;
    pinned: boolean;
    running: boolean;
    onToggle: () => void;
    onTogglePin: () => void;
    onNewSession: (workspaceId: string) => void;
    onMenu: (event: React.MouseEvent, projectId: string) => void;
    t: TFn;
}): React.ReactNode;
/** 搜索结果列表（标题 + 摘要，点击打开会话）。 */
export declare function SearchResults(props: {
    loading: boolean;
    items: readonly SearchResultLike[];
    list: SessionListStateLike;
    onOpen: (sessionId: SessionId) => void;
    t: TFn;
}): React.ReactNode;
/** 空态：还没有任何会话时的引导。 */
export declare function EmptyTree(props: {
    t: TFn;
}): React.ReactNode;
