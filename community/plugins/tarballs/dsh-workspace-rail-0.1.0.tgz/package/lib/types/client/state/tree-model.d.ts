/** 项目视图的行模型：把工作区分组投影成项目行（纯数据，不产生 JSX）。 */
import type { ProjectView, SessionId, SessionListStateLike } from '../faces.js';
import type { SessionMetaStore } from './session-meta.js';
import type { BrowserPrefsStore, SortMode } from './prefs.js';
import { type GroupsModel } from './groups.js';
/** 一个项目行：排序后的组内会话与新建会话的落点工作区。 */
export interface ProjectRow {
    project: ProjectView;
    sessionIds: readonly SessionId[];
    /** 项目首个归属工作区；没有归属工作区时为 undefined（不渲染新建会话按钮）。 */
    workspaceId: string | undefined;
}
/** 项目视图的整体行模型。 */
export interface ProjectRowsModel {
    projects: readonly ProjectRow[];
    /** 不属于任何项目的会话（已按当前排序模式重排）。 */
    ungrouped: readonly SessionId[];
}
/**
 * 按项目归组会话并排序。
 * @param input - 工作区分组、项目注册表、会话快照、元数据仓、偏好仓与当前排序模式。
 * @returns 项目行（含没有会话的项目）与未分组会话。
 */
export declare function buildProjectRows(input: {
    groups: GroupsModel;
    projects: readonly ProjectView[];
    list: SessionListStateLike;
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
    sort: SortMode;
}): ProjectRowsModel;
