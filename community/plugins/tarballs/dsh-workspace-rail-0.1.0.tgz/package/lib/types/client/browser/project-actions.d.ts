/**
 * 项目相关的动作：会话归属解析、项目归并动作与项目行菜单。
 */
import type { ProjectView, SessionId, WorkspaceViewLike } from '../faces.js';
import type { ProjectMenuActions } from '../overlays/project-menu.js';
import type { BrowserActionDeps } from './actions.js';
/** 会话所属工作区 id。 */
export declare function sessionWorkspaceId(workspaces: readonly WorkspaceViewLike[], sessionId: SessionId): string | undefined;
/** 项目下所有会话：按项目 roots 前缀命中的工作区汇总。 */
export declare function projectSessionIds(workspaces: readonly WorkspaceViewLike[], projects: readonly ProjectView[], projectId: string): readonly SessionId[];
/**
 * 把会话归并到项目：确保它挂在该项目下的工作区里。
 * 1) 项目下已有一个工作区与会话目录一致 → 直接移入（真正的多工作树命中）；
 * 2) 否则落入项目基本盘（首个归属工作区）；
 * 3) 项目还没有任何工作区时，以会话目录补建工作区并纳入项目 roots，再移入。
 * @param deps - 动作依赖（会话快照、工作区、项目与写入动作）。
 * @param sessionId - 待归并的会话。
 * @param projectId - 目标项目。
 */
export declare function moveSessionToProject(deps: BrowserActionDeps, sessionId: SessionId, projectId: string): Promise<void>;
/**
 * 项目行「更多」菜单的动作。
 * @param deps - 动作依赖。
 * @param projectId - 目标项目。
 */
export declare function buildProjectActions(deps: BrowserActionDeps, projectId: string): ProjectMenuActions;
