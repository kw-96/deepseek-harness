/** Failure-safe localStorage persistence for codex-shell preferences. */
import { type Dispatch, type SetStateAction } from 'react';
/** Read one serialized preference, falling back on failure. */
export declare function readPersisted<T>(key: string, fallback: T, deserialize?: (raw: string) => T): T;
/** Write one serialized preference; failures are silent (preferences only). */
export declare function writePersisted(key: string, value: string): void;
/** React state backed by localStorage. */
export declare function usePersistedState<T>(key: string, fallback: T): [T, Dispatch<SetStateAction<T>>];
