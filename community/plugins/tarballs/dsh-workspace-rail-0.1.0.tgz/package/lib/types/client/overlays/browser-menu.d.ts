/**
 * 侧栏行操作菜单外壳：固定定位 + 按 kind 派发会话/工作区/项目菜单体。
 */
import type { ProjectView, SessionId, TFn } from '../faces.js';
import { type SessionMenuActions } from './session-menu.js';
import { type WorkspaceMenuActions } from './workspace-menu.js';
import { type ProjectMenuActions } from './project-menu.js';
/** 菜单目标：行类型判别值 + 该行身份。 */
export type BrowserMenuTarget = {
    kind: 'workspace';
    workspaceId: string;
} | {
    kind: 'session';
    sessionId: SessionId;
} | {
    kind: 'project';
    projectId: string;
};
export type BrowserMenuState = BrowserMenuTarget & {
    x: number;
    y: number;
};
export interface BrowserMenuProps {
    state: BrowserMenuState | null;
    onDismiss: () => void;
    sessionActions: ((sessionId: SessionId) => SessionMenuActions) | null;
    workspaceActions: ((workspaceId: string) => WorkspaceMenuActions) | null;
    projectActions: ((projectId: string) => ProjectMenuActions) | null;
    projects: readonly ProjectView[];
    sessionProjectId: (sessionId: SessionId) => string | undefined;
    sessionCwd: (sessionId: SessionId) => string | undefined;
    /** 项目名（项目菜单提示行）。 */
    projectName: (projectId: string) => string;
    t: TFn;
}
/** 渲染工作区/会话/项目操作菜单；空状态返回 null。 */
export declare function BrowserMenu(props: BrowserMenuProps): React.ReactNode;
