/** 会话搜索的防抖、取消与最新请求保护。 */
import type { SearchResultLike } from '../faces.js';
/** 侧栏搜索的渲染状态。 */
export interface SessionSearchState {
    query: string;
    items: readonly SearchResultLike[];
    loading: boolean;
}
/**
 * 管理会话全文搜索，避免每个按键都留下无法取消的远端请求。
 * @param searchSessions 会话搜索远端调用。
 * @returns 搜索状态、输入处理器和清空操作。
 */
export declare function useSessionSearch(searchSessions: (query: string, signal: AbortSignal) => Promise<{
    items: readonly SearchResultLike[];
    hasMore: boolean;
}>): {
    search: SessionSearchState;
    setQuery: (value: string) => void;
    clear: () => void;
};
