/**
 * 注入面工厂：把 apply 闭包里的服务组装成各槽位组件需要的业务回调。
 *
 * 槽位框架按注册项缓存 inject 结果，所以这里返回的闭包必须自己读取可能
 * 后挂载的服务（例如底栏终端插件 dsh-codex-shell 的 remote），不能在
 * 工厂里一次性求值成布尔值。
 */
import type { SessionMetaStore } from './state/session-meta.js';
import type { BrowserPrefsStore } from './state/prefs.js';
import type { AddWorkspaceInjected } from './overlays/workspace-picker.js';
import type { ProjectPickerInjected } from './overlays/hero-picker.js';
import type { CodexBrowserInjected } from './browser/WorkspaceBrowser.js';
import type { CodexLeftRemoteFace, LayoutFace, RemoteResult, SessionsFace, TerminalOpenFace, WorkspacesFace } from './faces.js';
/** 会话面板的工作区打开动作（宿主 session remote 的可选方法）。 */
export interface OpenWorkspacePathFace {
    openWorkspacePath?: (request: {
        path: string;
    }) => Promise<{
        ok: boolean;
        error?: {
            message: string;
        };
    }>;
}
/** apply 交给注入面工厂的依赖包。 */
export interface CodexLeftDeps {
    sessions: SessionsFace;
    workspaces: WorkspacesFace;
    codexLeft: CodexLeftRemoteFace;
    sessionRemote: OpenWorkspacePathFace | undefined;
    connection: unknown;
    layout: LayoutFace | undefined;
    /** 底栏终端插件的 remote；未安装 dsh-codex-shell 时返回 undefined。 */
    terminal: () => TerminalOpenFace | undefined;
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
}
/**
 * 解开 Remote 结果，失败时抛出错误。
 * @param result - Remote 调用返回的结果联合。
 * @returns 成功时的值。
 */
export declare function unwrap<T>(result: RemoteResult<T>): T;
/** 侧栏浏览器（sidebar.workspaces）的注入面。 */
export declare function createBrowserInject(deps: CodexLeftDeps): CodexBrowserInjected;
/** 添加工作区弹窗（sidebar.footer.action）的注入面。 */
export declare function createAddWorkspaceInject(deps: CodexLeftDeps): AddWorkspaceInjected;
/** 新建会话页项目选择器（conversation.hero.workspace）的注入面。 */
export declare function createHeroInject(deps: CodexLeftDeps): ProjectPickerInjected;
