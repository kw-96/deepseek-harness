/** 浏览器副作用与局部状态：自动归档扫描、展开后聚焦搜索与会话/工作区重命名。 */
import type { RefObject } from 'react';
import type { SessionId, SessionListStateLike } from '../faces.js';
import type { BrowserPrefsStore } from '../state/prefs.js';
/**
 * 自动归档：会话超过阈值天数无活动即归档。运行中、当前选中、空白占位、
 * 子代理会话与已归档项都不动；阈值 0 表示关闭。
 * @param input - 会话快照、已归档集合、阈值天数与归档动作。
 */
export declare function useAutoArchive(input: {
    list: SessionListStateLike;
    archivedIds: readonly SessionId[];
    days: number;
    archiveSession: (sessionId: SessionId) => Promise<void>;
}): void;
/**
 * 展开侧栏后聚焦搜索框：等壳体滑动结束再聚焦，避免动画期间抢焦点。
 * @param input - 是否宽态、是否处于「展开后待聚焦」、搜索框引用与完成回调。
 */
export declare function useFocusSearchOnExpand(input: {
    wide: boolean;
    pending: boolean;
    inputRef: RefObject<HTMLInputElement>;
    onDone: () => void;
}): void;
/**
 * 分组收起状态（项目/工作区/归档桶）：写入侧栏偏好仓，刷新后保持。
 * @param prefs - 侧栏偏好仓。
 * @returns 当前收起集合与切换动作。
 */
export declare function useCollapsedGroups(prefs: BrowserPrefsStore): {
    collapsed: ReadonlySet<string>;
    toggle: (key: string) => void;
};
/** 会话/工作区重命名的就地编辑状态（工作区以 `ws:` 前缀与会话 id 区分）。 */ export interface RenameController {
    renaming: string | null;
    renameDraft: string;
    setRenameDraft: (value: string) => void;
    beginSession: (sessionId: SessionId, title: string) => void;
    beginWorkspace: (workspaceId: string, title: string) => void;
    commitSession: (sessionId: SessionId) => void;
    commitWorkspace: (workspaceId: string) => void;
}
/**
 * 重命名控制器。
 * @param input - 会话/工作区重命名动作与关菜单回调。
 * @returns 当前编辑目标、草稿与开始/提交动作。
 */
export declare function useRename(input: {
    renameSession: (sessionId: SessionId, title: string) => Promise<void>;
    renameWorkspace: (workspaceId: string, title: string) => Promise<void>;
    closeMenu: () => void;
}): RenameController;
