/**
 * dsh-workspace-rail 浏览器入口：挂载 codexLeft Remote（目录列举 + 项目注册表）
 * 并注册左侧导航面 ——
 * 遮蔽 sidebar.workspaces 的 Codex 式工作区浏览器、隐藏侧栏顶部品牌文字、
 * 挂在侧栏页脚槽位的添加工作区弹窗，以及新建会话页的项目选择器。
 *
 * 底栏终端属于 dsh-codex-shell：本插件只在会话菜单里调用它的
 * `remote.codexShell.terminalOpen`，未安装时该菜单项禁用，不构成硬依赖。
 * 插件/MCP/Skills 统一走宿主「设置 → 插件」。
 *
 * 对宿主编译采用本地结构面（faces.ts）而非宿主编排类型线；运行时的
 * 槽位核心仍会对每个名字做加载期强校验。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * 挂载 Remote 并注册左侧导航面的全部槽位。
 * @param ctx - 客户端根上下文。
 * @returns 卸载函数：注销所有槽位、文案命名空间与 Remote 贡献。
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
