/**
 * 侧栏会话行（Codex 式）：标题 + 悬停显露置顶/归档/更多操作；
 * 置顶/未读角标常驻；运行中会话点亮点。
 */
import type { SessionMetaStore } from '../../state/session-meta.js';
import type { SessionId, TFn } from '../../faces.js';
export interface SessionRowProps {
    sessionId: SessionId;
    title: string;
    cwd?: string | undefined;
    current: boolean;
    running: boolean;
    archived: boolean;
    renaming: boolean;
    renameDraft: string;
    setRenameDraft: (value: string) => void;
    commitRename: () => void;
    onOpen: () => void;
    onMenu: (event: React.MouseEvent) => void;
    onArchive: () => void;
    /** 归档行的恢复动作；未提供时不渲染。 */
    onRestore?: (() => void) | undefined;
    draggable: boolean;
    onDragStart?: (event: React.DragEvent) => void;
    onDragOver?: (event: React.DragEvent) => void;
    onDrop?: (event: React.DragEvent) => void;
    meta: SessionMetaStore;
    t: TFn;
}
/** 一条顶层会话行。 */
export declare function SessionRow(props: SessionRowProps): React.ReactNode;
