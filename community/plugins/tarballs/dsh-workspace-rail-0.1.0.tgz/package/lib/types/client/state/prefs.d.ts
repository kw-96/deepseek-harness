/**
 * 侧栏整理/排序偏好与项目置顶：独立于 SessionMeta 的 localStorage 仓。
 */
/** 侧栏整理：按项目分组，或扁平单列表。 */
export type OrganizeMode = 'byProject' | 'flat';
/** 聊天排序：置顶优先 / 最近更新 / 手动拖拽。 */
export type SortMode = 'pinnedFirst' | 'recent' | 'manual';
/** 自动归档默认阈值（天）。 */
export declare const DEFAULT_AUTO_ARCHIVE_DAYS = 30;
/**
 * 侧栏浏览器偏好仓。
 * 与 SessionMeta 分键，避免 meta 版本迁移误伤整理偏好。
 */
export declare class BrowserPrefsStore {
    private data;
    constructor();
    /** 当前整理模式。 */
    get organize(): OrganizeMode;
    /** 当前排序模式。 */
    get sort(): SortMode;
    /** 自动归档阈值（天）；0 表示关闭。 */
    get autoArchiveDays(): number;
    /** 写入自动归档阈值（0 关闭）。 */
    setAutoArchiveDays(days: number): void;
    /** 某工作区是否本地置顶。 */
    workspacePinned(workspaceId: string): boolean;
    /** 某项目是否本地置顶。 */
    projectPinned(projectId: string): boolean;
    /** 切换项目本地置顶。 */
    setProjectPinned(projectId: string, pinned: boolean): void;
    /** 当前收起的组键集合。 */
    collapsedGroups(): ReadonlySet<string>;
    /** 覆盖写入收起组键集合（项目/工作区/归档桶），供刷新后恢复。 */
    setCollapsedGroups(keys: readonly string[]): void;
    /** 写入整理模式。 */
    setOrganize(mode: OrganizeMode): void;
    /** 写入排序模式。 */
    setSort(mode: SortMode): void;
    /** 切换工作区本地置顶。 */
    setWorkspacePinned(workspaceId: string, pinned: boolean): void;
    private persist;
}
/** 偏好快照：整理模式、排序模式与自动归档阈值。 */
export interface BrowserPrefsSnapshot {
    organize: OrganizeMode;
    sort: SortMode;
    autoArchiveDays: number;
}
/** 订阅偏好变更（组件内本地快照）。 */
export declare function useBrowserPrefs(store: BrowserPrefsStore): [
    BrowserPrefsSnapshot,
    (patch: Partial<BrowserPrefsSnapshot>) => void
];
