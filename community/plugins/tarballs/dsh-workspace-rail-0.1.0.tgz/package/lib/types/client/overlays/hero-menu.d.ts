/** 新建会话页项目选择器的弹层内容：项目（可展开工作树）、未分组工作区与新建项目入口。 */
import type { ProjectView, TFn, WorkspaceViewLike } from '../faces.js';
/** 弹层属性：锚点、已排序项目、工作树解析与选择动作。 */
export interface HeroProjectMenuProps {
    anchor: {
        left: number;
        top: number;
    };
    projects: readonly ProjectView[];
    /** 项目归属的工作区列表（为空表示项目还没有工作树）。 */
    workspacesOf: (project: ProjectView) => readonly WorkspaceViewLike[];
    ungrouped: readonly WorkspaceViewLike[];
    /** 已展开工作树的项目 id。 */
    expanded: string | null;
    selectedId?: string | undefined;
    onChooseProject: (project: ProjectView) => void;
    onPick: (workspaceId: string) => void;
    onClose: () => void;
    onNewProject: () => void;
    t: TFn;
}
/** 渲染项目选择弹层。 */
export declare function HeroProjectMenu(props: HeroProjectMenuProps): React.ReactNode;
