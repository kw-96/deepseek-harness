/**
 * 侧栏树体：项目分组 / 扁平列表 / 归档与搜索结果。
 * 状态与动作来自 WorkspaceBrowser；分组行的渲染件在 tree-parts。
 */
import type { SessionMetaStore } from '../state/session-meta.js';
import type { BrowserPrefsStore, OrganizeMode, SortMode } from '../state/prefs.js';
import type { GroupsModel } from '../state/groups.js';
import type { ProjectView, SearchResultLike, SessionId, SessionListStateLike, TFn } from '../faces.js';
/** 分组投影结果。 */
export type { GroupsModel } from '../state/groups.js';
export interface BrowserTreeProps {
    groups: GroupsModel;
    list: SessionListStateLike;
    collapsed: ReadonlySet<string>;
    searching: boolean;
    searchItems: readonly SearchResultLike[];
    searchLoading: boolean;
    renaming: string | null;
    renameDraft: string;
    organize: OrganizeMode;
    sort: SortMode;
    prefs: BrowserPrefsStore;
    projects: readonly ProjectView[];
    onToggleGroup: (key: string) => void;
    onOpen: (sessionId: SessionId) => void;
    onWorkspaceMenu: (event: React.MouseEvent, workspaceId: string) => void;
    onSessionMenu: (event: React.MouseEvent, sessionId: SessionId) => void;
    onArchiveSession: (sessionId: SessionId) => void;
    /** 取消归档：把归档桶里的会话恢复到分组面。 */
    onRestoreSession: (sessionId: SessionId) => void;
    onToggleWorkspacePin: (workspaceId: string) => void;
    onToggleProjectPin: (projectId: string) => void;
    /** 打开项目「更多」菜单（重命名/管理工作树/归档组内/删除）。 */
    onProjectMenu: (event: React.MouseEvent, projectId: string) => void;
    /** 在项目所属工作区中新建会话。 */
    onNewSession: (workspaceId: string) => void;
    onBeginWorkspaceRename: (workspaceId: string, title: string) => void;
    setRenameDraft: (value: string) => void;
    commitRename: (sessionId: SessionId) => void;
    commitWorkspaceRename: (workspaceId: string) => void;
    onSessionDrop: (sessionId: SessionId, beforeSessionId: SessionId | undefined, workspaceId: string, fromWorkspaceId?: string) => void;
    sessionWorkspaceId: (sessionId: SessionId) => string | undefined;
    meta: SessionMetaStore;
    t: TFn;
}
/** 渲染树体。 */
export declare function BrowserTree(props: BrowserTreeProps): React.ReactNode;
