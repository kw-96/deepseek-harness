/**
 * 「新建项目」居中弹窗：项目名 + 基本盘工作区。
 * 基本盘可以是已有工作区（单选），也可以直接选一个目录——目录会先
 * 创建/复用一个工作区，再作为项目的首个工作树（root）。
 */
import type { FsListResponse, ProjectView } from 'dsh-workspace-rail/types';
import type { TFn, WorkspaceViewLike } from '../../faces.js';
export interface ProjectCreateProps {
    open: boolean;
    workspaces: readonly WorkspaceViewLike[];
    fsList: (path: string) => Promise<FsListResponse>;
    /** 创建或复用工作区（幂等）。 */
    createWorkspace: (input: {
        path: string;
    }) => Promise<{
        workspaceId: string;
        path: string;
    }>;
    createProject: (name: string, roots?: readonly string[]) => Promise<{
        project: ProjectView;
    }>;
    onCreated: () => void;
    onClose: () => void;
    t: TFn;
}
/** 渲染新建项目弹窗；关闭时返回 null。 */
export declare function ProjectCreateModal(props: ProjectCreateProps): import("react").JSX.Element | null;
