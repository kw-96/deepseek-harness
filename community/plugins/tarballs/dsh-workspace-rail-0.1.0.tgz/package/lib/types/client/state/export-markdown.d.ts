/** 会话历史的 Markdown 导出：尽力拼装用户/助手文本，失败返回 null。 */
interface SessionHistoryValueLike {
    records?: readonly unknown[];
}
export interface ConnectionProbeLike {
    api?: {
        sessions?: {
            history?: (request: {
                sessionId: string;
                maxMessages?: number;
                beforeSeq?: number;
            }) => Promise<{
                ok: true;
                value: SessionHistoryValueLike;
            } | {
                ok: false;
            }>;
        };
    };
}
/**
 * 尽力导出会话用户/助手文本为 Markdown。
 * @param connection - 客户端连接服务（结构面探测，缺失历史能力时返回 null）。
 * @param sessionId - 目标会话 id。
 * @returns Markdown 文本；无法拉取历史时返回 null。
 */
export declare function exportSessionMarkdown(connection: unknown, sessionId: string): Promise<string | null>;
export {};
