/**
 * 侧栏分组投影：按整理/排序偏好产出 grouped / flat / archived。
 * 会话排序规则独立导出，供工作区内部与项目级合并列表共用。
 */
import type { SessionMetaStore } from './session-meta.js';
import type { BrowserPrefsStore, OrganizeMode, SortMode } from './prefs.js';
import type { ProjectView, SessionId, SessionListStateLike, WorkspaceViewLike } from '../faces.js';
/** 分组投影结果。 */
export interface GroupsModel {
    grouped: {
        workspace: WorkspaceViewLike;
        sessions: SessionId[];
    }[];
    ungrouped: SessionId[];
    archived: SessionId[];
    flat: SessionId[];
}
export interface BuildGroupsInput {
    list: SessionListStateLike;
    workspaces: readonly WorkspaceViewLike[];
    archivedIds: readonly SessionId[];
    meta: SessionMetaStore;
    prefs: BrowserPrefsStore;
    organize: OrganizeMode;
    sort: SortMode;
}
/**
 * 会话排序比较器：置顶优先时置顶在前（置顶之间按最近更新），
 * 其余按最近更新倒序，同时刻按列表顺序兜底；手动模式只看列表顺序。
 * @param list - 会话列表快照（提供列表顺序与 updatedAt）。
 * @param meta - 会话置顶状态仓。
 * @param sort - 当前排序模式。
 * @returns 两个会话 id 的比较函数。
 */
export declare function sessionComparator(list: SessionListStateLike, meta: SessionMetaStore, sort: SortMode): (left: SessionId, right: SessionId) => number;
/**
 * 复制一份会话 id 并按当前排序模式重排；不修改入参数组。
 * @param ids - 待排序的会话 id 列表。
 * @returns 排序后的新数组。
 */
export declare function sortSessionIds(ids: readonly SessionId[], list: SessionListStateLike, meta: SessionMetaStore, sort: SortMode): SessionId[];
/**
 * 项目组排序：**恒为 置顶 → 最近活动 → 兜底**（项目没有拖拽排序，
 * 因此不受会话排序模式影响）。最近活动由调用方给出（项目下会话的
 * 最大 updatedAt，无会话时回退项目注册表 updatedAt）。
 * @param projects - 宿主项目注册表顺序。
 * @param prefs - 项目置顶状态仓。
 * @param recency - 返回某项目的最近活动时间（epoch ms，取不到为 0）。
 * @returns 排序后的新数组。
 */
export declare function orderProjects(projects: readonly ProjectView[], prefs: BrowserPrefsStore, recency: (projectId: string) => number): ProjectView[];
/** Normalize a directory path for matching: uniform separators, no trailing separator, case-folded on Windows-style paths. */
export declare function pathKey(value: string): string;
/**
 * Resolve the project owning one directory path by longest root prefix.
 * @param path - workspace or session directory path.
 * @param projects - project registry rows.
 * @returns the owning project, or undefined when no root matches.
 */
export declare function projectForPath(path: string, projects: readonly ProjectView[]): ProjectView | undefined;
/** 按偏好构建侧栏分组模型。 */
export declare function buildGroupsModel(input: BuildGroupsInput): GroupsModel;
