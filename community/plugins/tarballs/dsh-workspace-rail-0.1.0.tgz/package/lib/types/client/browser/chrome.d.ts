/** 侧栏浏览器外壳：常驻搜索框与折叠轨道控件。 */
import type { RefObject } from 'react';
import type { TFn } from '../faces.js';
/** 搜索框：输入绑定与清除按钮。 */
export declare function BrowserSearchBar(props: {
    query: string;
    inputRef: RefObject<HTMLInputElement>;
    onQuery: (value: string) => void;
    onClear: () => void;
    t: TFn;
}): React.ReactNode;
/** 折叠轨道态：常显的搜索入口，点击后展开侧栏并聚焦搜索。 */
export declare function BrowserRailControls(props: {
    onExpand: () => void;
    t: TFn;
}): React.ReactNode;
