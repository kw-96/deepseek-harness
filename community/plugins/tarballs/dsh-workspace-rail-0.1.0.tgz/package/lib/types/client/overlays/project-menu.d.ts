/**
 * 项目「更多」菜单体：重命名项目 / 管理工作树 / 归档组内会话 / 删除项目。
 */
import type { TFn } from '../faces.js';
/** 项目菜单可执行动作（由浏览器闭包提供）。 */
export interface ProjectMenuActions {
    rename(): void;
    manageWorktrees(): void;
    archiveAllSessions(): void;
    deleteProject(): void;
}
export interface ProjectMenuProps {
    actions: ProjectMenuActions;
    /** 项目名，显示为菜单顶部提示行。 */
    name: string;
    t: TFn;
}
/** 渲染项目菜单内容。 */
export declare function ProjectMenuBody({ actions, name, t }: ProjectMenuProps): React.ReactNode;
