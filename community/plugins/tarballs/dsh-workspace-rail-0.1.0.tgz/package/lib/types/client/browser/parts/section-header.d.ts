/**
 * 侧栏「项目」标题栏：标题 + 整理/排序菜单（…）+ 新建项目（+）。
 * 「添加工作区…」保留在整理菜单里（顶层入口让给新建项目）。
 */
import type { TFn } from '../../faces.js';
import type { OrganizeMode, SortMode } from '../../state/prefs.js';
export interface SectionHeaderProps {
    organize: OrganizeMode;
    sort: SortMode;
    /** 自动归档阈值（天）；0 表示关闭。 */
    autoArchiveDays: number;
    onOrganize: (mode: OrganizeMode) => void;
    onSort: (mode: SortMode) => void;
    onAutoArchive: (days: number) => void;
    onAddWorkspace: () => void;
    onNewProject: () => void;
    t: TFn;
}
/** 项目区段标题栏。 */
export declare function SectionHeader(props: SectionHeaderProps): React.ReactNode;
