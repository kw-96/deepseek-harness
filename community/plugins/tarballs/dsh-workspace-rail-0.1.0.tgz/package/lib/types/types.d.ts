/** Shared wire types for the dsh-workspace-rail Host Remote. */
import { z } from 'zod';
export type FsEntryKind = 'file' | 'directory' | 'other';
/** One direct child of a directory listing. */
export interface FsListEntry {
    name: string;
    kind: FsEntryKind;
    size: number | null;
}
export declare const fsListEntry: z.ZodReadonly<z.ZodObject<{
    name: z.ZodString;
    kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
    size: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>>;
export declare const fsListValue: z.ZodReadonly<z.ZodObject<{
    entries: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        name: z.ZodString;
        kind: z.ZodUnion<readonly [z.ZodLiteral<"file">, z.ZodLiteral<"directory">, z.ZodLiteral<"other">]>;
        size: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>>>>;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const projectViewValue: z.ZodReadonly<z.ZodObject<{
    projectId: z.ZodString;
    name: z.ZodString;
    roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strip>>;
export declare const projectListValue: z.ZodReadonly<z.ZodObject<{
    projects: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        projectId: z.ZodString;
        name: z.ZodString;
        roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const projectValue: z.ZodReadonly<z.ZodObject<{
    project: z.ZodReadonly<z.ZodObject<{
        projectId: z.ZodString;
        name: z.ZodString;
        roots: z.ZodReadonly<z.ZodArray<z.ZodString>>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>>;
export declare const projectDeleteValue: z.ZodReadonly<z.ZodObject<{
    deleted: z.ZodBoolean;
}, z.core.$strip>>;
/** Directory listing request/response (the workspace picker's browse step). */
export interface FsListRequest {
    path: string;
}
export interface FsListResponse {
    entries: readonly FsListEntry[];
    truncated: boolean;
}
/** A workspace-registry project. */
export interface ProjectView {
    projectId: string;
    name: string;
    roots: readonly string[];
    createdAt: string;
    updatedAt: string;
}
export interface ProjectListResponse {
    projects: readonly ProjectView[];
}
export interface ProjectCreateRequest {
    name: string;
    roots?: readonly string[];
}
export interface ProjectValue {
    project: ProjectView;
}
export interface ProjectRenameRequest {
    projectId: string;
    name: string;
}
export interface ProjectSetRootsRequest {
    projectId: string;
    roots: readonly string[];
}
export interface ProjectDeleteRequest {
    projectId: string;
}
export interface ProjectDeleteResponse {
    deleted: boolean;
}
