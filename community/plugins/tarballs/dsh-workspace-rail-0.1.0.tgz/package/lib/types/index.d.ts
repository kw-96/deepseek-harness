/** Host service for the dsh-workspace-rail Codex-style project/session navigation rail. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { FsListResponse, ProjectCreateRequest, ProjectDeleteRequest, ProjectDeleteResponse, ProjectListResponse, ProjectRenameRequest, ProjectSetRootsRequest, ProjectValue } from './types.js';
export type * from './types.js';
/** codexLeft Remote: directory listing for the pickers and the project registry. */
export declare class CodexLeft extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    private projectRegistry;
    fsList(path: string): Promise<FsListResponse>;
    projectList(): Promise<ProjectListResponse>;
    projectCreate(request: ProjectCreateRequest): Promise<ProjectValue>;
    projectRename(request: ProjectRenameRequest): Promise<ProjectValue>;
    projectSetRoots(request: ProjectSetRootsRequest): Promise<ProjectValue>;
    projectDelete(request: ProjectDeleteRequest): Promise<ProjectDeleteResponse>;
}
export default CodexLeft;
