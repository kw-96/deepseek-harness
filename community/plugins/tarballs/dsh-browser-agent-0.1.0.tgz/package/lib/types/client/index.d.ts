/**
 * dsh-browser-agent 浏览器入口：挂载 browserAgent Remote，并向宿主官方右栏
 * （ui-sidebar-right）注册一个页面型标签「浏览器」。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * 挂载 Remote 并注册右栏标签类型。
 * @param ctx - 客户端根上下文
 * @returns 卸载函数
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
