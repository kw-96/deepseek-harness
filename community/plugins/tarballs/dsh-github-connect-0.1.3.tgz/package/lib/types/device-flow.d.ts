/**
 * GitHub Device Flow client (ADR-0001): request a user code, then poll the
 * token endpoint at the server-dictated interval, handling
 * `authorization_pending` / `slow_down` (+5s) / `expired_token` /
 * `access_denied`. Pure functions over injected `fetch` and `sleep` so every
 * path is testable with the GitHub endpoints fully mocked (M5 DoD).
 * @module dsh-github-connect/device-flow
 */
/** What the UI shows the user: the code to type and where to type it. */
export interface DeviceFlowPrompt {
    readonly userCode: string;
    readonly verificationUri: string;
    /** Server-dictated seconds between polls. */
    readonly interval: number;
    /** Seconds until the device code expires. */
    readonly expiresIn: number;
}
/** One progress update pushed to the frontend over `github/device-flow`. */
export type DeviceFlowUpdate = {
    phase: 'awaiting-authorization';
    prompt: DeviceFlowPrompt;
} | {
    phase: 'slow-down';
    intervalSeconds: number;
} | {
    phase: 'authorized';
} | {
    phase: 'expired';
} | {
    phase: 'denied';
} | {
    phase: 'failed';
    message: string;
};
/** Everything one Device Flow run needs, injected for keyless tests. */
export interface DeviceFlowDeps {
    readonly fetch: typeof globalThis.fetch;
    /** Resolves after `ms`, rejecting (or resolving early is fine) on abort. */
    readonly sleep: (ms: number, signal?: AbortSignal) => Promise<void>;
    /** OAuth host, `https://github.com` (NOT the API host). */
    readonly authBaseURL: string;
    readonly clientId: string;
    /** Requested OAuth scope, e.g. `repo`. */
    readonly scope: string;
    readonly signal?: AbortSignal;
    readonly onUpdate: (update: DeviceFlowUpdate) => void;
}
/**
 * Request a device + user code pair (`POST /login/device/code`).
 * @param deps - injected transport and identity.
 * @returns the user-facing prompt and the private device code to poll with.
 */
export declare function requestDeviceCode(deps: DeviceFlowDeps): Promise<{
    prompt: DeviceFlowPrompt;
    deviceCode: string;
}>;
/**
 * Poll `POST /login/oauth/access_token` until the user authorizes, following
 * the server's pacing: wait `interval` seconds between polls, add 5 seconds on
 * `slow_down`, and settle terminally on `expired_token` / `access_denied`.
 * @param deps - injected transport and identity.
 * @param deviceCode - the private code from {@link requestDeviceCode}.
 * @param intervalSeconds - the initial poll interval from the prompt.
 * @returns the access token.
 */
export declare function pollForToken(deps: DeviceFlowDeps, deviceCode: string, intervalSeconds: number): Promise<string>;
/**
 * Run one complete Device Flow: request the code, surface the prompt through
 * `onUpdate`, poll to completion, and surface the terminal phase. The token is
 * RETURNED, never stored here — the caller owns the credentials seam write.
 * @param deps - injected transport and identity.
 * @returns the access token and the prompt it was authorized under.
 */
export declare function runDeviceFlow(deps: DeviceFlowDeps): Promise<{
    token: string;
    prompt: DeviceFlowPrompt;
}>;
/** Map a terminal failure to its frontend phase. */
export declare function terminalUpdate(error: unknown): DeviceFlowUpdate;
