/**
 * Host-side PR title/body derivation (design §6: the [Create PR] button's
 * fields arrive prefilled by the host, then edited by the user). Purely
 * deterministic — the commits ahead of base ARE the agent's own writing, so
 * no model turn is spent: one commit lends its subject and body verbatim,
 * several commits fold into a branch-derived title over a commit list.
 * @module dsh-github-connect/pr-draft
 */
/** A prefilled PR form: what the create panel shows before the user edits. */
export interface PrDraft {
    readonly title: string;
    readonly body?: string;
}
/** One commit ahead of base, as parsed from `git log`. */
export interface DraftCommit {
    readonly subject: string;
    readonly body: string;
}
/**
 * Turn a branch name into a readable title: a leading conventional-commit
 * segment becomes the `type:` prefix (`docs/root-readme` → `docs: root readme`),
 * and the remaining separators read as spaces.
 * @param branch - the head branch name.
 * @returns the humanized title.
 */
export declare function titleFromBranch(branch: string): string;
/**
 * Fold the commits ahead of base into a prefilled PR form.
 * @param branch - the head branch name (the multi-commit title source).
 * @param commits - oldest-first commits ahead of base; may be empty.
 * @returns the draft: single commit → its subject and body; several → a
 * branch-derived title over a bullet list of subjects; none → branch title only.
 */
export declare function derivePrDraft(branch: string, commits: readonly DraftCommit[]): PrDraft;
/** The `git log --format` template {@link parseCommitLog} expects (%x1f / %x1e keep the raw command ASCII-only). */
export declare const commitLogFormat = "--format=%s%x1f%b%x1e";
/**
 * Parse `git log` output produced with {@link commitLogFormat}.
 * @param stdout - the raw log output.
 * @returns the commits in the log's order.
 */
export declare function parseCommitLog(stdout: string): DraftCommit[];
