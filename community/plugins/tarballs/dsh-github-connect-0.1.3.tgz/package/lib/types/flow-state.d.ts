/**
 * Deterministic flow-state detection (ADR-0002): cheap git facts — current
 * branch, ahead count, head sha — plus one PR lookup fold into the four-state
 * machine driving the conversation status bar. No model involvement: git is
 * the objective signal. Dependencies are injected so fixture repositories and
 * scripted PR lookups cover every transition (M5 DoD).
 * @module dsh-github-connect/flow-state
 */
import type { GitHubRepoRef } from 'dsh-github';
/** CI rollup of a PR's check runs. */
export type ChecksSummary = 'pending' | 'passing' | 'failing';
/** The four states of the conversation PR status bar (design §2). */
export type GitHubFlowState = {
    kind: 'hidden';
}
/** `additions`/`deletions` summarize the diff against the base (the bar's +N −M pill); absent when the diff is empty or unreadable. */
 | {
    kind: 'pr-ready';
    repo: GitHubRepoRef;
    branch: string;
    base: string;
    aheadCount: number;
    additions?: number;
    deletions?: number;
} | {
    kind: 'pr-open';
    repo: GitHubRepoRef;
    branch: string;
    number: number;
    url?: string;
    ci?: ChecksSummary;
} | {
    kind: 'pr-merged';
    repo: GitHubRepoRef;
    branch: string;
    number: number;
};
/** A PR hit from the host-side branch lookup. */
export interface BranchPullRequest {
    readonly number: number;
    readonly url?: string;
}
/** Injected facts source for one detection pass. */
export interface FlowStateDeps {
    /** Run one git command in `cwd`, resolving stdout; MUST reject on a non-zero exit. */
    readonly runGit: (args: readonly string[], cwd: string) => Promise<string>;
    readonly cwd: string;
    /** GitHub host the remote must point at (gating: non-GitHub remotes are invisible). */
    readonly host: string;
    /** Configured base branch override; otherwise the remote HEAD (falling back to `main`). */
    readonly baseBranch?: string | undefined;
    /** Open PR for the branch, or undefined. */
    readonly findOpenPr: (repo: GitHubRepoRef, branch: string) => Promise<BranchPullRequest | undefined>;
    /** Most recent MERGED PR for the branch, or undefined. */
    readonly findMergedPr: (repo: GitHubRepoRef, branch: string) => Promise<BranchPullRequest | undefined>;
    /** CI rollup for an open PR; undefined when unavailable. */
    readonly checksSummary?: (repo: GitHubRepoRef, number: number) => Promise<ChecksSummary | undefined>;
}
/** One detection outcome: the state plus the head sha it was computed at. */
export interface FlowStateSnapshot {
    readonly state: GitHubFlowState;
    /** Head commit at detection time; absent when the cwd is not a usable git repo. */
    readonly headSha?: string;
}
/**
 * Parse a GitHub remote URL (`git@host:owner/repo.git`, `https://host/owner/repo`,
 * `ssh://git@host/owner/repo.git`) into a repo ref, or undefined for another host
 * or shape.
 * @param url - the raw remote URL.
 * @param host - the accepted GitHub host, e.g. `github.com`.
 * @returns the repo ref, or undefined.
 */
export declare function parseGitHubRemote(url: string, host: string): GitHubRepoRef | undefined;
/** Summarize seam check runs into the badge rollup; empty = undefined (nothing to show). */
export declare function summarizeChecks(runs: readonly {
    status: string;
    conclusion?: string;
}[]): ChecksSummary | undefined;
/**
 * Run one full detection pass. Never throws: any git or lookup failure folds
 * to `hidden` — the status bar silently disappears rather than erroring.
 * @param deps - injected git runner, repo gating, and PR lookups.
 * @returns the state and the head sha it was computed at.
 */
export declare function detectFlowState(deps: FlowStateDeps): Promise<FlowStateSnapshot>;
/**
 * The remote HEAD branch (`origin/HEAD` → `main`), falling back to `main`.
 * @param runGit - the injected git runner.
 * @param cwd - the workspace directory.
 * @returns the base branch name.
 */
export declare function detectBaseBranch(runGit: FlowStateDeps['runGit'], cwd: string): Promise<string>;
