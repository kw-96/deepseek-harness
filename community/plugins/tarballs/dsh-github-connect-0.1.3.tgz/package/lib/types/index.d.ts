/**
 * The GitHub connect service (`ctx.githubConnect`): Device Flow authorization
 * that stores the token through the credentials seam (ADR-0001), deterministic
 * git flow-state detection pushed over `github/flow-state` after each agent
 * turn (ADR-0002), and `@Remote` methods the web UI's buttons call directly —
 * zero model turns (design §6). Gating: a non-GitHub remote or an unresolvable
 * credential emits nothing, so unconnected users never see the feature.
 * @module dsh-github-connect
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type DeviceFlowPrompt, type DeviceFlowUpdate } from './device-flow.js';
import { type ChecksSummary, type GitHubFlowState } from './flow-state.js';
import { type PrDraft } from './pr-draft.js';
export { pollForToken, requestDeviceCode, runDeviceFlow, terminalUpdate, type DeviceFlowDeps, type DeviceFlowPrompt, type DeviceFlowUpdate, } from './device-flow.js';
export { detectBaseBranch, detectFlowState, parseGitHubRemote, summarizeChecks, type BranchPullRequest, type ChecksSummary, type FlowStateDeps, type FlowStateSnapshot, type GitHubFlowState, } from './flow-state.js';
export { commitLogFormat, derivePrDraft, parseCommitLog, titleFromBranch, type DraftCommit, type PrDraft, } from './pr-draft.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        githubConnect: GitHubConnectService;
    }
    interface Events {
        /**
         * The conversation PR status bar's state changed (design §2). Emitted only
         * for connected users on a GitHub-remoted workspace, after agent turns
         * that produced new commits, and from explicit UI refreshes.
         * @param state - the four-state machine's current state.
         * @mode emit
         */
        'github/flow-state'(state: GitHubFlowState): void;
        /**
         * Device Flow progress for the settings UI: the prompt to show, pacing
         * changes, and the terminal phase.
         * @param update - the progress update.
         * @mode emit
         */
        'github/device-flow'(update: DeviceFlowUpdate): void;
    }
}
/**
 * The shared `dsh-github-connector` OAuth App (owned by the project, Device
 * Flow enabled). A client id is a public identifier, not a secret — shipping
 * it is the same zero-setup pattern the GitHub CLI uses. GHES deployments
 * override it with an App registered on their own instance.
 */
export declare const DEFAULT_CLIENT_ID = "Ov23likAeAslKtkPq6Vn";
/** Plugin config. Every field has a default; overrides are for GHES and tests. */
export interface GitHubConnectConfig {
    /** OAuth App client id for the Device Flow; defaults to the project's shared App. */
    clientId?: string;
    /** Credential reference the token is stored under and resolved from. */
    credentialRef?: string;
    /** REST root (GHES: `https://ghes.example.com/api/v3`). */
    apiBaseURL?: string;
    /** OAuth host (NOT the API host). */
    authBaseURL?: string;
    /** GitHub host a workspace remote must point at to activate flow-state. */
    host?: string;
    /**
     * Workspace-directory override for git checks (ADR-0010). Normally the
     * calling session's `header.cwd` decides; this forces every check into one
     * directory — a single-workspace or test knob. Absent both, the process cwd.
     */
    cwd?: string;
    /** Base branch override; otherwise the remote HEAD (falling back to `main`). */
    baseBranch?: string;
    /** OAuth scope requested by the Device Flow. */
    scope?: string;
}
/** Config with schema defaults applied. */
interface ResolvedConnectConfig extends GitHubConnectConfig {
    credentialRef: string;
    apiBaseURL: string;
    authBaseURL: string;
    host: string;
    scope: string;
}
/** Outcome of a `createPr` button press. */
export interface CreatePrResult {
    readonly number: number;
    readonly url?: string;
    /** False when an open PR for the branch already existed (ADR-0004). */
    readonly created: boolean;
    readonly head: string;
    readonly base: string;
}
/** Merge strategies of the Merge dropdown (design §1). */
export type MergeMethod = 'squash' | 'merge' | 'rebase';
/** Abortable timer used between Device Flow polls (the service's default `sleep`). */
export declare function defaultSleep(ms: number, signal?: AbortSignal): Promise<void>;
/**
 * The connect service. `@Remote` methods are the web UI's direct lines
 * (Typert Gateway discovers them through the {@link TypertRemoteService}
 * binding); everything else is host-internal.
 */
export declare class GitHubConnectService extends TypertRemoteService {
    static inject: string[];
    /** Config schema (see {@link GitHubConnectConfig} for field semantics). */
    static Config: z<GitHubConnectConfig>;
    readonly config: ResolvedConnectConfig;
    /** Injectable transport (tests replace with scripted fetches). */
    fetchImpl: typeof globalThis.fetch;
    /** Injectable poll timer (tests replace with an immediate resolve). */
    sleep: (ms: number, signal?: AbortSignal) => Promise<void>;
    /** Injectable git runner (fixture repos use the real one in a temp cwd). */
    runGit: (args: readonly string[], cwd: string) => Promise<string>;
    /** The in-flight Device Flow poll, exposed so callers/tests can await settlement. */
    pendingFlow: Promise<void> | undefined;
    private activeFlow;
    private lastFlowUpdate;
    /** Detection caches keyed by the resolved workspace directory (ADR-0010: one dsh process serves many workspaces). */
    private readonly lastHead;
    private readonly lastEmitted;
    private statusCache;
    constructor(ctx: Context, config?: GitHubConnectConfig);
    /**
     * Whether a usable credential exists, and who it authenticates as. The
     * login lookup is cached per token and invalidated by
     * `credentials/reference-updated`.
     * @returns the connection state for the settings section.
     */
    connectStatus(): Promise<{
        connected: boolean;
        login?: string;
    }>;
    /**
     * Begin one Device Flow: returns the user prompt immediately and keeps
     * polling in the background, pushing progress over `github/device-flow`.
     * On success the token lands in the credentials seam, whose
     * `credentials/reference-updated` event refreshes every consumer — no restart.
     * A new start aborts any previous in-flight flow.
     * @returns the code and URL the frontend shows (and auto-copies).
     */
    startDeviceFlow(): Promise<DeviceFlowPrompt>;
    /**
     * The latest Device Flow progress — the settings card's polling source
     * (ADR-0009: dsh does not forward custom host events to the browser, so the
     * frontend polls this instead of subscribing to `github/device-flow`).
     * @returns the last update of the active flow, or undefined before any flow.
     */
    deviceFlowStatus(): DeviceFlowUpdate | undefined;
    /** Record progress for {@link deviceFlowStatus} and emit the host-internal event, dropping updates from a superseded flow. */
    private pushFlowUpdate;
    /**
     * Forget the stored credential (the settings section's Disconnect button).
     */
    disconnect(): Promise<void>;
    /**
     * Prefill the [Create PR] panel (design §6: title/body arrive prefilled by
     * the host, edited by the user). Deterministic derivation from the commits
     * ahead of base — zero model turns, zero GitHub requests.
     * @returns the draft title and optional body.
     */
    prDraft(request?: {
        sessionId?: string;
    }): Promise<PrDraft>;
    /** Commits ahead of base, oldest first: prefer the remote-tracking base, else the local one, else none. */
    private commitsAhead;
    /**
     * Create a PR from the workspace's current branch — the status bar's
     * [Create PR] button. Title/body arrive prefilled by the host and edited by
     * the user; the branch and base come from git. Idempotent through the seam
     * (ADR-0004).
     * @param request - title, optional body, optional base override, optional calling session (ADR-0010).
     * @returns the created-or-existing PR and the branches used.
     */
    createPr(request: {
        title: string;
        body?: string;
        base?: string;
        sessionId?: string;
    }): Promise<CreatePrResult>;
    /**
     * Merge one PR — the status bar's [Merge] dropdown, behind the host's
     * irreversible-action confirmation.
     *
     * Mergeability is checked FIRST (M10): when GitHub already knows the merge
     * cannot succeed, no `PUT` is sent and the blockers come back for the status
     * bar to show in place. A doomed merge should read as "this cannot merge
     * because X", not as an opaque HTTP failure after the fact.
     * @param request - the PR number, merge strategy, and optional calling session (ADR-0010).
     * @returns GitHub's merge outcome, or the blockers that stopped it.
     */
    mergePr(request: {
        number: number;
        method: MergeMethod;
        sessionId?: string;
    }): Promise<{
        merged: boolean;
        sha?: string;
        blockedBy?: readonly string[];
    }>;
    /**
     * CI rollup for one PR — the badge poller's endpoint. The frontend owns the
     * cadence: poll with backoff and STOP while the page is hidden (risk table).
     * @param number - the PR number.
     * @param sessionId - the calling session, deciding the workspace (ADR-0010).
     * @returns the rollup, or undefined when checks are unavailable.
     */
    prChecks(number: number, sessionId?: string): Promise<ChecksSummary | undefined>;
    /**
     * Re-detect the flow state on demand (UI refresh after its own button
     * actions), bypassing the new-commits noise rule, and emit the result.
     * @param request - optional calling session, deciding the workspace (ADR-0010).
     * @returns the freshly detected state.
     */
    refreshFlowState(request?: {
        sessionId?: string;
    }): Promise<GitHubFlowState>;
    /**
     * Turn-end hook (ADR-0002): gated on a resolvable credential, skipped when
     * the turn produced no new commits, and NEVER allowed to break the turn.
     * The workspace is the turn's session `header.cwd` (ADR-0010).
     */
    private onTurnEnd;
    /** Emit a state change, collapsing repeated hides per workspace (unconnected users see nothing; an untouched workspace starts hidden). */
    private emitState;
    /** Assemble the injected detection dependencies over one workspace directory. */
    private flowDeps;
    /** CI rollup through the seam; any failure (no provider, rate limit) reads as unavailable. */
    private checksSummary;
    /** Look up the branch's PR by exact head, host-side (not a seam operation). */
    private findBranchPr;
    /** The workspace's repo/branch/base facts, or a typed refusal for the buttons. */
    private repoFacts;
    /**
     * Resolve the workspace directory for one call (ADR-0010): the calling
     * session's `header.cwd` through the optional session store, else the
     * config override, else the process cwd.
     */
    private cwd;
    /** The calling session's workspace directory, or undefined outside a dsh session composition. */
    private sessionCwd;
    /** Resolve the credential: seam first, process environment as the fallback. */
    private resolveToken;
    /** Resolve the credential or throw the auth refusal the buttons surface. */
    private requireToken;
    /** One authenticated REST call against the API host, with connect-scoped error mapping. */
    private api;
    /** Extract the API's diagnostic suffix from an error body, tolerating non-JSON. */
    private apiMessage;
}
export default GitHubConnectService;
