/**
 * The approval-gated write tools: `github_issue_create`, `github_issue_comment`,
 * and `github_pr_create`. Every write asks through `tools/pre-execute` with a
 * human-readable reason (target repo, title, body preview); a denial becomes a
 * model-visible refusal result, never an exception. `github_pr_create` presents
 * the seam's idempotent outcome (ADR-0004): an already-open PR is a normal
 * answer, not an error.
 * @module dsh-tool-github/write
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ToolResult } from '@deepseek-ai/dsh-tools';
import { type ResolvedToolGitHubConfig } from './shared.js';
/** The gated tool names, exported so tests and hosts can recognize the set. */
export declare const GITHUB_WRITE_TOOLS: ReadonlySet<string>;
/**
 * Gate every write tool behind the approval waterfall. The registry resolves
 * `ask` through the optional approval seam: `allowed-once` proceeds, everything
 * else materializes a refusal result the model can read and continue from.
 * @param ctx - the preset's plugin context (listener rides its fiber).
 */
export declare function installWriteApprovalGate(ctx: Context): void;
/** Narrow opaque result meta to the PR-create presentation meta, or undefined. */
export declare function prCreateMetaFromResult(meta: unknown): {
    number: number;
    created: boolean;
} | undefined;
/** Completed-call presentation for `github_pr_create`: created vs already-open. */
export declare function presentPrCreateResult(result: ToolResult): {
    card: 'generic';
    title: string;
} | undefined;
/**
 * Register the three write tools.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (timeout).
 */
export declare function applyGitHubWriteTools(ctx: Context, config: ResolvedToolGitHubConfig): void;
