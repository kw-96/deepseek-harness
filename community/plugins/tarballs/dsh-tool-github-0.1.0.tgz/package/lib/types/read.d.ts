/**
 * The model-facing `github_issue_read` and `github_pr_read` tools. PR reads
 * split into on-demand parts (`metadata` / `diff` / `comments` / `reviews` /
 * `checks` / `ci-failures`) so one call never pays for data the model did not
 * ask for; the diff and log budgets are OWNED HERE (tool layer) and passed to
 * the seam, which enforces them (ADR-0005).
 * @module dsh-tool-github/read
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ResolvedToolGitHubConfig } from './shared.js';
/** The PR read parts — a CLOSED union consumers switch over. */
export type PullRequestReadPart = 'metadata' | 'diff' | 'comments' | 'reviews' | 'checks' | 'ci-failures';
/** Lean JSON projection of one comment. */
interface CommentValue {
    readonly body: string;
    readonly author?: string;
    readonly createdAt?: string;
}
/** The comments section shared by issue and PR reads. */
export declare function formatComments(comments: readonly CommentValue[], total: number): string;
/** Issue header + body formatting. */
export declare function formatIssue(value: {
    repo: string;
    number: number;
    title: string;
    state: string;
    author?: string;
    labels?: readonly string[];
    body?: string;
}): string;
/** PR header + body formatting (adds branches, draft, merged state). */
export declare function formatPullRequestHeader(value: {
    repo: string;
    number: number;
    title: string;
    state: string;
    headRef: string;
    baseRef: string;
    author?: string;
    draft?: boolean;
    body?: string;
}): string;
/** Diff formatting: per-file header lines plus fenced patches when present. */
export declare function formatDiff(diff: {
    files: readonly {
        path: string;
        previousPath?: string;
        status: string;
        additions: number;
        deletions: number;
        patch?: string;
    }[];
    truncated: boolean;
}): string;
/** Check-run list with an overall verdict line. */
export declare function formatChecks(runs: readonly {
    name: string;
    status: string;
    conclusion?: string;
    url?: string;
}[]): string;
/** Lean JSON projection of one submitted review. */
interface ReviewValue {
    readonly state: string;
    readonly author?: string;
    readonly body?: string;
    readonly submittedAt?: string;
}
/** Lean JSON projection of one line-anchored review comment. */
interface ReviewCommentValue {
    readonly path: string;
    readonly body: string;
    readonly side: string;
    readonly line?: number;
    readonly diffHunk?: string;
    readonly author?: string;
    readonly createdAt?: string;
}
/** Reviews section: verdicts first, then the line-anchored feedback to act on. */
export declare function formatReviews(value: {
    items: readonly ReviewValue[];
    comments: readonly ReviewCommentValue[];
    totalComments: number;
}): string;
/** CI failure evidence: one block per failed run, annotations preferred over log tails. */
export declare function formatCiFailures(value: {
    failures: readonly {
        name: string;
        conclusion?: string;
        annotations: readonly {
            path: string;
            level: string;
            message: string;
            title?: string;
            startLine?: number;
            endLine?: number;
        }[];
        log?: {
            text: string;
            truncated: boolean;
        };
    }[];
    truncated: boolean;
}): string;
/**
 * Register `github_issue_read`: body plus capped aggregated comments.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (`maxComments` cap, timeout).
 */
export declare function applyGitHubIssueReadTool(ctx: Context, config: ResolvedToolGitHubConfig): void;
/**
 * Register `github_pr_read`: metadata by default; `diff`, `comments`, and
 * `checks` are separate on-demand parts.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (diff budgets, comment cap, timeout).
 */
export declare function applyGitHubPrReadTool(ctx: Context, config: ResolvedToolGitHubConfig): void;
/** Render one `github_pr_read` value by its part. */
export declare function renderPrRead(value: {
    part: string;
    pullRequest?: {
        repo: string;
        number: number;
        title: string;
        state: string;
        headRef: string;
        baseRef: string;
        author?: string;
        draft?: boolean;
        body?: string;
    };
    diff?: {
        files: {
            path: string;
            previousPath?: string;
            status: string;
            additions: number;
            deletions: number;
            patch?: string;
        }[];
        truncated: boolean;
    };
    comments?: {
        items: {
            body: string;
            author?: string;
            createdAt?: string;
        }[];
        total: number;
    };
    checks?: {
        runs: {
            name: string;
            status: string;
            conclusion?: string;
            url?: string;
        }[];
    };
    reviews?: {
        items: {
            state: string;
            author?: string;
            body?: string;
            submittedAt?: string;
        }[];
        comments: {
            path: string;
            body: string;
            side: string;
            line?: number;
            diffHunk?: string;
            author?: string;
            createdAt?: string;
        }[];
        totalComments: number;
    };
    ciFailures?: {
        failures: {
            name: string;
            conclusion?: string;
            annotations: {
                path: string;
                level: string;
                message: string;
                title?: string;
                startLine?: number;
                endLine?: number;
            }[];
            log?: {
                text: string;
                truncated: boolean;
            };
        }[];
        truncated: boolean;
    };
}): string;
export {};
