/**
 * Function plugin registering the `github_*` tool suite over `ctx.github`.
 * Read tools always register; write tools are gated by the `write` switch
 * (default on) and every write asks for user approval through
 * `tools/pre-execute` before anything reaches GitHub. This package owns
 * schemas, prompt guidance, tool-layer budgets, and presentation — never
 * providers or transport.
 *
 * NO default export — the dsh Loader drops `inject` from default-exported
 * function plugins (engineering gate §8).
 * @module dsh-tool-github
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { applyGitHubSearchTool, formatSearchOutput, presentSearchResult, searchCallTitle, searchMetaFromResult } from './search.js';
export { applyGitHubIssueReadTool, applyGitHubPrReadTool, formatChecks, formatCiFailures, formatComments, formatDiff, formatIssue, formatReviews, formatPullRequestHeader, renderPrRead, type PullRequestReadPart, } from './read.js';
export { applyGitHubPrReviewTool, formatReviewBrief, REVIEW_DIMENSIONS, type ReviewBriefValue } from './review.js';
export { allowedReviewEvents, applyGitHubPrListTool, applyGitHubReviewWriteTools, formatPrList, prAssignApprovalReason, prUpdateApprovalReason, REVIEW_VERDICT_EVENTS, reviewSubmitApprovalReason, } from './review-write.js';
export { applyGitHubWriteTools, GITHUB_WRITE_TOOLS, installWriteApprovalGate, presentPrCreateResult, prCreateMetaFromResult } from './write.js';
export { parseRepoInput, preview, repoLabel, runGitHub, toModelError, type ResolvedToolGitHubConfig } from './shared.js';
/** Cordis plugin name. */
export declare const name = "tool-github";
/** Required services; the approval seam stays optional (registry degrades ask→deny). */
export declare const inject: string[];
/** Plugin config. All optional — the schema supplies defaults. */
export interface Config {
    /** Register the write tools (issue/comment/PR creation). Defaults to true. */
    write?: boolean;
    /** Cap on `github_search` hits per call. Defaults to 8. */
    searchMaxResults?: number;
    /** Cap on returned conversation comments per read. Defaults to 30. */
    maxComments?: number;
    /** Tool-owned diff budget: max changed files per `github_pr_read` diff. Defaults to 50. */
    diffMaxFiles?: number;
    /** Tool-owned diff budget: max total patch characters per diff. Defaults to 60000. */
    diffMaxPatchChars?: number;
    /** Tool-owned log budget: max trailing log lines per failed check run. Defaults to 80. */
    logMaxLines?: number;
    /** Tool-owned log budget: max trailing log characters per failed check run. Defaults to 8000. */
    logMaxChars?: number;
    /** Tool-owned review budget: max changed files in a `github_pr_review` brief. Defaults to 60. */
    reviewMaxFiles?: number;
    /** Tool-owned review budget: max total patch characters in a brief. Defaults to 120000. */
    reviewMaxPatchChars?: number;
    /**
     * Let the model submit APPROVE / REQUEST_CHANGES reviews under the user's own
     * GitHub account. **Defaults to false** (ADR-0014): those two change whether a
     * PR is blocked and read to collaborators as the user's judgement, so the
     * capability is opt-in rather than approval-gated only. Commenting is always
     * available. Ignored entirely when `write` is off.
     */
    reviewVerdicts?: boolean;
    /** Cooperative timeout budget (ms) attached to every github tool. Defaults to 30000. */
    timeoutMs?: number;
}
/**
 * Config schema (see {@link Config} which documents each field).
 *
 * 显式 `z<Config>` 标注与 `interface Config` 互为约束：schema 输出必须匹配
 * 公开配置类型，声明产物也只引用可命名的 `Schema<Config>`，不内联展开
 * `ObjectS`/`ObjectT` 结构。
 */
export declare const Config: z<Config>;
/**
 * Register the GitHub tool suite: prompt guidance, the three read tools, and —
 * when `write` is on — the three write tools plus their approval gate. All
 * registrations are effects riding this plugin's fiber.
 * @param ctx - plugin context carrying `ctx.tools`, `ctx.github`, `ctx.systemPrompt`.
 * @param config - resolved plugin config (schema defaults applied).
 */
export declare function apply(ctx: Context, config: Config): void;
