/**
 * The write half of the review loop (M10): submitting a review, updating a
 * pull request, assigning reviewers and labels, and listing pull requests.
 *
 * `github_pr_review_submit` carries the project's first operation with SOCIAL
 * consequence — `APPROVE` and `REQUEST_CHANGES` change a PR's blocking state
 * under the user's own name — so it is gated twice (ADR-0014): the
 * `reviewVerdicts` switch decides whether those two events exist in the schema
 * at all (default: they do not), and every submission still passes the approval
 * waterfall with a reason that names the event.
 * @module dsh-tool-github/review-write
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GitHubReviewEvent } from 'dsh-github';
import { type ResolvedToolGitHubConfig } from './shared.js';
/** The verdict-bearing events, i.e. the ones `reviewVerdicts` gates. */
export declare const REVIEW_VERDICT_EVENTS: ReadonlySet<string>;
/**
 * The events the model may choose from under this config.
 *
 * Narrowing happens in the SCHEMA, not at execution: with `reviewVerdicts` off
 * the model never sees that approving is possible, so it cannot try and be
 * refused (ADR-0014).
 * @param config - resolved plugin config.
 * @returns the allowed event names.
 */
export declare function allowedReviewEvents(config: ResolvedToolGitHubConfig): readonly GitHubReviewEvent[];
/**
 * Approval reason for a review submission.
 *
 * A verdict reads differently from a comment on purpose: the user is being
 * asked to let an agent speak with their voice in a way collaborators will
 * treat as their judgement, and the prompt says exactly that. This wording is
 * the whole of the confirmation layer available here — the host's
 * `PreToolDecision` carries only a reason string, with no risk level to raise
 * (see the M10 implementation note in the execution plan).
 * @param args - raw tool arguments.
 * @returns the human-readable approval reason.
 */
export declare function reviewSubmitApprovalReason(args: unknown): string;
/** Approval reason for a pull request field update. */
export declare function prUpdateApprovalReason(args: unknown): string;
/** Approval reason for reviewer/label assignment. */
export declare function prAssignApprovalReason(args: unknown): string;
/**
 * Register `github_pr_list` — a READ tool, so it is not gated by `write`.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config.
 */
export declare function applyGitHubPrListTool(ctx: Context, config: ResolvedToolGitHubConfig): void;
/** One pull request per line, lean enough to scan. */
export declare function formatPrList(value: {
    repo: string;
    pullRequests: readonly {
        number: number;
        title: string;
        state: string;
        headRef: string;
        baseRef: string;
        author?: string;
        draft?: boolean;
    }[];
}): string;
/**
 * Register the review-write tools: submission, field updates, and assignment.
 * All three are approval-gated writes and only register when `write` is on.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (`reviewVerdicts` narrows the event enum).
 */
export declare function applyGitHubReviewWriteTools(ctx: Context, config: ResolvedToolGitHubConfig): void;
