/**
 * The model-facing `github_search` tool. Execution goes through `ctx.github`;
 * this module owns only the schema (with the CLOSED `kind` union), validation,
 * the result bound, lean formatting, and presentation.
 * @module dsh-tool-github/search
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ToolResult } from '@deepseek-ai/dsh-tools';
import type { GitHubSearchKind } from 'dsh-github';
import { type ResolvedToolGitHubConfig } from './shared.js';
/** One lean model-facing search hit; `repo` collapses to `owner/repo`. */
interface SearchValueItem {
    readonly title: string;
    readonly url: string;
    readonly repo?: string;
    readonly number?: number;
    readonly state?: string;
    readonly snippet?: string;
}
/** Present-call title per kind — the CLOSED-union switch the design demands. */
export declare function searchCallTitle(kind: GitHubSearchKind, query: string): string;
/**
 * Format the search outcome as one lean text block: one line per hit
 * (`owner/repo#N [state] title` when addressable), a refine hint when
 * truncated, or a plain no-results notice.
 * @param value - the canonical output value.
 * @returns the model-facing text.
 */
export declare function formatSearchOutput(value: {
    items: readonly SearchValueItem[];
    truncated: boolean;
}): string;
/** Narrow opaque result meta to the search presentation meta, or undefined. */
export declare function searchMetaFromResult(meta: unknown): {
    count: number;
    truncated: boolean;
} | undefined;
/** Completed-call presentation: replace the title with the hit count. */
export declare function presentSearchResult(result: ToolResult): {
    card: 'generic';
    title: string;
} | undefined;
/**
 * Register `github_search`.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (`searchMaxResults` bound, timeout).
 */
export declare function applyGitHubSearchTool(ctx: Context, config: ResolvedToolGitHubConfig): void;
export {};
