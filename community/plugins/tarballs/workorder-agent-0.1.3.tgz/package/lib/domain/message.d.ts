import type { Violation } from './types.js';
/** 生成易协作工单详情地址。 */
export declare function issueUrl(host: string, issueId: number): string;
/** 按指派人聚合正式巡检消息，并附加工单详情链接。 */
export declare function buildInspectionMessage(title: string, violations: Violation[], host: string): string | null;
