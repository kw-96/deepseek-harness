import type { Context } from '@deepseek-ai/cordis';
export declare const WORKORDER_AGENT_ID = "workorder-agent-background";
export interface WorkorderAgentRouter {
    routeWebhook(traceId: string, issueId: number, projectName: string): Promise<void>;
}
/** 基于 Harness ctx.agents 的后台单实例工单 Agent 路由器。 */
export declare class HarnessWorkorderAgent implements WorkorderAgentRouter {
    private readonly ctx;
    private handle?;
    private creating?;
    constructor(ctx: Context);
    /** 创建或复用唯一后台 Agent，并把 Webhook 事件路由为后续回合。 */
    routeWebhook(traceId: string, issueId: number, projectName: string): Promise<void>;
    /** 停止由该路由器创建的后台 Agent。 */
    close(): Promise<void>;
    private getOrCreate;
    private buildPrompt;
}
