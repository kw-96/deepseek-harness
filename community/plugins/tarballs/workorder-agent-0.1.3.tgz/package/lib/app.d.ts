import { Hono } from 'hono';
import type { AppConfig } from './config.js';
import type { WorkorderAgentRouter } from './harness/agent.js';
export interface AppRuntime {
    app: Hono;
    close: () => Promise<void>;
}
/** 创建完整业务运行时及内部管理 API。 */
export declare function createApp(config: AppConfig, agentRouter?: WorkorderAgentRouter): Promise<AppRuntime>;
