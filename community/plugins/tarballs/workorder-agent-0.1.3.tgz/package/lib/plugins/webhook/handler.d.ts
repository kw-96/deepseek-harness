import type { ProjectMap } from '../gcp/service.js';
import type { GcpClient } from '../gcp/client.js';
import type { WorkorderStore } from '../store/store.js';
import type { WorkorderAgentRouter } from '../../harness/agent.js';
export interface WebhookResult {
    accepted: boolean;
    duplicate: boolean;
    issueId?: number;
}
/** 易协作事件接收、持久任务与 dry-run 处理服务。 */
export declare class GcpWebhookHandler {
    private readonly store;
    private readonly gcp;
    private readonly instanceHost;
    private readonly agentRouter?;
    private timer?;
    private running;
    private readonly projectsById;
    constructor(store: WorkorderStore, gcp: GcpClient, projects: ProjectMap, instanceHost: string, agentRouter?: WorkorderAgentRouter | undefined);
    /** 启动持久任务轮询器。 */
    start(): void;
    /** 停止持久任务轮询器。 */
    stop(): void;
    /** 返回后台任务轮询器是否处于运行状态。 */
    isReady(): boolean;
    /** 校验事件并持久入队，后续由后台有限重试。 */
    accept(payload: unknown): WebhookResult;
    private processNext;
}
