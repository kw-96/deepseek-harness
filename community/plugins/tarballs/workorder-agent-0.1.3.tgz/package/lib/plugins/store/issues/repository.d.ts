import type Database from 'better-sqlite3';
import type { IssueSnapshot } from '../../../domain/types.js';
/** 持久化工单快照，供巡检按更新时间复用。 */
export declare class IssueRepository {
    private readonly db;
    constructor(db: Database.Database);
    /** 按工单 ID 读取本地快照。 */
    get(id: number): IssueSnapshot | undefined;
    /** 按更新时间倒序列出本地工单快照。 */
    list(limit?: number): IssueSnapshot[];
    /** 返回已入库工单总数。 */
    count(): number;
    /** 覆盖写入工单快照。 */
    upsert(issue: IssueSnapshot): void;
}
