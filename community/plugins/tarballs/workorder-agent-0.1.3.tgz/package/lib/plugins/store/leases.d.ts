import type Database from 'better-sqlite3';
import type { WebhookTask } from './types.js';
/** 原子领取发送租约，过期的 pending 记录可恢复。 */
export declare function beginDelivery(db: Database.Database, key: string, leaseMs?: number): string | undefined;
/** 原子领取 Webhook 任务，并恢复已过期的 processing 租约。 */
export declare function claimWebhook(db: Database.Database, leaseMs?: number): WebhookTask | undefined;
/** 记录失败；达到上限后转入 dead-letter。 */
export declare function failWebhook(db: Database.Database, task: WebhookTask, error: string): void;
