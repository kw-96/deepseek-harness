/** 返回 Harness 业务控制面交互脚本。 */
export declare function adminScript(): string;
