/** 返回挂载于 Harness WebServer 的业务控制面。 */
export declare function adminPage(): string;
