/** 返回 Harness 业务控制面样式。 */
export declare function adminStyles(): string;
