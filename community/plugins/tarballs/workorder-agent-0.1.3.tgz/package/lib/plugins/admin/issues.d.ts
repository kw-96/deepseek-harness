import type { IssueSnapshot } from '../../domain/types.js';
/** 将入库字段转为页面展示文本，不附加单位。 */
export declare function issueFieldText(value: unknown): string;
export interface AdminIssueView {
    id: number;
    url: string;
    projectName: string;
    subject: string;
    assigneeName: string;
    statusName: string;
    gameProduct: string;
    deliveryChannel: string;
    returnDeliveryChannel: string;
    aiDeliveryChannel: string;
    artCategory: string;
    aiPipelineTime: string;
    totalHours: string;
    designQuantity: string;
    expectedDeliveryDate: string;
    startDate: string;
    dueDate: string;
    createdOn: string;
    updatedOn: string;
    closedOn: string;
}
/** 将工单快照转为控制面展示结构，并附带易协作详情地址。 */
export declare function toAdminIssue(issue: IssueSnapshot, host: string): AdminIssueView;
