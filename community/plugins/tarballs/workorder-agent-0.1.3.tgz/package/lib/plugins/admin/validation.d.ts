import { z } from 'zod';
export declare const dateRangeSchema: z.ZodObject<{
    startDate: z.ZodString;
    endDate: z.ZodString;
}, z.core.$strip>;
export declare const previewIdSchema: z.ZodString;
export declare const messageIdSchema: z.ZodString;
export declare const issueIdSchema: z.ZodCoercedNumber<unknown>;
export declare const resumeMessageSchema: z.ZodObject<{
    confirmation: z.ZodLiteral<"确认从失败分段继续发送">;
}, z.core.$strip>;
export declare const sendPreviewSchema: z.ZodObject<{
    previewId: z.ZodString;
    confirmation: z.ZodLiteral<"确认发送正式巡检结果">;
}, z.core.$strip>;
export declare const resendPreviewSchema: z.ZodObject<{
    confirmation: z.ZodLiteral<"确认再次发送复核结果">;
}, z.core.$strip>;
/** 控制面允许在线修改的非敏感运行设置。 */
export declare const runtimeSettingsSchema: z.ZodObject<{
    scheduleEnabled: z.ZodOptional<z.ZodBoolean>;
    automaticSendEnabled: z.ZodOptional<z.ZodBoolean>;
    webhookProcessingEnabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
