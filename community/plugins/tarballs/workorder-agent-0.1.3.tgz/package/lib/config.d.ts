import type { ProjectMap } from './plugins/gcp/service.js';
export interface AppConfigInput {
    port?: number;
    dataDir?: string;
    adminToken: string;
    webhookToken: string;
    gcpUserKey: string;
    gcpUrl?: string;
    gcpHost?: string;
    popoWebhookUrl: string;
    popoWebhookSecret?: string;
    completedStatusId?: number;
    projectIdChannelArt?: number;
    projectIdReturnBusiness?: number;
    projectIdAiOperations?: number;
}
export interface AppConfig {
    port: number;
    dataDir: string;
    adminToken: string;
    webhookToken: string;
    projects: ProjectMap;
    completedStatusId: number;
    gcp: {
        url: string;
        host: string;
        userKey: string;
    };
    popo: {
        url: string;
        secret?: string;
    };
}
/**
 * 将已解析字段组装为运行配置。
 * @param input 令牌、项目与连接参数
 * @returns 校验后的应用配置
 */
export declare function buildAppConfig(input: AppConfigInput): AppConfig;
/** 从进程环境变量读取并校验运行配置。 */
export declare function loadConfig(): AppConfig;
