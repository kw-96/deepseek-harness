/**
 * One-call installation: mount the settings section and the status bar into
 * their client slots (design §3) and hand back a single disposer. The web
 * client calls this with its shell adapter and Typert Client Remote.
 * @module dsh-github/ui/install
 */
import { type UiLocale } from './i18n.js';
import type { GitHubUiRemote, GitHubUiShell } from './types.js';
import { type PollPolicy, type StatusBarTimers } from './status-bar.js';
/** Installation knobs, all defaulted. */
export interface GitHubUiOptions {
    readonly locale?: UiLocale;
    readonly poll?: PollPolicy;
    /** Flow-state poll pacing (ADR-0009), independent of the CI badge's. */
    readonly flowPoll?: PollPolicy;
    readonly collapseMs?: number;
    /** Loading cap of the agent-driven [Create PR] (ADR-0011). */
    readonly createTimeoutMs?: number;
    readonly timers?: StatusBarTimers;
}
/**
 * Register both slots.
 * @param shell - the client shell adapter (ADR-0007).
 * @param remote - the Typert Client Remote slice.
 * @param options - optional locale and pacing knobs.
 * @returns a disposer that unregisters both slots.
 */
export declare function installGitHubUi(shell: GitHubUiShell, remote: GitHubUiRemote, options?: GitHubUiOptions): () => void;
