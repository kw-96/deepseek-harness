/**
 * 插件对外值类型：Host 工具、Remote 面板与 Client 共用同一份
 * 定义，Remote 线协议用 zod schema 校验。
 */
import { z } from 'zod';
/** bsk 会话状态机。 */
export declare const SESSION_STATES: readonly ["idle", "open", "stopped", "error"];
declare const instanceSchema: z.ZodObject<{
    instanceId: z.ZodString;
    browserName: z.ZodString;
    label: z.ZodString;
    extensionVersion: z.ZodString;
    versionSkew: z.ZodBoolean;
}, z.core.$strip>;
declare const tabSchema: z.ZodObject<{
    tabId: z.ZodString;
    url: z.ZodString;
    title: z.ZodString;
    scope: z.ZodUnion<readonly [z.ZodLiteral<"user">, z.ZodLiteral<"agent">]>;
}, z.core.$strip>;
declare const sessionSchema: z.ZodObject<{
    sessionId: z.ZodString;
    bskSessionId: z.ZodNullable<z.ZodString>;
    state: z.ZodUnion<readonly [z.ZodLiteral<"idle">, z.ZodLiteral<"open">, z.ZodLiteral<"stopped">, z.ZodLiteral<"error">]>;
    currentUrl: z.ZodNullable<z.ZodString>;
    pageTitle: z.ZodNullable<z.ZodString>;
    tabCount: z.ZodNumber;
    lastActionAtMs: z.ZodNumber;
    idleDeadlineAtMs: z.ZodNullable<z.ZodNumber>;
    lastError: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const browserPanelValue: z.ZodObject<{
    session: z.ZodObject<{
        sessionId: z.ZodString;
        bskSessionId: z.ZodNullable<z.ZodString>;
        state: z.ZodUnion<readonly [z.ZodLiteral<"idle">, z.ZodLiteral<"open">, z.ZodLiteral<"stopped">, z.ZodLiteral<"error">]>;
        currentUrl: z.ZodNullable<z.ZodString>;
        pageTitle: z.ZodNullable<z.ZodString>;
        tabCount: z.ZodNumber;
        lastActionAtMs: z.ZodNumber;
        idleDeadlineAtMs: z.ZodNullable<z.ZodNumber>;
        lastError: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    browsers: z.ZodArray<z.ZodObject<{
        instanceId: z.ZodString;
        browserName: z.ZodString;
        label: z.ZodString;
        extensionVersion: z.ZodString;
        versionSkew: z.ZodBoolean;
    }, z.core.$strip>>;
    tabs: z.ZodArray<z.ZodObject<{
        tabId: z.ZodString;
        url: z.ZodString;
        title: z.ZodString;
        scope: z.ZodUnion<readonly [z.ZodLiteral<"user">, z.ZodLiteral<"agent">]>;
    }, z.core.$strip>>;
    lastScreenshotPath: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
export declare const browserStopValue: z.ZodObject<{
    stopped: z.ZodBoolean;
    message: z.ZodString;
}, z.core.$strip>;
export declare const browserLiveValue: z.ZodObject<{
    sessionOpen: z.ZodBoolean;
    running: z.ZodBoolean;
    toolName: z.ZodString;
    summary: z.ZodString;
    startedAtMs: z.ZodNumber;
    elapsedMs: z.ZodNumber;
    currentUrl: z.ZodString;
    pageTitle: z.ZodString;
    lastActionAtMs: z.ZodNumber;
    idleDeadlineAtMs: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
export declare const browserInterruptValue: z.ZodObject<{
    interrupted: z.ZodBoolean;
    message: z.ZodString;
}, z.core.$strip>;
export declare const browserPreviewValue: z.ZodObject<{
    dataUrl: z.ZodNullable<z.ZodString>;
    path: z.ZodNullable<z.ZodString>;
    bytes: z.ZodNumber;
    message: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/** 浏览器实例（`bsk browsers --json` 投影）。 */
export type BrowserInstanceView = z.infer<typeof instanceSchema>;
/** 标签页（`bsk tab list --json` 投影）。 */
export type BrowserTabView = z.infer<typeof tabSchema>;
/** 一个 DSH 会话对应的 bsk 会话视图。 */
export type BrowserSessionView = z.infer<typeof sessionSchema>;
/** 右侧面板一次拉取的完整快照。 */
export type BrowserPanelSnapshot = z.infer<typeof browserPanelValue>;
/** 面板「结束会话」结果。 */
export type BrowserStopResult = z.infer<typeof browserStopValue>;
/** 面板截图预览（data URL 有大小上限）。 */
export type BrowserPreviewResult = z.infer<typeof browserPreviewValue>;
/** 面板实时视图：当前动作、耗时与会话状态。 */
export type BrowserLiveView = z.infer<typeof browserLiveValue>;
/** 面板中断结果。 */
export type BrowserInterruptResult = z.infer<typeof browserInterruptValue>;
export {};
