/**
 * dsh-browser-agent Host 半：把 browser-skill 的 bsk CLI 包装成模型工具，
 * 并托管每个 DSH 会话的 bsk 会话。会话回收有四条路径——模型显式调用
 * browser_stop、DSH 会话结束（agent/disposed）、宿主会话不存在时的孤儿回收、
 * 插件卸载——另有空闲巡检兜底，因此不会留下无人关闭的 Agent Window。
 */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { BrowserAgentConfig } from './host/config.js';
import type { BrowserInterruptResult, BrowserLiveView, BrowserPanelSnapshot, BrowserPreviewResult, BrowserStopResult } from './types.js';
export type * from './types.js';
/** BrowserAgent Remote：右侧面板的状态读取、截图预览与会话结束。 */
export declare class BrowserAgent extends TypertRemoteService {
    static inject: string[];
    static Config: import("@deepseek-ai/schemastery").default<BrowserAgentConfig>;
    private readonly config;
    private readonly runner;
    private readonly tracker;
    private readonly store;
    private readonly policy;
    /**
     * @param ctx - 宿主上下文
     * @param config - 部署配置；缺省或给出部分字段时与内置默认值合并
     */
    constructor(ctx: Context, config?: Partial<BrowserAgentConfig>);
    /**
     * 面板状态：daemon/浏览器、本会话的 bsk 会话与 Agent Window 标签页。
     * @param sessionId - DSH 会话 id
     * @returns 面板快照
     */
    panel(sessionId: string): Promise<BrowserPanelSnapshot>;
    /**
     * 结束该 DSH 会话的浏览器会话（面板按钮）。
     * @param sessionId - DSH 会话 id
     * @returns 结束结果
     */
    stop(sessionId: string): Promise<BrowserStopResult>;
    /**
     * 读取最近一次截图供面板预览（有大小上限）。
     * @param sessionId - DSH 会话 id
     * @returns 内联预览，或不可预览的原因
     */
    preview(sessionId: string): Promise<BrowserPreviewResult>;
    /**
     * 面板实时视图：正在执行的动作与耗时，供轮询使用（不含截图）。
     * @param sessionId - DSH 会话 id
     * @returns 实时视图
     */
    live(sessionId: string): BrowserLiveView;
    /**
     * 中断该会话正在执行的动作（面板按钮）。
     * @param sessionId - DSH 会话 id
     * @returns 中断结果
     */
    interrupt(sessionId: string): BrowserInterruptResult;
    /**
     * 组装面板依赖（runner/store/tracker/空闲上限）。
     * @returns 面板依赖
     */
    private panelDeps;
}
export default BrowserAgent;
