/**
 * 浏览器面板：展示 Agent Window 的会话状态、标签页与最近截图，并提供
 * 手动刷新与结束会话。写操作只在 Host 侧发生，这里只读状态。
 */
import type { BrowserPanelApi } from './faces.js';
import type { TFn } from './faces.js';
/** 面板注入的依赖与运行时 props。 */
export interface BrowserBodyInjected {
    api: BrowserPanelApi;
    t: TFn;
}
/** 组件 props：槽位运行时注入的 sessionId 加上本插件的注入面。 */
export type BrowserBodyProps = BrowserBodyInjected & {
    sessionId: string;
};
/**
 * 浏览器面板主体。
 * @param props - 会话 id 与面板 API
 */
export declare function BrowserBody({ sessionId, api, t }: BrowserBodyProps): React.ReactNode;
