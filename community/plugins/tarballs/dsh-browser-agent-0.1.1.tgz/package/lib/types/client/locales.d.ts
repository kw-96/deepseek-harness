/** 浏览器面板文案字典。 */
export declare const zh: {
    readonly tabTitle: "浏览器";
    readonly guideTitle: "浏览器自动化";
    readonly guideDescription: "查看 Agent Window 状态、标签页与最近截图，并可手动结束会话。";
    readonly refresh: "刷新";
    readonly stop: "结束会话";
    readonly stopping: "结束中…";
    readonly loading: "加载中…";
    readonly idle: "未开启";
    readonly open: "运行中";
    readonly sessionId: "会话";
    readonly browser: "浏览器";
    readonly noBrowser: "没有已连接的浏览器";
    readonly currentPage: "当前页面";
    readonly noPage: "尚未打开页面";
    readonly tabs: "标签页";
    readonly noTabs: "Agent Window 内没有标签页";
    readonly screenshot: "最近截图";
    readonly noScreenshot: "本次会话尚未截图";
    readonly showPreview: "查看";
    readonly hidePreview: "收起";
    readonly previewFailed: "截图不可预览";
    readonly live: "实时观测";
    readonly running: "执行中";
    readonly noAction: "空闲";
    readonly elapsed: "已用时";
    readonly interrupt: "中断";
    readonly interrupting: "中断中…";
    readonly stopped: "已结束浏览器会话";
    readonly loadFailed: "读取状态失败";
};
/** 文案键。 */
export type LocaleKey = keyof typeof zh;
export declare const en: Record<LocaleKey, string>;
