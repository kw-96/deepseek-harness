/**
 * 实时观测区：轮询当前动作与耗时，提供中断按钮，并按较慢的节奏刷新截图。
 *
 * 两条节奏是刻意的——`live` 只回状态（很轻，1 秒一次），`preview` 要读图（约 2.5 秒一次），
 * 因此面板打开时的开销可控。
 */
import type { BrowserPanelApi, TFn } from './faces.js';
/** 实时区 props。 */
export interface LiveSectionProps {
    sessionId: string;
    api: BrowserPanelApi;
    t: TFn;
    /** 会话是否处于开启状态；关闭时不轮询。 */
    active: boolean;
}
/**
 * 实时观测区。
 * @param props - 会话 id、面板 API 与文案函数
 */
export declare function LiveSection({ sessionId, api, t, active }: LiveSectionProps): React.ReactNode;
