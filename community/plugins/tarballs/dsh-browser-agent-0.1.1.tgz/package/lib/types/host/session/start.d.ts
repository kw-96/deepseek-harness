/**
 * 启动一个 bsk 会话：解析目标浏览器实例，再把初始运行态交给调用方登记。
 *
 * 多实例时不猜测：直接拒绝并列出候选，让部署方用 `browserInstance` 固定其一，
 * 避免把命令发到用户自己正在用的浏览器上。
 */
import type { BskCommandRunner } from '../bsk.js';
import type { BskSessionRecord } from '../config.js';
/**
 * 计算 `session start` 的目标浏览器参数。
 * @param runner - bsk 命令执行器
 * @param browserInstance - 目标实例（id 或 label）；空串表示要求恰好一个实例
 * @returns 附加参数（配置指定时带 `--browser`，唯一实例时为空）
 */
export declare function browserArgsFor(runner: BskCommandRunner, browserInstance: string): Promise<string[]>;
/**
 * 启动一个新的 bsk 会话。
 * @param runner - bsk 命令执行器
 * @param browserInstance - 目标实例（id 或 label）
 * @param key - 复合会话键（仅用于日志）
 * @returns 初始运行态记录
 */
export declare function startBskSession(runner: BskCommandRunner, browserInstance: string, key: string): Promise<BskSessionRecord>;
