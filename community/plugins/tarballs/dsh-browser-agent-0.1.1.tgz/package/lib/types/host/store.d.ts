/**
 * 会话托管：把每个 DSH 会话映射到一个或多个 bsk 会话（懒启动、引用新鲜度、空闲回收与收尾）。
 *
 * 多会话用一个**复合键**表达：`<dshId>##<alias>`；默认会话仍直接用 `<dshId>`，
 * 因此单会话路径的行为与历史完全一致。插件卸载或 DSH 会话结束时由调用方触发
 * stop，确保 Agent Window 不被遗留。
 */
import type { BskCommandRunner } from './bsk.js';
import type { BskSessionRecord, SessionStoreOptions } from './config.js';
import type { SessionEntry } from './session/list.js';
import type { SnapshotPayload } from './snapshot.js';
import type { ReclaimStore } from './sweep.js';
/** 会话托管器。 */
export declare class BskSessionStore {
    private readonly runner;
    private readonly options;
    private readonly records;
    /** 每个 DSH 会话当前活跃的别名；缺省即默认会话。 */
    private readonly aliases;
    /** 目标浏览器实例；空串表示运行时要求唯一实例。 */
    private readonly browserInstance;
    /**
     * @param runner - bsk 命令执行器
     * @param options - 空闲上限、浏览器实例与日志
     */
    constructor(runner: BskCommandRunner, options: SessionStoreOptions);
    /**
     * 取回或懒启动该 DSH 会话对应的 bsk 会话。
     * @param sessionId - DSH 会话 id
     * @returns 会话运行态
     */
    ensure(key: string): Promise<BskSessionRecord>;
    /**
     * 读取会话运行态。
     * @param sessionId - DSH 会话 id
     * @returns 运行态，或 undefined
     */
    get(sessionId: string): BskSessionRecord | undefined;
    /**
     * 更新会话运行态并刷新活动时间。
     * @param sessionId - DSH 会话 id
     * @param patch - 需要合并的字段
     */
    update(sessionId: string, patch: Partial<BskSessionRecord>): void;
    /**
     * 标记引用失效（导航、点击跳转或任何 DOM 结构变化后调用）。
     * @param sessionId - DSH 会话 id
     */
    markRefsStale(sessionId: string): void;
    /**
     * 本插件当前持有的 bsk 会话 id（用于诊断与「非本插件会话」识别）。
     * @returns bsk 会话 id 列表
     */
    ownedSessionIds(): string[];
    /** 设置某个 DSH 会话的活跃别名（`browser_session use` 用）。 */
    setActiveAlias(dshSessionId: string, alias: string): void;
    /** 取某个 DSH 会话当前活跃的复合键。 */
    activeKey(dshSessionId: string): string;
    /** 列出某个 DSH 会话名下的会话（活跃的在前）。 */
    sessionsOf(dshSessionId: string): SessionEntry[];
    /**
     * 丢弃一个已失效的会话记录（不调用 bsk——会话本身已经不存在）。
     * @param sessionId - DSH 会话 id
     * @param reason - 诊断原因
     * @returns 是否确实丢弃了记录
     */
    drop(sessionId: string, reason: string): boolean;
    /**
     * 结束一个会话并清理记录。
     * @param sessionId - DSH 会话 id
     * @param reason - 触发原因（写入诊断日志）
     * @returns 是否实际结束了会话
     */
    stop(sessionId: string, reason: string): Promise<boolean>;
    /** 结束本插件启动的全部会话（插件卸载时的兜底）。 */
    stopAll(reason: string): Promise<void>;
    /**
     * 结束某个 DSH 会话名下的全部 bsk 会话（含所有别名）。
     * @param dshSessionId - DSH 会话 id
     * @param reason - 触发原因
     * @returns 被结束的复合键
     */
    stopAllOf(dshSessionId: string, reason: string): Promise<string[]>;
    /**
     * 回收空闲超时的会话。
     * @param nowMs - 当前时间
     * @returns 被结束的复合键
     */
    sweepIdle(nowMs: number): Promise<string[]>;
    /**
     * 回收宿主会话已不存在的记录。
     * @returns 被结束的复合键
     */
    reapOrphaned(): Promise<string[]>;
    /**
     * 回收模块需要的最小面（sweep.ts 的入口）。
     * @returns 回收面
     */
    reclaim(): ReclaimStore;
    /**
     * 计算 `session start` 的目标浏览器参数。
     * @returns 附加参数（配置指定时带 `--browser`，唯一实例时为空）
     */
    /**
     * 记录一次快照结果（截断后），并刷新页面信息。
     * @param sessionId - DSH 会话 id
     * @param raw - bsk 返回的快照 JSON 字段
     * @returns 规范化后的快照
     */
    recordSnapshot(sessionId: string, raw: {
        text: string;
        refCount: number;
        truncated: boolean;
    }): SnapshotPayload;
}
