/**
 * 截图附件桥：把截图字节提交到宿主附件库，让工具结果能直接把图给模型看。
 *
 * 只有同时满足「宿主挂了附件库」「字节类型被接受」「不超限额」「该会话当前
 * 模型路由声明支持图像输入」时才提交；任一条件不成立就返回 undefined，
 * 工具结果退回「只给文件路径」的形态。判定失败的默认值一律是「不支持」。
 */
import type { Context } from '@deepseek-ai/cordis';
/** 附件库接受的图片类型。 */
export type ImageMediaType = 'image/png' | 'image/jpeg' | 'image/webp' | 'image/gif';
/** 已提交到宿主附件库的图片引用（结构化面，工具层不依赖宿主类型线）。 */
export interface ImageRefLike {
    attachmentId: string;
    mediaType: ImageMediaType;
    bytes: number;
    width: number;
    height: number;
    name?: string;
}
/** 提交一次截图所需的信息。 */
export interface SaveImageInput {
    /** 归属的 DSH 会话：用于判定该会话的模型路由能否接收图像。 */
    sessionId: string;
    data: Uint8Array;
    mediaType: ImageMediaType;
    name: string;
}
/** 一次提交操作。 */
export type ImageSaver = (input: SaveImageInput) => Promise<ImageRefLike | undefined>;
/**
 * 生成截图提交函数；宿主没有附件库时返回 undefined。
 * @param ctx - 宿主上下文
 * @returns 提交函数，或 undefined
 */
export declare function createImageSaver(ctx: Context): ImageSaver | undefined;
