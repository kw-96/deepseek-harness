import type { ImageMediaType } from './attachment.js';
import { BskError } from './bsk.js';
/**
 * bsk JSON 输出的解析：只保留本插件投影需要的字段，未知字段一律忽略，
 * 因此 bsk 增加字段不会影响插件。
 */
import type { BrowserInstanceView, BrowserTabView } from '../types.js';
/**
 * 解析浏览器实例列表。`bsk status --json` 把实例放在 `browsers` 字段里，
 * 而 `bsk browsers --json` 直接返回数组，两种形状都要支持。
 * @param json - 对象形态的输出
 * @param rows - 数组形态的输出
 * @returns 浏览器实例视图
 */
export declare function parseBrowsers(json: Record<string, unknown> | undefined, rows?: unknown[] | undefined): BrowserInstanceView[];
/**
 * 解析 `bsk session list --json` 的输出（数组形态）。
 * @param rows - 命令返回的数组
 * @returns 会话 id 列表
 */
export declare function parseSessions(rows: unknown[] | undefined): string[];
/**
 * 取 `bsk tab list --json` 里活动标签页的 URL。
 *
 * 点击或按键可能让页面自行跳转，此时 `navigate` 的返回值已经过期；状态查询
 * 与面板用这个派生值给出真实 URL。
 * @param json - 命令返回的 JSON
 * @returns 活动标签页 URL；取不到时为 undefined
 */
export declare function activeTabUrl(json: Record<string, unknown> | undefined): string | undefined;
/**
 * 解析 `bsk tab list --json` 的输出。
 * @param json - 命令返回的 JSON
 * @returns 标签页列表
 */
export declare function parseTabs(json: Record<string, unknown> | undefined): BrowserTabView[];
/** 附件库接受的图片类型。 */
export declare const IMAGE_MEDIA_TYPES: readonly ImageMediaType[];
/**
 * 按魔术字节识别图片类型。
 *
 * 不能信扩展声明的格式：部分 Chromium/Edge 构建的 `captureVisibleTab` 即使
 * 要求 PNG 也会返回 JPEG，声明错类型会被附件库的校验拒绝。
 * @param data - 图片字节
 * @returns 识别出的媒体类型，无法识别时为 undefined
 */
export declare function sniffImageMediaType(data: Uint8Array): ImageMediaType | undefined;
/**
 * 从活动标签页派生真实 URL 并写回会话状态。
 *
 * 点击、按键或脚本都可能让页面自行跳转，此时 `navigate` 的返回值已经过期；
 * 观测结果里的 URL 一律以这里派生出的值为准。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param signal - 取消信号
 */
/**
 * 解析 bsk 的 JSON 输出；非 JSON 时返回 undefined。
 * @param text - 命令 stdout
 * @returns 解析出的对象，或 undefined
 */
export declare function parseJsonObject(text: string): Record<string, unknown> | undefined;
/** 读取字符串字段。 */
export declare function stringField(source: Record<string, unknown> | undefined, key: string): string | undefined;
/** 解析数组形态的 JSON 输出；非数组时返回 undefined。 */
export declare function parseJsonRows(text: string): unknown[] | undefined;
/**
 * 判断错误是否表示「会话已不存在」（被外部结束、daemon 重启等）。
 * 注意与引用失效区分：后者描述的是 ref，不会是 session not registered。
 * @param error - 捕获到的错误
 * @returns 会话已失效时为 true
 */
export declare function isStaleSessionError(error: unknown): error is BskError;
/** 统一的错误文本化。 */
export declare function errorText(error: unknown): string;
/** 把 console / network 的条目压成模型可读的多行文本（每行一条）。 */
export declare function formatDiagnosticEntries(entries: readonly Record<string, unknown>[], kind: string): string;
