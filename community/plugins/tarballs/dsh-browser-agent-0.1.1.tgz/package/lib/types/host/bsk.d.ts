/**
 * bsk CLI 驱动：本插件唯一的执行面。命令一律以 argv 直连（不经 shell），
 * 因此参数里的引号、中文与 `@eN` 引用都原样传递。
 */
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** 普通命令默认超时（毫秒）。 */
export declare const DEFAULT_TIMEOUT_MS = 30000;
/** 导航类命令默认超时（毫秒）。 */
export declare const NAVIGATION_TIMEOUT_MS = 60000;
/** bsk 命令失败（含结构化错误码与原始参数）。 */
export declare class BskError extends Error {
    readonly code: string | null;
    readonly hint: string | null;
    readonly exitCode: number | null;
    /**
     * @param message - 面向模型的一次性说明
     * @param fields - bsk 返回的错误码、建议与退出码
     */
    constructor(message: string, fields: {
        code?: string | null;
        hint?: string | null;
        exitCode?: number | null;
    });
}
/** 一次命令的结果。 */
export interface BskOutcome {
    stdout: string;
    stderr: string;
    exitCode: number | null;
    /** 对象形态的 JSON 输出（多数命令）。 */
    json: Record<string, unknown> | undefined;
    /** 数组形态的 JSON 输出（`session list`）。 */
    rows?: unknown[] | undefined;
}
/** 单次调用的可选项。 */
export interface BskRunOptions {
    timeoutMs?: number;
    /** 非零退出不抛错（探测类命令）。 */
    allowFailure?: boolean;
    /** 取消信号（来自工具执行）。 */
    signal?: AbortSignal | undefined;
}
/**
 * 本插件依赖的 bsk 执行面：会话托管与工具只面向这个接口，
 * 测试可注入脚本化的替身。
 */
export interface BskCommandRunner {
    run(args: readonly string[], options?: BskRunOptions): Promise<BskOutcome>;
    ensureDaemon(): Promise<void>;
}
/** bsk CLI 进程封装。 */
export declare class BskRunner implements BskCommandRunner {
    private readonly subprocess;
    private readonly binary;
    private readonly cwd;
    private readonly log;
    /** 子进程环境覆盖（例如 `BSK_HOME`）；未给时沿用父进程环境。 */
    private readonly env;
    private executablePath;
    private daemonStart;
    /**
     * @param subprocess - 宿主子进程服务
     * @param binary - 可执行文件名或绝对路径（默认 bsk）
     * @param cwd - 子进程工作目录
     * @param log - 诊断日志出口
     */
    constructor(subprocess: SubprocessRuntime, binary: string, cwd: string, log?: (message: string) => void, 
    /** 子进程环境覆盖（例如 `BSK_HOME`）；未给时沿用父进程环境。 */
    env?: Readonly<Record<string, string>> | undefined);
    /**
     * 执行一条命令；失败时抛出带中文建议的 {@link BskError}。
     * @param args - 不含可执行文件的参数
     * @param options - 超时、取消与容错
     * @returns 命令结果（含解析后的 JSON）
     */
    run(args: readonly string[], options?: BskRunOptions): Promise<BskOutcome>;
    /**
     * 确保 daemon 已在后台 detach 运行；幂等，失败只记日志。
     * @returns 首次启动完成后的 Promise
     */
    ensureDaemon(): Promise<void>;
    private startDaemon;
    private executable;
}
