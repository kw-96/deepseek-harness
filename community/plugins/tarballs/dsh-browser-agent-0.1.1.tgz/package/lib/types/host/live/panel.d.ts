/**
 * 面板数据的组装：一次性快照（panel）、截图预览（preview）与实时动作视图（live）。
 *
 * 这些逻辑从插件类里搬出来，宿主半只保留 Remote 方法签名；面板的轮询频率很高，
 * 所以 live 视图刻意不截图——截图由客户端按更慢的节奏单独调 preview。
 */
import type { BskCommandRunner } from '../bsk.js';
import type { BskSessionStore } from '../store.js';
import type { BrowserLiveView, BrowserPanelSnapshot, BrowserPreviewResult, BrowserSessionView } from '../../types.js';
import type { ActionTracker } from './tracker.js';
/** 面板预览内联上限：超过就只给路径。 */
export declare const PREVIEW_MAX_BYTES: number;
/** 面板数据组装所需的依赖。 */
export interface PanelDeps {
    runner: BskCommandRunner;
    store: BskSessionStore;
    tracker: ActionTracker;
    idleTimeoutMs: number;
}
/**
 * 单个 DSH 会话的视图。
 * @param store - 会话托管器
 * @param idleTimeoutMs - 空闲上限（用于算出回收时刻）
 * @param sessionId - DSH 会话 id
 * @returns 会话视图
 */
export declare function sessionView(store: BskSessionStore, idleTimeoutMs: number, sessionId: string): BrowserSessionView;
/**
 * 面板一次性快照：daemon/浏览器、本会话的 bsk 会话与 Agent Window 标签页。
 * @param deps - 面板依赖
 * @param sessionId - DSH 会话 id
 * @returns 面板快照
 */
export declare function panelSnapshot(deps: PanelDeps, sessionId: string): Promise<BrowserPanelSnapshot>;
/**
 * 读取最近一次截图供面板预览。
 * @param store - 会话托管器
 * @param sessionId - DSH 会话 id
 * @returns 内联预览，或不可预览的原因
 */
export declare function previewShot(store: BskSessionStore, sessionId: string): Promise<BrowserPreviewResult>;
/**
 * 实时动作视图：当前动作、耗时与会话状态；不截图。
 * @param deps - 面板依赖
 * @param activeKey - 当前活跃会话的复合键
 * @param nowMs - 当前时间
 * @returns 实时视图
 */
export declare function liveView(deps: PanelDeps, activeKey: string, nowMs: number): BrowserLiveView;
