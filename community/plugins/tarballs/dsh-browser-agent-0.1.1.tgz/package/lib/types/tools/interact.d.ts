/** 交互类工具：点击、填写、按键与下拉选择（写前自动补齐失效引用）。 */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserToolDeps } from './shared.js';
/**
 * 判断目标是引用还是 CSS 选择器。
 * @param target - 模型给出的目标
 * @returns 目标是否为快照引用
 */
export declare function isRef(target: string): boolean;
/**
 * 注册 browser_click / browser_fill / browser_press / browser_select。
 * @param ctx - 宿主上下文（提供 tools 注册表）
 * @param deps - 工具依赖
 */
export declare function registerInteractTools(ctx: Context, deps: BrowserToolDeps): void;
