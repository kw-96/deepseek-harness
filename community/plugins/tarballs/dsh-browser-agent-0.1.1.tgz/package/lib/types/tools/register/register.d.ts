/**
 * 工具注册与包装：所有 `browser_*` 工具都经这里挂到 `ctx.tools`。
 *
 * 包装器承担两件事——把 `session` 别名解析成会话键写进调用上下文（多会话支持），
 * 以及记录/中断当前动作（面板的实时观测）。两者都不需要各工具自己实现。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { BrowserToolDeps } from '../shared.js';
/**
 * 注册一个模型工具，并把释放器绑定到当前 fiber。
 *
 * 仓库约定「注册即 effect」：即便注册表本身不绑定调用方 fiber，插件卸载 /
 * Cordis HMR 热替换时也必须把工具摘干净——否则重挂载会撞上重复工具名。
 * @param ctx - 当前插件上下文
 * @param definition - 工具定义
 */
export declare function registerTool(ctx: Context, deps: BrowserToolDeps, definition: ToolDefinition): void;
