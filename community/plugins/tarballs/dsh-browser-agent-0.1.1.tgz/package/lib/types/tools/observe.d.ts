/** 观测类工具：打开页面与按需升级的观测方式（快照优先，HTML/截图按需）。 */
import type { Context } from '@deepseek-ai/cordis';
import type { BrowserToolDeps } from './shared.js';
/**
 * 注册 browser_open 与 browser_observe。
 * @param ctx - 宿主上下文（提供 tools 注册表）
 * @param deps - 工具依赖
 */
export declare function registerObserveTools(ctx: Context, deps: BrowserToolDeps): void;
