/**
 * 工具层动作封装：命令执行、快照补拍、引用刷新与 DOM 点击表达式。
 * 所有工具的动作都经过这里，保证「引用新鲜」「会话失效即重置」与超时口径一致。
 */
import type { BskOutcome } from '../host/bsk.js';
import type { SnapshotPayload } from '../host/snapshot.js';
import type { BskSessionRecord } from '../host/config.js';
import type { BrowserToolDeps } from './shared.js';
/** 扩展注入的浮层自定义元素名（`clickMode: 'dom'` 需要绕过它）。 */
export declare const OVERLAY_TAG = "browser-skill-overlay";
/**
 * 执行一条带会话上下文的 bsk 命令。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param args - bsk 参数（不含 `--session`）
 * @param options - 超时与取消
 * @returns 命令结果
 */
export declare function runFor(deps: BrowserToolDeps, sessionId: string, args: readonly string[], options?: {
    timeoutMs?: number;
    signal?: AbortSignal;
}): Promise<BskOutcome>;
/** 一次快照的结果：会话运行态与规范化快照。 */
export interface SnapshotOutcome {
    record: BskSessionRecord;
    snapshot: SnapshotPayload;
}
/**
 * 拍一次观测快照并写入会话状态。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param signal - 取消信号
 * @returns 会话运行态与快照
 */
export declare function takeSnapshot(deps: BrowserToolDeps, sessionId: string, signal?: AbortSignal): Promise<SnapshotOutcome>;
/**
 * 写操作前保证引用新鲜：引用已失效时补拍一次快照。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param signal - 取消信号
 * @returns 补拍的快照；引用本就新鲜时为 null
 */
export declare function refreshRefs(deps: BrowserToolDeps, sessionId: string, signal?: AbortSignal): Promise<SnapshotPayload | null>;
/**
 * 记录导航结果（URL）并把引用标记为失效。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param outcome - 导航类命令结果
 */
export declare function recordNavigation(deps: BrowserToolDeps, sessionId: string, outcome: BskOutcome): void;
/** 导航类工具的超时取值。 */
export declare function navigationTimeout(deps: BrowserToolDeps): number;
/**
 * 把毫秒转成 bsk 接受的时长写法（`30s` / `1500ms`）。
 * @param ms - 毫秒
 * @returns bsk 时长参数
 */
export declare function durationArg(ms: number): string;
/**
 * 生成「在 (x, y) 处点击最上层非浮层元素」的 JavaScript 表达式。
 *
 * 0.2.x 的扩展会注入固定定位、`pointer-events: auto` 的 `<browser-skill-overlay>`，
 * 处于 blocking（人工接管）状态时它先接到指针事件，`bsk click` 的点击到不了页面；
 * `clickMode: 'dom'` 改为在目标坐标上直接触发元素 `click()` 并跳过该浮层。
 *
 * 表达式由插件生成、内容固定（只嵌入两个坐标数字、且不含引号），模型无法借它注入脚本。
 * @param x - 视口内 X 坐标（CSS 像素）
 * @param y - 视口内 Y 坐标（CSS 像素）
 * @returns 可直接交给 `bsk evaluate` 的表达式
 */
export declare function domClickExpression(x: number, y: number): string;
