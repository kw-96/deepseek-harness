/** 进阶工具：悬停、诊断（console/network）、移动端模拟与文件传输。 */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserToolDeps } from './shared.js';
/**
 * 注册进阶工具（悬停、诊断、模拟、传输）。
 * @param ctx - 宿主上下文
 * @param deps - 工具依赖
 */
export declare function registerAdvancedTools(ctx: Context, deps: BrowserToolDeps): void;
export declare const transferSchema: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly properties: {
        readonly action: {
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["upload", "download"];
        };
        readonly target: {
            readonly type: "string";
            readonly required: true;
        };
        readonly path: {
            readonly type: "string";
            readonly required: true;
        };
        readonly bytes: {
            readonly type: "integer";
            readonly required: true;
        };
        readonly message: {
            readonly type: "string";
            readonly required: true;
        };
    };
};
