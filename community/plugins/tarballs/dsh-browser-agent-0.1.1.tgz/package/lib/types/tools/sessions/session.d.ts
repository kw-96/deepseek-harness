/**
 * 多会话管理：同一 DSH 会话下可以有多个浏览器会话（别名区分），
 * 其余工具用可选的 `session` 参数指向其中之一，不传就是当前活跃会话。
 */
import type { Context } from '@deepseek-ai/cordis';
import type { BrowserToolDeps } from '../shared.js';
/**
 * 注册 browser_session。
 * @param ctx - 宿主上下文（提供 tools 注册表）
 * @param deps - 工具依赖
 */
export declare function registerSessionTools(ctx: Context, deps: BrowserToolDeps): void;
