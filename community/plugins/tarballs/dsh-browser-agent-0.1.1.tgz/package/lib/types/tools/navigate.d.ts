/** 导航与标签页工具（历史导航刷新引用；标签页默认只看 Agent Window）。 */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserToolDeps, type ExecLike } from './shared.js';
/**
 * 注册 browser_history 与 browser_tabs。
 * @param ctx - 宿主上下文（提供 tools 注册表）
 * @param deps - 工具依赖
 */
export declare function registerNavigateTools(ctx: Context, deps: BrowserToolDeps): void;
/**
 * 执行一次必须获批的操作；未获批时抛出说明性错误。
 * @param deps - 工具依赖
 * @param exec - 工具执行上下文（审批需要发起调用方的 Agent）
 * @param toolName - 记录审批归属的工具名
 * @param reason - 向用户解释为什么需要批准
 */
export declare function requireApproval(deps: BrowserToolDeps, exec: ExecLike & {
    callId?: unknown;
}, toolName: string, reason: string): Promise<void>;
