/**
 * 观测结果的统一形状与截图能力。
 *
 * 截图能力随 bsk 版本变化：0.1.x 的扩展在本机 Edge 上整页截图会失败
 * （`cdp_failed: image readback failed`）而元素截图可用，此时回退到「根节点引用」
 * 得到视口等效截图；0.2.1 起整页截图已可用，回退只剩兜底意义。
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { SnapshotPayload } from '../host/snapshot.js';
import type { BskSessionRecord } from '../host/config.js';
import type { ImageRefLike } from '../host/attachment.js';
import type { BrowserToolDeps } from './shared.js';
export declare function refreshCurrentUrl(deps: BrowserToolDeps, sessionId: string, signal?: AbortSignal): Promise<void>;
/** 模型可见的观测结果。 */
export interface ObservationValue {
    url: string;
    title: string;
    bskSessionId: string;
    refs: number;
    truncated: boolean;
    note: string;
    snapshot: string;
}
/** 观测结果的输出 schema。 */
export declare const observationSchema: {
    readonly type: "object";
    readonly additionalProperties: false;
    readonly properties: {
        readonly url: {
            readonly type: "string";
            readonly required: true;
        };
        readonly title: {
            readonly type: "string";
            readonly required: true;
        };
        readonly bskSessionId: {
            readonly type: "string";
            readonly required: true;
        };
        readonly refs: {
            readonly type: "integer";
            readonly required: true;
        };
        readonly truncated: {
            readonly type: "boolean";
            readonly required: true;
        };
        readonly note: {
            readonly type: "string";
            readonly required: true;
        };
        readonly snapshot: {
            readonly type: "string";
            readonly required: true;
        };
    };
};
/**
 * 由会话运行态与快照组装观测结果。
 * @param record - 会话运行态
 * @param snapshot - 规范化快照
 * @param note - 附加说明（如「点击后已重新快照」）
 * @returns 观测值
 */
export declare function observationValue(record: BskSessionRecord, snapshot: SnapshotPayload, note?: string): ObservationValue;
/** 观测结果的模型输出。 */
export declare const observationRender: (value: unknown) => ContentBlock[];
/** 简单回执的模型输出。 */
export declare const ackRender: (value: unknown) => ContentBlock[];
/** 一次截图的产物。 */
export interface ScreenshotResult {
    path: string;
    bytes: number;
    width: number;
    height: number;
    /** 回退说明，例如「整页截图不被支持，已改用根节点截图」。 */
    note: string;
    /** 已提交到宿主附件库的图像引用；宿主不支持内联时为 undefined。 */
    image?: ImageRefLike | undefined;
}
/**
 * 截取当前标签页；`ref` 为空时先尝试整页，失败后回退到根节点引用。
 * @param deps - 工具依赖
 * @param sessionId - DSH 会话 id
 * @param ref - 可选的快照引用（`@eN`）
 * @param signal - 取消信号
 * @returns 截图产物
 */
export declare function captureScreenshot(deps: BrowserToolDeps, sessionId: string, ref: string | undefined, signal: AbortSignal): Promise<ScreenshotResult>;
