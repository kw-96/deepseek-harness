/**
 * 控制类工具：状态查询、结束会话、人工求助与（默认关闭的）脚本执行。
 * 结束会话走 store，因此不会留下无人回收的 Agent Window。
 */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserToolDeps } from './shared.js';
/**
 * 注册 browser_status / browser_stop / browser_ask_human / browser_evaluate。
 * @param ctx - 宿主上下文（提供 tools 注册表）
 * @param deps - 工具依赖
 */
export declare function registerControlTools(ctx: Context, deps: BrowserToolDeps): void;
