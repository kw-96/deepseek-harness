/**
 * REST transport core for `dsh-github-rest`: URL composition (github.com and
 * GHES bases), authenticated JSON requests over platform `fetch` (ADR-0006),
 * Link-header pagination with a hard page cap, and the single mapping from
 * HTTP outcomes to the seam's {@link GitHubError} vocabulary. Rate limits map
 * to `GITHUB_RATE_LIMITED { retryAfterMs }` and are NEVER retried here — the
 * seam contract hands that decision to the caller.
 * @module dsh-github-rest/http
 */
/** Everything one request needs; assembled per operation so credential and base changes apply live. */
export interface RestTransport {
    /** API root: `https://api.github.com`, or a GHES root such as `https://ghe.example.com/api/v3`. */
    readonly baseURL: string;
    /** The resolved token, sent as a `Bearer` credential. */
    readonly token: string;
    /** The fetch implementation (injectable for keyless replay tests). */
    readonly fetch: typeof globalThis.fetch;
}
/** Options of one JSON request. `PATCH`/`PUT` carry the update and label writes (M10). */
export interface RestRequestOptions {
    readonly method?: 'GET' | 'POST' | 'PATCH' | 'PUT';
    /** Query parameters; `undefined` values are omitted. */
    readonly query?: Readonly<Record<string, string | number | undefined>>;
    /** JSON request body (POST). */
    readonly body?: unknown;
    readonly signal?: AbortSignal | undefined;
}
/** One JSON response plus the absolute `rel="next"` URL when the reply is paginated. */
export interface RestResponse {
    readonly json: unknown;
    readonly next: string | undefined;
}
/** Outcome of a paginated read: aggregated items, and whether pagination ran to the end. */
export interface RestPageResult<T> {
    readonly items: T[];
    /** False when a `rel="next"` page was left unfetched (page cap or early stop). */
    readonly exhausted: boolean;
}
/** Hard cap on followed pages so a runaway listing cannot spin the provider (execution plan M2). */
export declare const MAX_PAGES = 10;
/**
 * Compose an absolute endpoint URL from the configured base, a `/`-prefixed
 * path, and query parameters. Trailing slashes on the base are tolerated so a
 * GHES base configured as `https://ghe.example.com/api/v3/` joins cleanly.
 * @param baseURL - the API root, with or without trailing slashes.
 * @param path - the endpoint path, starting with `/`.
 * @param query - query parameters; `undefined` values are omitted.
 * @returns the absolute URL.
 */
export declare function buildUrl(baseURL: string, path: string, query?: RestRequestOptions['query']): string;
/**
 * Extract the absolute `rel="next"` target of an RFC 8288 `Link` header.
 * @param header - the raw header value, or null when absent.
 * @returns the next-page URL, or undefined on the last page.
 */
export declare function parseLinkNext(header: string | null): string | undefined;
/**
 * Run one authenticated JSON request against an absolute URL and either return
 * the parsed body or throw the mapped {@link GitHubError}. `next` carries the
 * follow-up URL of a paginated reply.
 * @param transport - base, token, and fetch implementation for this operation.
 * @param url - the absolute request URL (from {@link buildUrl} or a `Link` header).
 * @param options - method, body, and cancellation.
 * @returns the parsed JSON body and the optional next-page URL.
 */
export declare function restRequest(transport: RestTransport, url: string, options?: RestRequestOptions): Promise<RestResponse>;
/**
 * Fetch a PLAIN-TEXT endpoint (Actions job logs), following the API's redirect
 * to object storage by hand.
 *
 * The redirect is followed manually and WITHOUT the `Authorization` header
 * (ADR-0015): the target is a different host, and the signed, short-lived URL
 * the API hands back already carries its own grant — forwarding our token there
 * would leak the user's credential to storage infrastructure.
 * @param transport - base, token, and fetch implementation for this operation.
 * @param url - the absolute endpoint URL.
 * @param options - cancellation only; this path is always an unbodied GET.
 * @returns the response body as text.
 */
export declare function restTextRequest(transport: RestTransport, url: string, options?: Pick<RestRequestOptions, 'signal'>): Promise<string>;
/**
 * Follow a paginated listing from its first page, aggregating extracted items,
 * bounded by {@link MAX_PAGES} and an optional early-stop predicate (used by
 * diff reads to stop once a `maxFiles` budget is satisfiable). `exhausted`
 * reports honestly whether a next page was left behind, so callers can set
 * `truncated` without guessing.
 * @param transport - base, token, and fetch implementation for this operation.
 * @param firstUrl - the absolute URL of page one.
 * @param extract - pull the item array out of one page's JSON body.
 * @param options - request options applied to every page.
 * @param enough - optional predicate; once true after a page, later pages stay unfetched.
 * @returns aggregated items and the exhaustion flag.
 */
export declare function restPaginate<T>(transport: RestTransport, firstUrl: string, extract: (json: unknown) => readonly T[], options?: RestRequestOptions, enough?: (items: readonly T[]) => boolean): Promise<RestPageResult<T>>;
