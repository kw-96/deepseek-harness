/**
 * The REST v3 {@link GitHubProvider}: maps the v1 endpoint set onto the seam's
 * normalized vocabulary. Configuration and the credential are re-read on EVERY
 * operation (a changed token or base URL applies without restart), and
 * `createPullRequest` is idempotent per ADR-0004: look up the open PR first,
 * create only on a miss, and re-look-up once when the POST loses a race to a
 * concurrent creation (HTTP 422 "already exists").
 * @module dsh-github-rest/provider
 */
import type { GitHubCheckFailureRequest, GitHubCheckFailuresResult, GitHubChecksResult, GitHubComment, GitHubCommentCreateRequest, GitHubDiff, GitHubDiffRequest, GitHubIssue, GitHubIssueCreateRequest, GitHubItemRef, GitHubLabelsRequest, GitHubMergeability, GitHubProvider, GitHubPullRequest, GitHubPullRequestCreateRequest, GitHubPullRequestCreateResult, GitHubPullRequestListRequest, GitHubPullRequestUpdateRequest, GitHubReview, GitHubReviewComment, GitHubReviewersRequest, GitHubReviewSubmitRequest, GitHubSearchRequest, GitHubSearchResult } from 'dsh-github';
/** The provider's stable registry id. */
export declare const PROVIDER_ID = "rest";
/** Config snapshot one operation runs under, re-read from the source per call. */
export interface ResolvedRestConfig {
    /** Environment-variable name the token resolves through (default `GITHUB_TOKEN`). */
    readonly credentialRef: string;
    /** API root, `https://api.github.com` or a GHES `/api/v3` root. */
    readonly baseURL: string;
}
/** Wiring the provider receives from the plugin layer (or directly from tests). */
export interface RestGitHubProviderOptions {
    /** Current config; consulted at every operation, never cached here. */
    readonly config: () => ResolvedRestConfig;
    /** Resolve the credential ref to a token, or undefined while unconfigured. */
    readonly resolveToken: (credentialRef: string) => Promise<string | undefined>;
    /** Cheap, local, non-network answer to `available()` for the same ref. */
    readonly tokenConfigured: (credentialRef: string) => boolean;
    /** Fetch implementation; defaults to the platform's. */
    readonly fetch?: typeof globalThis.fetch;
}
/**
 * The REST v3 provider. Owns ALL seam operations under one identity and
 * credential (ADR-0003); never retries rate limits (the caller decides).
 */
export declare class RestGitHubProvider implements GitHubProvider {
    readonly id = "rest";
    private readonly options;
    private readonly fetch;
    constructor(options: RestGitHubProviderOptions);
    /** Cheap local check only — no network (seam contract). */
    available(): boolean;
    search(request: GitHubSearchRequest, signal?: AbortSignal): Promise<GitHubSearchResult>;
    getIssue(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubIssue>;
    getPullRequest(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubPullRequest>;
    getComments(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubComment[]>;
    getDiff(item: GitHubItemRef, request: GitHubDiffRequest, signal?: AbortSignal): Promise<GitHubDiff>;
    getChecks(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubChecksResult>;
    getReviews(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubReview[]>;
    getReviewComments(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubReviewComment[]>;
    getCheckFailures(item: GitHubItemRef, request: GitHubCheckFailureRequest, signal?: AbortSignal): Promise<GitHubCheckFailuresResult>;
    /** Annotations of one check run, with the pagination honesty the caller needs. */
    private annotationsOf;
    /**
     * Log of the Actions job behind one check run, or undefined when there is no
     * job to point at or its log is gone. An EXPIRED log (410, mapped to
     * `GITHUB_NOT_FOUND`) is missing evidence rather than a failed read: the
     * annotations gathered alongside it stay usable, so the absence is reported
     * by omission instead of aborting the whole failure read.
     */
    private jobLogOf;
    createIssue(request: GitHubIssueCreateRequest, signal?: AbortSignal): Promise<GitHubIssue>;
    createComment(request: GitHubCommentCreateRequest, signal?: AbortSignal): Promise<GitHubComment>;
    getMergeability(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubMergeability>;
    listPullRequests(request: GitHubPullRequestListRequest, signal?: AbortSignal): Promise<readonly GitHubPullRequest[]>;
    submitReview(request: GitHubReviewSubmitRequest, signal?: AbortSignal): Promise<GitHubReview>;
    updatePullRequest(request: GitHubPullRequestUpdateRequest, signal?: AbortSignal): Promise<GitHubPullRequest>;
    requestReviewers(request: GitHubReviewersRequest, signal?: AbortSignal): Promise<void>;
    setLabels(request: GitHubLabelsRequest, signal?: AbortSignal): Promise<readonly string[]>;
    createPullRequest(request: GitHubPullRequestCreateRequest, signal?: AbortSignal): Promise<GitHubPullRequestCreateResult>;
    /** Look up the open PR for the exact head/base pair, or undefined. */
    private findOpenPullRequest;
    /** URL of one issue/PR read; both families share the `/{collection}/{number}` shape. */
    private itemUrl;
    /**
     * Assemble the transport for ONE operation: config and credential are
     * resolved fresh here, which is the seam's change-without-restart guarantee.
     */
    private transport;
}
