import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type LocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.pluginManager': LocaleKey;
    }
}
export declare const inject: string[];
/** Mount the generated Remote contribution and register the settings tab. */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
export { PluginManagerTab } from './PluginManagerTab.js';
export type { PluginManagerTabApi, PluginManagerTabProps } from './PluginManagerTab.js';
export { McpServersPanel } from './McpServersPanel.js';
export type { McpServersPanelApi, McpServersPanelProps } from './McpServersPanel.js';
export { SkillsPanel } from './skills/SkillsPanel.js';
export type { SkillsPanelApi, SkillsPanelProps } from './skills/SkillsPanel.js';
