import type { McpMutationReceipt, McpServerInput, McpServersSnapshot } from '../types.js';
import type { LocaleKey } from './locales.js';
/** MCP 服务面板可调用的远端操作。 */
export interface McpServersPanelApi {
    list: () => Promise<McpServersSnapshot>;
    save: (input: McpServerInput, enabled: boolean) => Promise<McpMutationReceipt>;
    remove: (serverName: string) => Promise<McpMutationReceipt>;
    setEnabled: (serverName: string, enabled: boolean) => Promise<McpMutationReceipt>;
}
/** MCP 服务面板渲染属性。 */
export interface McpServersPanelProps extends McpServersPanelApi {
    t: (key: LocaleKey) => string;
    locale: string;
}
/** 在插件管理页提供 MCP 服务的列表与编辑。 */
export declare function McpServersPanel(props: McpServersPanelProps): import("react").JSX.Element;
