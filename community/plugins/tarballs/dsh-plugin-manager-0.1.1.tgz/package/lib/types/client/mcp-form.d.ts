import type { McpServerInput, McpServerRecord } from '../types.js';
/** MCP 表单的暂存字段。 */
export interface McpFormState {
    serverName: string;
    transport: 'stdio' | 'streamable-http';
    command: string;
    args: string;
    cwd: string;
    url: string;
    env: string;
    headers: string;
    toolCallTimeoutMs: string;
    enabled: boolean;
}
/** 生成空白表单，默认使用本地进程传输。 */
export declare function emptyMcpForm(): McpFormState;
/** 把一条记录回填为可编辑表单。 */
export declare function formFromRecord(record: McpServerRecord): McpFormState;
/** 把表单暂存内容转换为提交输入。 */
export declare function inputFromForm(form: McpFormState): McpServerInput;
