import type { SkillMutationReceipt, SkillsSnapshot } from '../../types.js';
import type { LocaleKey } from '../locales.js';
/** 技能面板可调用的远端操作。 */
export interface SkillsPanelApi {
    list: () => Promise<SkillsSnapshot>;
    setModelInvocation: (skillName: string, enabled: boolean) => Promise<SkillMutationReceipt>;
}
/** 技能面板渲染属性。 */
export interface SkillsPanelProps extends SkillsPanelApi {
    t: (key: LocaleKey) => string;
    locale: string;
}
/** 在插件管理页提供技能列表与「允许模型调用」开关。 */
export declare function SkillsPanel(props: SkillsPanelProps): import("react").JSX.Element;
