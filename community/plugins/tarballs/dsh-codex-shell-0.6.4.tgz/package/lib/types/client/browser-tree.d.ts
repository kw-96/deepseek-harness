/**
 * 侧栏树体：项目分组 / 扁平列表 / 归档与搜索结果。
 * 状态与动作来自 WorkspaceBrowser。
 */
import type { SessionMetaStore } from './session-meta.js';
import type { BrowserPrefsStore, OrganizeMode, SortMode } from './sidebar/prefs.js';
import type { SearchResultLike, SessionId, SessionListStateLike, TFn, WorkspaceViewLike } from './faces.js';
/** 分组投影结果。 */
export interface GroupsModel {
    grouped: {
        workspace: WorkspaceViewLike;
        sessions: SessionId[];
    }[];
    ungrouped: SessionId[];
    archived: SessionId[];
    flat: SessionId[];
}
export interface BrowserTreeProps {
    groups: GroupsModel;
    list: SessionListStateLike;
    collapsed: ReadonlySet<string>;
    collapsedSubagents: ReadonlySet<string>;
    searching: boolean;
    searchItems: readonly SearchResultLike[];
    searchLoading: boolean;
    renaming: string | null;
    renameDraft: string;
    organize: OrganizeMode;
    sort: SortMode;
    prefs: BrowserPrefsStore;
    onToggleGroup: (key: string) => void;
    onOpen: (sessionId: SessionId) => void;
    onWorkspaceMenu: (event: React.MouseEvent, workspaceId: string) => void;
    onSessionMenu: (event: React.MouseEvent, sessionId: SessionId) => void;
    onArchiveSession: (sessionId: SessionId) => void;
    onToggleWorkspacePin: (workspaceId: string) => void;
    onBeginWorkspaceRename: (workspaceId: string, title: string) => void;
    onToggleSubagents: (key: string) => void;
    setRenameDraft: (value: string) => void;
    commitRename: (sessionId: SessionId) => void;
    commitWorkspaceRename: (workspaceId: string) => void;
    onSessionDrop: (sessionId: SessionId, beforeSessionId: SessionId | undefined, workspaceId: string) => void;
    sessionWorkspaceId: (sessionId: SessionId) => string | undefined;
    meta: SessionMetaStore;
    t: TFn;
}
/** 渲染树体。 */
export declare function BrowserTree(props: BrowserTreeProps): React.ReactNode;
