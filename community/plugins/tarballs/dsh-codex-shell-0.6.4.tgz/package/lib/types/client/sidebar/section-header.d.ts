/**
 * 侧栏「项目」标题栏：标题 + 整理/排序菜单（…）+ 添加工作区（+）。
 */
import type { TFn } from '../faces.js';
import type { OrganizeMode, SortMode } from './prefs.js';
export interface SectionHeaderProps {
    organize: OrganizeMode;
    sort: SortMode;
    onOrganize: (mode: OrganizeMode) => void;
    onSort: (mode: SortMode) => void;
    onAddWorkspace: () => void;
    t: TFn;
}
/** 项目区段标题栏。 */
export declare function SectionHeader(props: SectionHeaderProps): React.ReactNode;
