/**
 * 会话「更多」嵌套菜单：重命名/置顶/未读/归档，以及项目/复制/分叉/打开方式子菜单。
 * 项目归属经 Host attach/detach；跨目录项禁用并附原因。
 */
import type { TFn, WorkspaceViewLike } from '../faces.js';
/** 规范化路径：统一分隔符、去尾斜杠、Windows 盘符小写。 */
export declare function normalizePath(path: string): string;
/** 两路径在规范化后是否指向同一目录。 */
export declare function sameDirectory(left: string | undefined, right: string | undefined): boolean;
/** 会话菜单可执行动作（由浏览器闭包提供）。 */
export interface SessionMenuActions {
    rename(): void;
    togglePin(): void;
    toggleUnread(): void;
    archive(): void;
    moveToWorkspace(workspaceId: string): void;
    moveToUngrouped(): void;
    canMoveToUngrouped: boolean;
    copyCwd(): void;
    copyLink(): void;
    copyMarkdown(): void;
    markdownAvailable: boolean;
    fork(): void;
    openInExplorer(): void;
    openInTerminal(): void;
    openNewWindow(): void;
    pinned: boolean;
    unread: boolean;
    cwd?: string | undefined;
}
export interface SessionMenuProps {
    actions: SessionMenuActions;
    workspaces: readonly WorkspaceViewLike[];
    currentWorkspaceId?: string | undefined;
    t: TFn;
}
/** 渲染会话嵌套菜单内容（不含定位外壳）。 */
export declare function SessionMenuBody(props: SessionMenuProps): React.ReactNode;
