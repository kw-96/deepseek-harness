/** Host service for the dsh-codex-shell integrated Codex-style workspace shell. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { FsContentSearchResponse, FsListResponse, FsNameSearchResponse, FsReadResponse, FsSearchOptions, GitBranchesResponse, GitDiffResponse, GitLogResponse, GitStatusResponse, ProjectAddDirResponse, ProjectDirsResponse, TerminalListResponse, TerminalOpenOptions, TerminalOpenResponse, TerminalReadResponse, TerminalSendResponse } from './types.js';
export type * from './types.js';
/** codexShell Remote: filesystem, git, and per-workspace project directories for the Web shell. */
export declare class CodexShell extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    fsList(path: string): Promise<FsListResponse>;
    fsRead(path: string, maxBytes?: number): Promise<FsReadResponse>;
    fsWrite(path: string, content: string): Promise<{
        ok: true;
    }>;
    fsSearchName(root: string, query: string, options?: FsSearchOptions): Promise<FsNameSearchResponse>;
    fsSearchContent(root: string, query: string, options?: FsSearchOptions): Promise<FsContentSearchResponse>;
    gitStatus(cwd: string): Promise<GitStatusResponse>;
    gitLog(cwd: string, count?: number): Promise<GitLogResponse>;
    gitDiff(cwd: string, path?: string, staged?: boolean): Promise<GitDiffResponse>;
    gitStage(cwd: string, path?: string): Promise<{
        ok: true;
    }>;
    gitUnstage(cwd: string, path?: string): Promise<{
        ok: true;
    }>;
    gitDiscard(cwd: string, path: string): Promise<{
        ok: true;
    }>;
    gitCommit(cwd: string, message: string): Promise<{
        ok: true;
    }>;
    gitBranches(cwd: string): Promise<GitBranchesResponse>;
    gitCheckout(cwd: string, branch: string): Promise<{
        ok: true;
    }>;
    gitFetch(cwd: string): Promise<{
        ok: true;
    }>;
    gitPull(cwd: string): Promise<{
        ok: true;
    }>;
    gitPush(cwd: string): Promise<{
        ok: true;
    }>;
    gitStageAll(cwd: string): Promise<{
        ok: true;
    }>;
    gitUnstageAll(cwd: string): Promise<{
        ok: true;
    }>;
    private terminalOwner;
    private mintUiName;
    /**
     * Open or reconnect one bottom-panel PTY for the live Agent.
     * @param sessionId - live Agent session id.
     * @param options - cwd, unique name, shell dialect, and initial size.
     */
    terminalOpen(sessionId: string, options?: TerminalOpenOptions): Promise<TerminalOpenResponse>;
    /**
     * List owner-scoped PTY sessions for the bottom panel.
     * @param sessionId - live Agent session id.
     */
    terminalList(sessionId: string): Promise<TerminalListResponse>;
    terminalSend(sessionId: string, terminalId: string, text: string): Promise<TerminalSendResponse>;
    /**
     * Stream interactive PTY output to the Web bottom panel (not session-logged).
     * @param sessionId - live Agent session id.
     * @param terminalId - owner-scoped PTY id.
     * @param signal - Remote stream carrier cancellation.
     * @returns decoded frames with CSI preserved.
     */
    terminalFollow(sessionId: string, terminalId: string, signal: AbortSignal): AsyncIterable<{
        seq: number;
        chunk: string;
    }>;
    terminalWrite(sessionId: string, terminalId: string, data: string): Promise<{
        ok: true;
    }>;
    terminalResize(sessionId: string, terminalId: string, cols: number, rows: number): Promise<{
        ok: true;
    }>;
    terminalRead(sessionId: string, terminalId: string): Promise<TerminalReadResponse>;
    terminalClose(sessionId: string, terminalId: string): Promise<{
        ok: true;
    }>;
    projectDirs(workspaceId: string): Promise<ProjectDirsResponse>;
    projectSetDirs(workspaceId: string, dirs: readonly string[]): Promise<ProjectDirsResponse>;
    projectAddDir(workspaceId: string, path: string): Promise<ProjectAddDirResponse>;
}
export default CodexShell;
