/** Cursor-style interactive bottom terminal: xterm.js + live PTY write/follow/resize. */
import '@xterm/xterm/css/xterm.css';
import type { CodexApi } from './RightPanel.js';
import type { SelectorHook, SessionListStateLike, TFn } from './faces.js';
interface BottomTerminalPanelProps {
    api: CodexApi;
    useSessions: SelectorHook<SessionListStateLike>;
    close: () => void;
    t: TFn;
}
/** 当前会话独占的交互式底栏终端面板。 */
export declare function BottomTerminalPanel({ api, useSessions, close, t }: BottomTerminalPanelProps): React.ReactNode;
export {};
