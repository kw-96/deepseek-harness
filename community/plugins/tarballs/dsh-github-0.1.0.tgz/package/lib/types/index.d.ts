/**
 * Service Definition for the GitHub capability seam (`ctx.github`): provider registry and
 * provider-selecting execution for every GitHub operation. Duplicate ids are rejected. At
 * execution time, a configured provider must exist and be usable; without one, exactly one
 * usable provider is required, so selection never depends on registration order. Providers
 * are resolved on EVERY operation and never cached, so credential/config changes take effect
 * without restart.
 * @module dsh-github
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { GitHubCheckFailureRequest, GitHubCheckFailuresResult, GitHubChecksResult, GitHubComment, GitHubCommentCreateRequest, GitHubDiff, GitHubDiffRequest, GitHubIssue, GitHubIssueCreateRequest, GitHubItemRef, GitHubLabelsRequest, GitHubMergeability, GitHubProvider, GitHubPullRequest, GitHubPullRequestCreateRequest, GitHubPullRequestCreateResult, GitHubPullRequestListRequest, GitHubPullRequestUpdateRequest, GitHubReviewersRequest, GitHubReviewSubmitRequest, GitHubReview, GitHubReviewBrief, GitHubReviewBriefRequest, GitHubReviewComment, GitHubSearchRequest, GitHubSearchResult } from './types.js';
export { GitHubError, } from './types.js';
export { buildReviewBrief, changedLines, classifyFile, routeDimensions, type GitHubFileKind } from './review.js';
export type { GitHubAnnotationLevel, GitHubCheckAnnotation, GitHubCheckConclusion, GitHubCheckFailure, GitHubCheckFailureRequest, GitHubCheckFailuresResult, GitHubCheckLog, GitHubCheckRun, GitHubChecksResult, GitHubCheckStatus, GitHubComment, GitHubCommentCreateRequest, GitHubDiff, GitHubDiffFile, GitHubDiffFileStatus, GitHubDiffRequest, GitHubErrorOptions, GitHubIssue, GitHubIssueCreateRequest, GitHubIssueState, GitHubItemRef, GitHubLabelsRequest, GitHubMergeability, GitHubMergeableState, GitHubProvider, GitHubPullRequest, GitHubPullRequestCreateRequest, GitHubPullRequestCreateResult, GitHubPullRequestListRequest, GitHubPullRequestState, GitHubPullRequestUpdateRequest, GitHubRepoRef, GitHubReview, GitHubReviewBrief, GitHubReviewBriefRequest, GitHubReviewComment, GitHubReviewCommentDraft, GitHubReviewDimension, GitHubReviewDimensionBrief, GitHubReviewersRequest, GitHubReviewEvent, GitHubReviewSeverity, GitHubReviewSeverityLevel, GitHubReviewSide, GitHubReviewState, GitHubReviewSubmitRequest, GitHubSearchItem, GitHubSearchKind, GitHubSearchRequest, GitHubSearchResult, } from './types.js';
declare module '@deepseek-ai/cordis' {
    interface Context {
        github: GitHubRuntime;
    }
}
/**
 * Config for the GitHub seam. `provider` pins which provider wins; optional (a
 * single registered usable provider auto-selects). Operational overrides such
 * as environment variables must feed this same field rather than introduce a
 * hidden priority chain.
 */
export interface GitHubRuntimeConfig {
    /** Explicit provider id. Omitted = auto-select when exactly one usable. */
    readonly provider?: string;
}
/**
 * The GitHub service. Registered as `ctx.github` (one instance per context).
 *
 * Selection semantics (resolved at execution time, never order-dependent):
 * - A configured id that is registered and `available()` → that provider.
 * - A configured id not registered → `GITHUB_PROVIDER_CONFIGURED_MISSING`.
 * - A configured id registered but unavailable →
 *   `GITHUB_PROVIDER_CONFIGURED_UNAVAILABLE`.
 * - No id configured, exactly one registered usable provider → that provider.
 * - No id configured, multiple usable providers → `GITHUB_PROVIDER_AMBIGUOUS`.
 * - No id configured, no usable provider → `GITHUB_PROVIDER_UNAVAILABLE`.
 */
export declare class GitHubRuntime extends Service {
    /**
     * Provider selection config. The operational env override feeds the SAME
     * field: `$DSH_GITHUB_PROVIDER` is equivalent to `provider` and is NOT a
     * hidden priority chain.
     */
    static Config: z<GitHubRuntimeConfig>;
    private providers;
    private readonly providerId;
    constructor(ctx: Context, config?: GitHubRuntimeConfig);
    /**
     * Register a GitHub provider. Throws {@link GitHubError}
     * `GITHUB_PROVIDER_DUPLICATE` if its id is already registered. Returns a
     * disposer; disposed with the calling fiber.
     * @param provider - the provider; its `id` is the registry key.
     * @returns the disposer that unregisters the provider.
     */
    registerProvider(provider: GitHubProvider): () => void;
    /**
     * Run one search through the selected provider. The seam enforces
     * `request.maxResults` on the result: if the provider over-returns,
     * `items[]` is truncated and `truncated` set.
     * @param request - the search kind, query, and optional result bound.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the provider's hits, capped to `request.maxResults`.
     */
    search(request: GitHubSearchRequest, signal?: AbortSignal): Promise<GitHubSearchResult>;
    /**
     * Read one issue through the selected provider.
     * @param item - the issue handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized issue.
     */
    getIssue(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubIssue>;
    /**
     * Read one pull request's metadata through the selected provider. Diff and
     * checks are separate on-demand operations.
     * @param item - the pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized pull request.
     */
    getPullRequest(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubPullRequest>;
    /**
     * Read the aggregated conversation comments of an issue or pull request.
     * @param item - the issue or pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized comments.
     */
    getComments(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubComment[]>;
    /**
     * Read one pull request's diff through the selected provider, enforcing the
     * request's budgets at the seam (ADR-0005). The provider may return the diff
     * full or pre-truncated; the final result never exceeds the budgets and
     * `truncated` is true whenever ANY reduction happened.
     * @param item - the pull request handle.
     * @param request - consumer-owned `maxFiles` / `maxPatchChars` budgets.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the budgeted diff.
     */
    getDiff(item: GitHubItemRef, request?: GitHubDiffRequest, signal?: AbortSignal): Promise<GitHubDiff>;
    /**
     * Assemble a structured review brief: the pull request, its budgeted diff,
     * the dimensions that DETERMINISTICALLY apply to it, and the checklists,
     * severity scale, and output contract a review must satisfy (ADR-0013).
     *
     * The seam routes and packages evidence; it never judges. The diff is carried
     * once and dimensions reference its paths, so N dimensions cost one diff.
     * @param item - the pull request handle.
     * @param request - consumer-owned diff budgets plus an optional dimension restriction.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the brief, `truncated` when its diff was reduced.
     */
    buildReviewBrief(item: GitHubItemRef, request?: GitHubReviewBriefRequest, signal?: AbortSignal): Promise<GitHubReviewBrief>;
    /**
     * Read the check runs of a pull request's head commit.
     * @param item - the pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized check runs.
     */
    getChecks(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubChecksResult>;
    /**
     * Read the submitted reviews (verdicts) of a pull request.
     * @param item - the pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized reviews.
     */
    getReviews(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubReview[]>;
    /**
     * Read the line-anchored review comments of a pull request. These are NOT the
     * issue-level conversation comments {@link getComments} returns.
     * @param item - the pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the normalized review comments.
     */
    getReviewComments(item: GitHubItemRef, signal?: AbortSignal): Promise<readonly GitHubReviewComment[]>;
    /**
     * Read failure evidence for a pull request's failing check runs, enforcing
     * the request's log budgets at the seam (ADR-0005 mechanism, ADR-0015
     * policy). The provider may return logs full or pre-truncated; the final
     * result never exceeds the budgets and `truncated` is true whenever ANY
     * reduction happened.
     * @param item - the pull request handle.
     * @param request - consumer-owned `maxLogLines` / `maxLogChars` budgets and log mode.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the budgeted failure evidence.
     */
    getCheckFailures(item: GitHubItemRef, request?: GitHubCheckFailureRequest, signal?: AbortSignal): Promise<GitHubCheckFailuresResult>;
    /**
     * Read a pull request's merge readiness. Callers are expected to consult this
     * BEFORE attempting a merge, so a doomed merge is refused locally with a
     * reason rather than as an opaque HTTP failure.
     * @param item - the pull request handle.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns mergeability with human-readable blockers.
     */
    getMergeability(item: GitHubItemRef, signal?: AbortSignal): Promise<GitHubMergeability>;
    /**
     * List a repository's pull requests, capped at the seam like {@link search}.
     * @param request - repo, filters, and an optional result bound.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the pull requests, capped to `request.maxResults`.
     */
    listPullRequests(request: GitHubPullRequestListRequest, signal?: AbortSignal): Promise<readonly GitHubPullRequest[]>;
    /**
     * Submit one review. The seam does NOT decide whether a verdict is allowed —
     * that gate lives at the tool layer (ADR-0014), because it is a policy about
     * what the MODEL may do, not about what GitHub supports.
     * @param request - target PR, event, and optional body and inline comments.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the submitted review.
     */
    submitReview(request: GitHubReviewSubmitRequest, signal?: AbortSignal): Promise<GitHubReview>;
    /**
     * Update one pull request's own fields.
     * @param request - target PR plus the fields to change.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the updated pull request.
     */
    updatePullRequest(request: GitHubPullRequestUpdateRequest, signal?: AbortSignal): Promise<GitHubPullRequest>;
    /**
     * Request review from users and/or teams.
     * @param request - target PR plus reviewers.
     * @param signal - optional cancellation signal forwarded to the provider.
     */
    requestReviewers(request: GitHubReviewersRequest, signal?: AbortSignal): Promise<void>;
    /**
     * Apply labels to an issue or pull request.
     * @param request - target item, labels, and add-vs-set mode.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the resulting label set.
     */
    setLabels(request: GitHubLabelsRequest, signal?: AbortSignal): Promise<readonly string[]>;
    /**
     * Create one issue through the selected provider.
     * @param request - target repo plus issue content.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the created issue.
     */
    createIssue(request: GitHubIssueCreateRequest, signal?: AbortSignal): Promise<GitHubIssue>;
    /**
     * Create one conversation comment through the selected provider.
     * @param request - target issue/PR handle plus comment body.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the created comment.
     */
    createComment(request: GitHubCommentCreateRequest, signal?: AbortSignal): Promise<GitHubComment>;
    /**
     * Create one pull request through the selected provider. Idempotent
     * (ADR-0004): when an open PR for the same head/base already exists, the
     * provider returns it with `created: false` instead of failing.
     * @param request - target repo, branches, and PR content.
     * @param signal - optional cancellation signal forwarded to the provider.
     * @returns the created or pre-existing pull request with the `created` flag.
     */
    createPullRequest(request: GitHubPullRequestCreateRequest, signal?: AbortSignal): Promise<GitHubPullRequestCreateResult>;
    /** Resolve the selected provider AT CALL TIME or throw the matching {@link GitHubError}. */
    private resolveProvider;
}
export default GitHubRuntime;
