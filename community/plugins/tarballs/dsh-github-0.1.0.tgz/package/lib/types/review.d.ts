/**
 * Deterministic half of a structured review (ADR-0013): classify the changed
 * files, decide which dimensions apply to THIS pull request, and package the
 * evidence with the checklists and output contract the reviewer must satisfy.
 *
 * Nothing here judges code. Every function is total and pure — given the same
 * diff it always routes the same way, which is exactly why this half lives in
 * the host and the findings half lives with the model.
 * @module dsh-github/review
 */
import type { GitHubDiff, GitHubDiffFile, GitHubPullRequest, GitHubReviewBrief, GitHubReviewBriefRequest, GitHubReviewDimension } from './types.js';
/** What kind of file one changed path is. Drives every routing rule below. */
export type GitHubFileKind = 'test' | 'types' | 'docs' | 'code' | 'asset';
/**
 * Classify one changed path.
 *
 * Order matters and encodes precedence: a file under `tests/` that also ends in
 * `.d.ts` is a TEST first — what it is used for beats what it contains.
 * @param path - the repository-relative path.
 * @returns the file kind driving dimension routing.
 */
export declare function classifyFile(path: string): GitHubFileKind;
/**
 * The lines a patch ADDS or REMOVES, without the surrounding context lines.
 *
 * Context is excluded deliberately: a `catch` the author merely happened to
 * scroll past must not route the whole review through error handling.
 * @param patch - unified-diff hunk text, or undefined for a patch-less file.
 * @returns the changed lines with their leading +/- markers stripped.
 */
export declare function changedLines(patch: string | undefined): readonly string[];
/** One routing outcome before checklists are attached. */
interface Route {
    readonly reason: string;
    readonly paths: readonly string[];
}
/**
 * Decide which dimensions apply to a diff, and which files each is about.
 *
 * The rules are intentionally asymmetric. `correctness` and `simplification`
 * ride any executable change, so they nearly always apply — routing earns its
 * keep by EXCLUDING the ones that would otherwise arrive empty (a docs-only PR
 * gets no type review), not by distributing dimensions evenly.
 * @param files - the changed files of the pull request.
 * @returns a route per applicable dimension, in presentation order.
 */
export declare function routeDimensions(files: readonly GitHubDiffFile[]): ReadonlyMap<GitHubReviewDimension, Route>;
/**
 * Assemble a review brief from already-fetched material.
 *
 * Kept separate from the seam operation so the whole deterministic pipeline is
 * testable without a provider.
 * @param pullRequest - the PR under review.
 * @param diff - its budgeted diff; carried into the brief exactly once.
 * @param request - optional dimension restriction from the caller.
 * @returns the brief, with dimensions in presentation order.
 */
export declare function buildReviewBrief(pullRequest: GitHubPullRequest, diff: GitHubDiff, request?: GitHubReviewBriefRequest): GitHubReviewBrief;
export {};
