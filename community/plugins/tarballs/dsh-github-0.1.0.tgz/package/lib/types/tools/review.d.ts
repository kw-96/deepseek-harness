/**
 * The model-facing `github_pr_review` tool: one call that turns "review this
 * PR" from a bare prompt into a task with a known shape — the dimensions that
 * apply, what to check under each, the severity vocabulary, and the contract
 * every finding must satisfy (ADR-0013).
 *
 * This tool orchestrates EVIDENCE, it does not judge. It ships no verdict, no
 * score, and no opinion; the model produces the findings. The review budgets
 * are owned here (tool layer) and enforced at the seam, as with diffs
 * (ADR-0005) — but they are deliberately their own numbers, because a brief is
 * a different cost profile than a plain PR read.
 * @module dsh-github/tools/review
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GitHubReviewDimension } from '../index.js';
import { type ResolvedToolGitHubConfig } from './shared.js';
/** The dimension names the tool accepts, mirroring the seam's closed union. */
export declare const REVIEW_DIMENSIONS: readonly GitHubReviewDimension[];
/** Lean JSON projection of one dimension brief. */
interface DimensionValue {
    readonly dimension: string;
    readonly reason: string;
    readonly paths: readonly string[];
    readonly checklist: readonly string[];
}
/** The value shape `github_pr_review` returns and renders. */
export interface ReviewBriefValue {
    readonly pullRequest: {
        repo: string;
        number: number;
        title: string;
        state: string;
        headRef: string;
        baseRef: string;
        url?: string;
        author?: string;
        draft?: boolean;
        body?: string;
    };
    readonly diff: {
        files: {
            path: string;
            previousPath?: string;
            status: string;
            additions: number;
            deletions: number;
            patch?: string;
        }[];
        truncated: boolean;
    };
    readonly dimensions: readonly DimensionValue[];
    readonly severityScale: readonly {
        level: string;
        meaning: string;
    }[];
    readonly outputContract: readonly string[];
    readonly truncated: boolean;
}
/**
 * Render one brief as the review task the model performs.
 *
 * The diff is printed ONCE and dimensions name their files, rather than each
 * dimension repeating the hunks it cares about — six dimensions over one diff
 * must cost one diff.
 * @param value - the brief projection.
 * @returns the markdown review task.
 */
export declare function formatReviewBrief(value: ReviewBriefValue): string;
/**
 * Register `github_pr_review`: a READ tool (it writes nothing to GitHub and so
 * is not gated by the `write` switch) that returns the structured review task
 * for one pull request.
 * @param ctx - context carrying `ctx.tools` and `ctx.github`.
 * @param config - resolved plugin config (review budgets, timeout).
 */
export declare function applyGitHubPrReviewTool(ctx: Context, config: ResolvedToolGitHubConfig): void;
export {};
