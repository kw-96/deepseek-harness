/**
 * Shared vocabulary of the `github_*` tool suite: the `owner/repo` argument
 * convention, model-friendly error translation, and small pure formatting
 * helpers. Everything here is deliberately presentation-safe (total, throw-free
 * unless documented) because presenters replay logged sessions.
 * @module dsh-github/tools/shared
 */
import { type GitHubRepoRef } from '../index.js';
/** Resolved plugin config: every field present (schema defaults applied). */
export interface ResolvedToolGitHubConfig {
    readonly write: boolean;
    readonly searchMaxResults: number;
    readonly maxComments: number;
    readonly diffMaxFiles: number;
    readonly diffMaxPatchChars: number;
    readonly logMaxLines: number;
    readonly logMaxChars: number;
    readonly reviewMaxFiles: number;
    readonly reviewMaxPatchChars: number;
    readonly reviewVerdicts: boolean;
    readonly timeoutMs: number;
}
/**
 * Parse the model-facing `owner/repo` argument. Throws a plain `Error` (a
 * model-visible argument problem, not a provider failure) on any other shape.
 * @param repo - the raw argument.
 * @returns the seam's repo ref.
 */
export declare function parseRepoInput(repo: string): GitHubRepoRef;
/** The `owner/repo` display label of a repo ref. */
export declare function repoLabel(repo: GitHubRepoRef): string;
/**
 * Validate a positive-integer tool argument the schema DSL cannot bound.
 * @param name - argument name for the diagnostic.
 * @param value - the schema-validated numeric argument.
 */
export declare function assertPositiveArg(name: string, value: number): void;
/**
 * Translate a seam failure into the message a model can act on. Rate limits
 * become a wait-and-retry hint carrying the seam's `retryAfterMs`; auth and
 * not-found name the fix. Anything else passes through unchanged.
 * @param error - whatever the operation threw.
 * @returns the value to rethrow.
 */
export declare function toModelError(error: unknown): unknown;
/**
 * Run one seam operation with model-friendly failure translation.
 * @param op - the operation.
 * @returns the operation's result.
 */
export declare function runGitHub<T>(op: () => Promise<T>): Promise<T>;
/** First line of a body, hard-capped for approval prompts and titles. */
export declare function preview(text: string | undefined, max?: number): string;
