/**
 * The browser-side {@link GitHubUiShell} adapter (ADR-0008): binds the port's
 * members to the dsh client services and plain browser facilities.
 *
 * - `registerSlot('settings.section')` narrows to a `settings.plugin.item`
 *   card (the "插件 → 插件配置" page); the dock keeps its slot name.
 * - `prompt` sends into the session the dock last rendered for — v1 renders
 *   one active conversation at a time, matching the dsh web layout.
 * - `openExternal` opens http(s) URLs only, mirroring the dsh safe-anchor
 *   convention; anything else is silently refused.
 * @module dsh-github/ui/client/shell
 */
import type { GitHubUiShell } from '../types.js';
import type { ClientContext } from './shims.js';
/**
 * Build the shell over the client context.
 * @param ctx - the client plugin's context (slots + sessions services).
 * @returns the port implementation `installGitHubUi` mounts through.
 */
export declare function createBrowserShell(ctx: ClientContext): GitHubUiShell;
