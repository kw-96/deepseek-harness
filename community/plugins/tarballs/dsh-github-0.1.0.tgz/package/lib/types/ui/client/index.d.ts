/**
 * The dsh client half of `dsh-github/ui` (ADR-0008/ADR-0009): self-mounts the
 * hand-written `githubConnect` Remote contribution through `ctx.remote.$mount`
 * (no dsh-repo change required), then installs the connect card and the PR
 * status bar over the browser shell adapter. Locale follows the page
 * language; every registration is an effect on this plugin's fiber.
 * @module dsh-github/ui/client
 */
import type { Context } from '@deepseek-ai/cordis';
import type { UiLocale } from '../i18n.js';
/** Cordis client plugin name. */
export declare const name = "ui-github";
/** Services the client half consumes (ADR-0008: NOT `remote.githubConnect` — this plugin mounts that namespace itself, and injecting it would deadlock). */
export declare const inject: string[];
/**
 * Map a page language to a catalog locale.
 * @param lang - `document.documentElement.lang` or `navigator.language`.
 * @returns the catalog to render with.
 */
export declare function detectLocale(lang: string | undefined): UiLocale;
/**
 * Mount the Remote face and both UI surfaces.
 * @param ctx - the client plugin context.
 */
export declare function apply(ctx: Context): Promise<void>;
