/**
 * Built-in bilingual string catalogs for the two slots. Catalogs are frozen
 * module constants so component callbacks can depend on them without
 * re-rendering churn; the zh-CN strings mirror the design document's wording.
 * @module dsh-github/ui/i18n
 */
import type { ChecksSummary, MergeMethod } from '../connect/index.js';
/** Locales the UI ships built in. */
export type UiLocale = 'en' | 'zh-CN';
/** Every user-visible string of the two slots, parameterized where needed. */
export interface UiCatalog {
    readonly connectLoading: string;
    readonly connectButton: string;
    readonly connectedAs: (login: string) => string;
    readonly connectedAnonymous: string;
    readonly disconnectButton: string;
    readonly connectDescription: string;
    readonly waitingForAuthorization: (userCode: string) => string;
    readonly waitingHint: string;
    readonly openAuthPage: string;
    readonly deviceExpired: string;
    readonly deviceDenied: string;
    readonly deviceFailed: (message: string) => string;
    readonly retryButton: string;
    readonly aheadOfBase: (branch: string, base: string, count: number) => string;
    readonly createPrButton: string;
    readonly creatingButton: string;
    readonly createPrompt: (branch: string, base: string) => string;
    readonly createTimedOut: string;
    readonly dismissLabel: string;
    readonly openPr: (number: number) => string;
    readonly ciBadge: (summary: ChecksSummary) => string;
    readonly reviewButton: string;
    readonly reviewPrompt: (number: number) => string;
    readonly mergeButton: string;
    readonly mergeMethodLabel: (method: MergeMethod) => string;
    readonly openOnGitHub: string;
    readonly mergeConfirm: (number: number, methodLabel: string) => string;
    readonly mergeFailed: (message: string) => string;
    readonly mergeBlocked: (reasons: readonly string[]) => string;
    readonly mergedBanner: (number: number) => string;
}
/**
 * Resolve the frozen catalog for one locale.
 * @param locale - a built-in locale.
 * @returns the catalog constant (stable identity per locale).
 */
export declare function catalogFor(locale: UiLocale): UiCatalog;
