/**
 * Pure view models: what each slot shows as a function of Remote results and
 * forwarded events. Keeping the folds here leaves the components as thin
 * render/dispatch shells and lets every branch be pinned by direct unit tests.
 * @module dsh-github/ui/model
 */
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { DeviceFlowUpdate, GitHubFlowState } from '../connect/index.js';
import type { UiCatalog } from './i18n.js';
import type { ConnectStatus } from './types.js';
/** The settings section's five faces. */
export type ConnectView = {
    kind: 'loading';
} | {
    kind: 'disconnected';
} | {
    kind: 'waiting';
    userCode: string;
    verificationUri: string;
} | {
    kind: 'connected';
    login?: string;
} | {
    kind: 'error';
    reason: 'expired' | 'denied' | 'failed';
    message?: string;
};
/**
 * Fold one `connectStatus()` result into the section view.
 * @param result - the Remote call's result.
 * @returns the view the result proves.
 */
export declare function connectViewFromStatus(result: RemoteResult<ConnectStatus>): ConnectView;
/**
 * Advance the section view on one forwarded Device Flow update.
 * @param view - the current view.
 * @param update - the forwarded `github/device-flow` update.
 * @returns the next view; `slow-down` is pacing-only and changes nothing.
 */
export declare function reduceConnectView(view: ConnectView, update: DeviceFlowUpdate): ConnectView;
/**
 * Localize one error view.
 * @param view - the error view.
 * @param catalog - the active catalog.
 * @returns the message to show next to [Retry].
 */
export declare function connectErrorText(view: Extract<ConnectView, {
    kind: 'error';
}>, catalog: UiCatalog): string;
/** The [Merge ▾] dropdown's strategy order (design §1). */
export declare const MERGE_METHODS: readonly ["squash", "merge", "rebase"];
/**
 * Whether two flow states show the same bar (ADR-0009: the poller applies a
 * refreshed state only on a real transition, so an unchanged poll never
 * closes an open dropdown or discards a draft title). The CI rollup of
 * `pr-open` is deliberately ignored — it updates in place through the badge,
 * not by re-adopting the state.
 * @param a - the currently shown state.
 * @param b - the freshly polled state.
 * @returns whether the bar should keep its current state object.
 */
export declare function sameFlowState(a: GitHubFlowState, b: GitHubFlowState): boolean;
