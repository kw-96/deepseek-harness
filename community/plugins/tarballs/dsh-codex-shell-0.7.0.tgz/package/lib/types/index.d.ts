/** Host service for the dsh-codex-shell bottom multi-tab terminal. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { TerminalListResponse, TerminalOpenOptions, TerminalOpenResponse, TerminalReadResponse, TerminalSendResponse } from './types.js';
export type * from './types.js';
/** codexShell Remote: the bottom panel's PTY sessions for the live Agent. */
export declare class CodexShell extends TypertRemoteService {
    static inject: string[];
    constructor(ctx: Context);
    private terminalOwner;
    private mintUiName;
    /**
     * Open or reconnect one bottom-panel PTY for the live Agent.
     * @param sessionId - live Agent session id.
     * @param options - cwd, unique name, shell dialect, and initial size.
     */
    terminalOpen(sessionId: string, options?: TerminalOpenOptions): Promise<TerminalOpenResponse>;
    /**
     * List owner-scoped PTY sessions for the bottom panel.
     * @param sessionId - live Agent session id.
     */
    terminalList(sessionId: string): Promise<TerminalListResponse>;
    terminalSend(sessionId: string, terminalId: string, text: string): Promise<TerminalSendResponse>;
    /**
     * Stream interactive PTY output to the Web bottom panel (not session-logged).
     * @param sessionId - live Agent session id.
     * @param terminalId - owner-scoped PTY id.
     * @param signal - Remote stream carrier cancellation.
     * @returns decoded frames with CSI preserved.
     */
    terminalFollow(sessionId: string, terminalId: string, signal: AbortSignal): AsyncIterable<{
        seq: number;
        chunk: string;
    }>;
    terminalWrite(sessionId: string, terminalId: string, data: string): Promise<{
        ok: true;
    }>;
    terminalResize(sessionId: string, terminalId: string, cols: number, rows: number): Promise<{
        ok: true;
    }>;
    terminalRead(sessionId: string, terminalId: string): Promise<TerminalReadResponse>;
    terminalClose(sessionId: string, terminalId: string): Promise<{
        ok: true;
    }>;
}
export default CodexShell;
