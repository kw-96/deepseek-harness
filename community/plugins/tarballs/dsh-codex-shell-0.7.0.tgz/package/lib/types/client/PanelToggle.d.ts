/** 会话头工具按钮：一键打开底部终端面板。
 * 桌面独立窗口隐藏（开合按钮由顶部栏在窗口控制按钮左侧提供，参考
 * 左侧栏开合按钮的双模式处理）；右侧面板由官方右栏（ui-sidebar-right）
 * 自己的会话头角落按钮负责开合，本插件不再渲染第二个右侧开合按钮。 */
import type { TFn } from './faces.js';
export interface PanelToggleInjected {
    /** 打开底部终端行（ctx.layout.openBottom）。 */
    setBottomOpen: (open: boolean) => void;
}
export interface PanelToggleProps extends PanelToggleInjected {
    t: TFn;
}
export declare function PanelToggle({ setBottomOpen, t }: PanelToggleProps): React.ReactNode;
