/** Locale dictionary for the codex-shell plugin UI（底栏多 tab 终端）。 */
export declare const zh: {
    readonly bottomTerminal: "终端";
    readonly bottomTerminalClose: "关闭终端面板";
    readonly bottomTerminalCloseTab: "关闭标签";
    readonly bottomTerminalNew: "新建终端";
    readonly bottomTerminalPwsh: "PowerShell";
    readonly bottomTerminalBash: "Bash";
    readonly bottomTerminalAgent: "Agent";
    readonly bottomTerminalStarting: "正在启动终端…";
    readonly bottomTerminalNeedAgent: "终端需要当前会话的 live Agent。";
    readonly bottomTerminalEmpty: "没有打开的终端标签。点 + 新建，或等待 Agent 打开会话。";
    readonly bottomTerminalBusy: "模型正在占用此终端，稍后再键入。";
};
export type LocaleKey = keyof typeof zh;
export declare const en: Record<LocaleKey, string>;
