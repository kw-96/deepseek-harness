/**
 * dsh-codex-shell 浏览器入口：挂载 codexShell Remote（底栏终端）并注册 ——
 * 宿主 bottom 行的多 tab 交互终端，以及会话头的终端开合按钮
 * （桌面独立窗口由顶部栏负责，会话头不渲染）。
 *
 * 左侧项目/工作区/会话导航面属于 dsh-codex-left：本插件不注册任何侧栏
 * 槽位，也不提供右侧面板（右侧由宿主官方右栏 ui-sidebar-right 负责）。
 * 插件/MCP/Skills 统一走宿主「设置 → 插件」。
 *
 * 对宿主编译采用本地结构面（faces.ts）而非宿主编排类型线；运行时的
 * 槽位核心仍会对每个名字做加载期强校验。
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
/**
 * 挂载 Remote 并注册底栏终端与会话头按钮。
 * @param ctx - 客户端根上下文。
 * @returns 卸载函数：注销槽位、文案命名空间与 Remote 贡献。
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
