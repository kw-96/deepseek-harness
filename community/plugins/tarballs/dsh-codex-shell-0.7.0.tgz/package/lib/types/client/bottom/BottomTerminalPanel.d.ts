/** Multi-tab interactive bottom terminal workbench. */
import type { TerminalApi } from './terminal-api.js';
import type { SelectorHook, SessionListStateLike, TFn } from '../faces.js';
interface BottomTerminalPanelProps {
    api: TerminalApi;
    useSessions: SelectorHook<SessionListStateLike>;
    close: () => void;
    t: TFn;
}
/** 当前会话的多 tab 交互式底栏终端面板。 */
export declare function BottomTerminalPanel({ api, useSessions, close, t, }: BottomTerminalPanelProps): React.ReactNode;
export {};
