/** Bottom-panel tab state: UI spawns + Agent list merge. */
import type { TerminalApi } from './terminal-api.js';
import type { TFn } from '../faces.js';
export type ShellDialect = 'bash' | 'pwsh';
export type TabOrigin = 'ui' | 'agent';
export interface BottomTab {
    terminalId: string;
    name?: string;
    origin: TabOrigin;
    title: string;
}
/** Browser-side default dialect for the new-tab menu. */
export declare function defaultShellDialect(): ShellDialect;
/**
 * Merge host list with local dismissals; keep UI tabs the user opened.
 * @param api - Codex Shell remotes.
 * @param sessionId - live Agent session, or undefined when none.
 * @param cwd - optional spawn cwd for new UI tabs.
 * @param t - locale lookup (reserved for future title copy).
 */
export declare function useBottomTerminals(api: TerminalApi, sessionId: string | undefined, cwd: string | undefined, _t: TFn): {
    tabs: BottomTab[];
    activeId: string | null;
    error: string | null;
    setActiveId: (id: string) => void;
    createTab: (dialect: ShellDialect) => Promise<void>;
    closeTab: (id: string) => Promise<void>;
    clearError: () => void;
};
