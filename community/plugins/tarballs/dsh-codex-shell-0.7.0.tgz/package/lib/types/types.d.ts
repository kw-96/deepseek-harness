/** Shared wire types for the dsh-codex-shell Host Remote（底栏终端）。 */
import { z } from 'zod';
export declare const terminalStatusValue: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
    kind: z.ZodLiteral<"running">;
}, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
    kind: z.ZodLiteral<"exited">;
    exitCode: z.ZodNullable<z.ZodNumber>;
    signal: z.ZodNullable<z.ZodString>;
}, z.core.$strip>>]>>;
export declare const terminalOpenOptions: z.ZodReadonly<z.ZodObject<{
    cwd: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    shellDialect: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"bash">, z.ZodLiteral<"pwsh">]>>;
    cols: z.ZodOptional<z.ZodNumber>;
    rows: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>>;
export declare const terminalOpenValue: z.ZodReadonly<z.ZodObject<{
    terminalId: z.ZodString;
    output: z.ZodString;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    name: z.ZodOptional<z.ZodString>;
    origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
}, z.core.$strip>>;
export declare const terminalListEntryValue: z.ZodReadonly<z.ZodObject<{
    terminalId: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
}, z.core.$strip>>;
export declare const terminalListValue: z.ZodReadonly<z.ZodObject<{
    terminals: z.ZodReadonly<z.ZodArray<z.ZodReadonly<z.ZodObject<{
        terminalId: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
            kind: z.ZodLiteral<"running">;
        }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
            kind: z.ZodLiteral<"exited">;
            exitCode: z.ZodNullable<z.ZodNumber>;
            signal: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>]>>;
        origin: z.ZodUnion<readonly [z.ZodLiteral<"ui">, z.ZodLiteral<"agent">]>;
    }, z.core.$strip>>>>;
}, z.core.$strip>>;
export declare const terminalSendValue: z.ZodReadonly<z.ZodObject<{
    output: z.ZodString;
    status: z.ZodReadonly<z.ZodUnion<readonly [z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"running">;
    }, z.core.$strip>>, z.ZodReadonly<z.ZodObject<{
        kind: z.ZodLiteral<"exited">;
        exitCode: z.ZodNullable<z.ZodNumber>;
        signal: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>]>>;
    waitReason: z.ZodString;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const terminalReadValue: z.ZodReadonly<z.ZodObject<{
    output: z.ZodString;
    truncated: z.ZodBoolean;
}, z.core.$strip>>;
export declare const terminalFollowValue: z.ZodReadonly<z.ZodObject<{
    seq: z.ZodNumber;
    chunk: z.ZodString;
}, z.core.$strip>>;
export declare const terminalOkValue: z.ZodReadonly<z.ZodObject<{
    ok: z.ZodLiteral<true>;
}, z.core.$strip>>;
export interface TerminalOpenOptions {
    cwd?: string;
    name?: string;
    shellDialect?: 'bash' | 'pwsh';
    cols?: number;
    rows?: number;
}
export interface TerminalOpenResponse {
    terminalId: string;
    output: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    name?: string;
    origin: 'ui' | 'agent';
}
export interface TerminalListEntry {
    terminalId: string;
    name?: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    origin: 'ui' | 'agent';
}
export interface TerminalListResponse {
    terminals: readonly TerminalListEntry[];
}
export interface TerminalSendResponse {
    output: string;
    status: {
        kind: string;
        exitCode?: number | null;
        signal?: string | null;
    };
    waitReason: string;
    truncated: boolean;
}
export interface TerminalReadResponse {
    output: string;
    truncated: boolean;
}
/** One interactive bottom-terminal output frame. */
export interface TerminalFollowFrame {
    seq: number;
    chunk: string;
}
export interface TerminalWriteResponse {
    ok: true;
}
export interface TerminalResizeResponse {
    ok: true;
}
export interface TerminalCloseResponse {
    ok: true;
}
