# dsh-codex-shell DESIGN.md

Replacement visual world, v2: **Precision Console**. An engineering console
that disappears into the task: layered near-black neutrals, hairline
geometry, one warm orange signal, complete state vocabulary, and tuned
browser surfaces. Operate mode — earned familiarity over expression.

## Color tokens

| Token | Value | Use |
|---|---|---|
| `--cx-bg` | #0e1013 | canvas (sidebar root) |
| `--cx-bg-surface` | #151821 | panel / raised surfaces |
| `--cx-bg-raised` | #1b202a | menus, dialogs, popovers |
| `--cx-bg-inset` | rgba(255,255,255,.04) | inputs, code wells |
| `--cx-text-hi` | #f2f4f7 | primary text |
| `--cx-text-mid` | #b6bdc7 | row text, secondary |
| `--cx-text-low` | #7a828e | sublines, meta, placeholders |
| `--cx-line` | rgba(255,255,255,.08) | hairline borders |
| `--cx-line-strong` | rgba(255,255,255,.16) | focus-adjacent, hover borders |
| `--cx-accent` | #f2734a | current rail, primary actions, focus, running |
| `--cx-accent-strong` | #ff8a5e | accent hover / active |
| `--cx-accent-muted` | rgba(242,115,74,.14) | current tint, accent washes |
| `--cx-hover` | rgba(255,255,255,.055) | hover fills |
| `--cx-active` | rgba(255,255,255,.09) | pressed fills |
| `--cx-success` | #34d17b | completed, success |
| `--cx-warn` | #e8b34b | warnings |
| `--cx-error` | #f87171 | destructive, errors |
| `--cx-info` | #5aa2ff | informational states |

All tokens carry `--dsw-*` fallbacks so the plugin follows the host theme.

## Typography

One system sans family (var(--dsw-font-family, system-ui stack)) for
everything; the mono face is reserved for code, hashes, and measurements.

- Group labels: 10.5px / 650 / +.08em / uppercase
- Session title: 13px / 500; subline 11px / 440 low
- Subagent rows: 12px / 450 low, indent 16px + 1px connector
- Panel body: 12.5px / 1.45; code 12px mono / 1.6
- Tabular figures (`font-variant-numeric: tabular-nums`) on counts, times,
  hashes, sizes
- Text contrast: mid ≥ 4.5:1, low ≥ 4.5:1 on `--cx-bg`

## Shape, space, elevation

- Radii: 8px controls · 10px cards/menus · 12px panels
- 4px grid; groups get more space above than below their heading
- Shadows carry offset + soft blur: menus `0 8px 24px rgba(0,0,0,.5)`,
  panel `-16px 0 40px rgba(0,0,0,.45)`. No hard-offset block shadows.
- Current row: 2px accent left rail + accent-muted fill
- Focus-visible: 2px accent ring, offset 2, on every control

## Motion

160ms ease for state transitions; 200ms cubic-bezier(.2,.8,.2,1) for the
panel slide; 1.6s ease-in-out running pulse. Motion conveys state only —
no load choreography.

## States (every interactive component)

default / hover / active / focus-visible / disabled / loading / error /
empty. Empty states teach the next action; loading uses quiet skeletons or
one shared spinner token, never mid-content spinners.

## Semantic vocabulary

running = accent pulse · completed = success · idle = hollow · archived =
hollow dim · unread = accent badge · pinned = accent pin · destructive =
error red with confirm · save/commit = accent primary.

## Browser surfaces

Text selection, caret, focus rings, scrollbars (8px, rounded, translucent
thumb) themed from the palette; tabular numerals everywhere data appears.

## Rules

- Never redeclare `sidebar.workspaces.directoryFlow`.
- CSS Modules + `--cx-*` only; host globals untouched.
- Icons from one library (lucide), one visual weight.
