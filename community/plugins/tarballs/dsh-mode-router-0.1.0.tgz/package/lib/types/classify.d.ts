/**
 * 逐轮模式分类：把一条用户消息判定为「本轮以什么为验收重心」。
 *
 * 分类是确定性的关键词打分，不额外调用模型：同一段输入永远得到同一结论，
 * 便于测试与事后复核（会话日志里能看到注入文本）。
 * @module dsh-mode-router/classify
 */
/** 三种验收重心，借自 routing-suite 的分类学（只取重心，不改任务与范围）。 */
export type RouteMode = 'correct' | 'experience' | 'research';
/** 一种模式的展示名、验收重心与给模型的动作要求。 */
export interface RouteModeSpec {
    /** 注入文本里的中文模式名。 */
    readonly name: string;
    /** 本轮「什么算合格」的一句话。 */
    readonly center: string;
    /** 给模型的动作要求（不含格式要求，避免与 persona 抢格式）。 */
    readonly directive: string;
}
/** 模式元数据。 */
export declare const ROUTE_MODES: Record<RouteMode, RouteModeSpec>;
/** 一次分类的结论。 */
export interface RouteVerdict {
    /** 命中的模式。 */
    readonly mode: RouteMode;
    /** 该模式的命中次数。 */
    readonly score: number;
    /** 命中的关键词，便于事后复核分类依据。 */
    readonly matched: readonly string[];
}
/**
 * 判定一条用户消息的本轮验收重心。
 * @param message - 用户消息原文
 * @returns 模式、命中次数与命中词；零命中或平局时回落 {@link ROUTE_MODES} 之外的 correct
 */
export declare function classifyTurn(message: string): RouteVerdict;
/**
 * 渲染注入文本：模式名、验收重心、动作要求三行。
 * @param verdict - 分类结论
 * @param note - 可选补充说明（例如开关关闭时的空串）
 * @returns 注入的动态上下文文本
 */
export declare function renderRouteContext(verdict: RouteVerdict, note?: string): string;
