/**
 * mode-router —— 会话级轻量模式路由（自研）。
 *
 * 挂在一个 agent 预设里：每轮读取该会话最近一条用户消息，确定性判定「本轮以
 * 什么为验收重心」，并把它作为**动态上下文**注入。注入走官方的
 * `systemPrompt.context`，默认进入模型历史，因此模型看到的这段文本在会话日志里
 * 可重建、可复核（符合「model-visible ⟺ logged」）。
 * @module dsh-mode-router
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis 插件名。 */
export declare const name = "dsh-mode-router";
/** 依赖 agents 服务来逐 agent 安装注入。 */
export declare const inject: string[];
/** 插件配置。 */
export interface Config {
    /** 关掉即完全不注入（默认开）。 */
    enabled?: boolean;
    /** 动态上下文的排序位（默认排在沙箱/审批策略之后）。 */
    order?: number;
}
/** 动态上下文的默认排序位：紧随内建的沙箱/审批/委派策略。 */
export declare const DEFAULT_ORDER = 130;
/**
 * 挂载逐轮模式路由。
 * @param ctx - agent 平面上下文（预设内）
 * @param config - 预设行传入的配置
 */
export declare function apply(ctx: Context, config?: Config): void;
