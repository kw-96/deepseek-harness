import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
import { type DesktopTitleBarT } from './menus.ts';
export type { DesktopTitleBarT };
/** Props for the desktop title bar. */
export type DesktopTitleBarProps = {
    t: DesktopTitleBarT;
    toggleSidebar: () => void;
    /** 右侧面板开合（官方右栏；组合里无右栏包时由装配层回落到 details 列）。 */
    toggleRightbar: () => void;
    toggleBottom: () => void;
    openBottom: () => void;
    openSession: (id: SessionId) => void;
    useSessions: <S>(sel: (s: SessionListState) => S) => S;
    /** 侧栏收起态：装配层经 inject 的 hooks 注入，标题栏随布局变化重渲染。 */
    useSidebarCollapsed: <S>(sel: (collapsed: boolean) => S) => S;
};
/**
 * Render the Codex-style desktop title bar.
 * @param props - layout actions, session hooks, and locale translator.
 * @returns the title bar element tree.
 */
export declare function DesktopTitleBar(props: DesktopTitleBarProps): import("react").JSX.Element;
//# sourceMappingURL=DesktopTitleBar.d.ts.map