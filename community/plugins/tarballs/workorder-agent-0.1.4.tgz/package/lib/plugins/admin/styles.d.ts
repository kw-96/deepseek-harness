/** 返回 Harness 风格的工单控制面样式。 */
export declare function adminStyles(): string;
