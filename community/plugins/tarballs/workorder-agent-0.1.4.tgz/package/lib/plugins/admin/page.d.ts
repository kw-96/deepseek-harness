/** 返回挂载于 Harness WebServer 的工单控制面。 */
export declare function adminPage(): string;
