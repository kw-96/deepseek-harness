/** 返回不依赖构建产物的控制面浏览器脚本。 */
export declare function adminScript(): string;
