import type { MiddlewareHandler } from 'hono';
/** 创建单进程固定窗口基础限流中间件。 */
export declare function createRateLimit(maxRequests: number, windowMs: number): MiddlewareHandler;
