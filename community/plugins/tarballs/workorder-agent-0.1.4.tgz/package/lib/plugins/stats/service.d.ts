import type { StatsRow } from '../store/issues/repository.js';
import type { WorkorderStore } from '../store/store.js';
import type { QuantityStat, StatsReport } from './types.js';
/**
 * 计算占比统计：占比保留两位小数，总量为 0 时两侧均为 0。
 * @param aiQuantity AI 管线设计数量
 * @param quantity 设计数量总计
 * @returns 数量与占比统计
 */
export declare function toQuantityStat(aiQuantity: number, quantity: number): QuantityStat;
/**
 * 聚合统计报告纯函数，便于单元测试与复用。
 * 总单分类的行不纳入任何统计维度。
 */
export declare function aggregateStats(rows: StatsRow[], startDate?: string, endDate?: string): StatsReport;
/** 工单数据统计服务：读取本地快照并按会话口径聚合。 */
export declare class WorkorderStatsService {
    private readonly store;
    constructor(store: WorkorderStore);
    /**
     * 计算指定周期（按期望交付时间）的工单数据统计。
     * @param startDate 起始日期，缺省不限制
     * @param endDate 结束日期，缺省不限制
     * @returns 统计报告
     */
    compute(startDate?: string, endDate?: string): StatsReport;
}
