import type { AppConfig } from '../../config.js';
import type { IssueSnapshot } from '../../domain/types.js';
import type { WorkorderAgentRouter } from '../../harness/agent.js';
import type { WorkorderStore } from '../store/store.js';
import type { PopoDeliveryService } from '../popo/delivery.js';
export interface IssueReviewRequest {
    traceId?: string;
    triggerType: 'webhook' | 'manual';
    issue: IssueSnapshot;
}
/** 单张工单审核工作流，持久化规则、模型与 POPO 投递结果。 */
export declare class IssueReviewWorkflow {
    private readonly store;
    private readonly delivery;
    private readonly host;
    private readonly review;
    private readonly agent?;
    constructor(store: WorkorderStore, delivery: PopoDeliveryService, host: string, review: AppConfig['review'], agent?: WorkorderAgentRouter | undefined);
    /** 执行规则与模型审核，并在允许时向提单人发送群机器人提醒。 */
    reviewIssue(request: IssueReviewRequest): Promise<string>;
    private reviewByModel;
    private notifySubmitter;
}
