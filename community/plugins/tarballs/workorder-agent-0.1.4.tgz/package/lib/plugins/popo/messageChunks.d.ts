/**
 * 按 POPO UTF-8 字节限制分段，巡检消息按指派人隔离并重复必要上下文。
 * @param message 完整文本消息
 * @returns 可依次发送的消息分段
 */
export declare function splitPopoMessage(message: string): string[];
