export declare const TEST_NOTIFICATION = "\u3010\u8BBE\u8BA1\u5DE5\u5355\u586B\u5199\u63D0\u9192\u3011\nK\u5321\u632F\u5A01\uFF1A\n\u672A\u586B\u5199\u603B\u5DE5\u65F6\uFF1A[#49100](https://promoteart.pm.netease.com/v6/issues/49100)\u3001[#49066](https://promoteart.pm.netease.com/v6/issues/49066)\n\n\u8BF7\u76F8\u5173\u540C\u5B66\u53CA\u65F6\u5B8C\u5584\u5DE5\u5355\u5B57\u6BB5\u3002";
export interface PopoSendResponse {
    msgId: string;
}
/** POPO 自定义群机器人客户端。 */
export declare class PopoClient {
    private readonly url;
    private readonly secret?;
    constructor(url: string, secret?: string | undefined);
    /** 发送单段文本并返回 POPO 消息标识。 */
    sendText(message: string): Promise<PopoSendResponse>;
}
