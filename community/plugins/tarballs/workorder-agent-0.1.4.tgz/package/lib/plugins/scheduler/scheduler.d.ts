import type { InspectionWorkflow } from '../workflow/service.js';
import type { WorkorderStore } from '../store/store.js';
/** 注册每日和每周巡检调度；调度和自动发送分别控制且默认关闭。 */
export declare function startScheduler(workflow: InspectionWorkflow, store: WorkorderStore): () => void;
