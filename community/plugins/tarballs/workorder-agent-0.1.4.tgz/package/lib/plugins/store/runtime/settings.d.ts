import type Database from 'better-sqlite3';
import type { AuditEvent, SettingRecord } from '../types.js';
/** 管理运行开关、配置记录与不可变审计事件。 */
export declare class StoreSettings {
    private readonly db;
    constructor(db: Database.Database);
    /** 写入类型化设置，并保留修改主体。 */
    set(setting: SettingRecord): void;
    /** 读取设置；兼容旧 settings 表记录。 */
    get(key: string): SettingRecord | undefined;
    /** 保存布尔开关。 */
    setFlag(key: string, enabled: boolean, actor: string): void;
    /** 读取布尔开关，缺失或非法值均使用默认值。 */
    getFlag(key: string, fallback: boolean): boolean;
    /** 追加不可变审计事件。 */
    appendAudit(event: AuditEvent): void;
}
