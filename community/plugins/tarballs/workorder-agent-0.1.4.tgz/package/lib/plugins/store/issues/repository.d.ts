import type Database from 'better-sqlite3';
import type { IssueSnapshot } from '../../../domain/types.js';
/** 统计聚合所需的轻量工单行。 */
export interface StatsRow {
    expectedDeliveryDate: string;
    projectName: string;
    artCategory: string;
    aiPipelineTime: unknown;
    designQuantity: unknown;
    gameProduct: string;
    assigneeName: string;
}
/** 持久化工单快照，供巡检按更新时间复用。 */
export declare class IssueRepository {
    private readonly db;
    constructor(db: Database.Database);
    /** 按工单 ID 读取本地快照。 */
    get(id: number): IssueSnapshot | undefined;
    /** 按更新时间倒序列出本地工单快照。 */
    list(limit?: number): IssueSnapshot[];
    /** 返回已入库工单总数。 */
    count(): number;
    /**
     * 返回统计聚合需要的轻量行；可选按期望交付日期（含端点）筛选。
     * @param startDate YYYY-MM-DD 起始日期，缺省不限制
     * @param endDate YYYY-MM-DD 结束日期，缺省不限制
     */
    listStatsRows(startDate?: string, endDate?: string): StatsRow[];
    /** 覆盖写入工单快照。 */
    upsert(issue: IssueSnapshot): void;
}
