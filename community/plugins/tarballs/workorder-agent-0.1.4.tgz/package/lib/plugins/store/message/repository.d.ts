import type Database from 'better-sqlite3';
import type { ClaimedMessageTask, MessageTaskDetail, MessageTaskInput, MessageTaskView } from './types.js';
/** 管理 POPO 消息任务与固定分段的持久状态。 */
export declare class MessageRepository {
    private readonly db;
    constructor(db: Database.Database);
    /** 原子创建消息任务及全部固定分段，重复幂等键返回既有任务。 */
    create(input: MessageTaskInput): MessageTaskDetail;
    /** 读取最近消息任务摘要。 */
    list(limit?: number, status?: string): MessageTaskView[];
    /** 按标识读取消息正文和分段详情。 */
    get(id: string): MessageTaskDetail | undefined;
    /** 按幂等键读取消息。 */
    getByDeliveryKey(key: string): MessageTaskDetail | undefined;
    /** 原子领取可发送任务；已完成或有效租约任务不可重复领取。 */
    claim(id: string, leaseMs?: number): ClaimedMessageTask | undefined;
    /** 将分段置为发送中并续租。 */
    startChunk(taskId: string, sequence: number, owner: string): boolean;
    /** 保存成功分段的远端消息标识并更新汇总进度。 */
    completeChunk(taskId: string, sequence: number, owner: string, msgId: string): boolean;
    /** 完成全部分段并释放租约。 */
    completeTask(id: string, owner: string): boolean;
    /** 保存失败分段和任务状态，达到上限后进入死信。 */
    failChunk(task: ClaimedMessageTask, sequence: number, error: string, uncertain?: boolean): void;
}
