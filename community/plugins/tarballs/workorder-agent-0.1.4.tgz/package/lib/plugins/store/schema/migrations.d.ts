import type Database from 'better-sqlite3';
export declare const LATEST_SCHEMA_VERSION = 5;
/** 执行向前兼容迁移，保留旧数据库中的记录。 */
export declare function migrateSchema(db: Database.Database): void;
