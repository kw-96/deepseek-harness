import type Database from 'better-sqlite3';
import type { IssueReviewRecord, IssueReviewView } from '../types.js';
/** 持久化单张工单的规则、模型与 POPO 审核结果。 */
export declare class ReviewRepository {
    private readonly db;
    constructor(db: Database.Database);
    /** 写入不可变的单次审核记录。 */
    save(record: IssueReviewRecord): void;
    /** 按创建时间倒序返回审核列表。 */
    list(limit?: number): IssueReviewView[];
    /** 返回指定审核记录，不存在时返回 undefined。 */
    get(id: string): IssueReviewView | undefined;
}
