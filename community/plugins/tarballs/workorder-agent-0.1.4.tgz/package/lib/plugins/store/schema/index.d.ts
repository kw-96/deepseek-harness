import type Database from 'better-sqlite3';
/** 初始化持久化表，并以增量迁移保持旧数据兼容。 */
export declare function initializeSchema(db: Database.Database): void;
