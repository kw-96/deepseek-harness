export interface GcpClientConfig {
    url: string;
    host: string;
    userKey: string;
}
/** 官方易协作 MCP 的确定性只读客户端。 */
export declare class GcpClient {
    private readonly client;
    private readonly transport;
    private connected;
    constructor(config: GcpClientConfig);
    /** 建立 MCP 会话。 */
    connect(): Promise<void>;
    /** 返回 MCP 会话是否已成功建立且尚未关闭。 */
    isReady(): boolean;
    /** 调用白名单内的查询工具。 */
    call(name: string, args: Record<string, unknown>): Promise<unknown>;
    /** 关闭 MCP 会话。 */
    close(): Promise<void>;
}
