import type { IssueSnapshot } from '../../domain/types.js';
/** 将易协作详情响应归一化为规则快照。 */
export declare function mapIssueDetail(payload: unknown, fallbackProjectName: string): IssueSnapshot;
/** 将 list_issues 行归一化为规则快照，避免再打详情。 */
export declare function mapListIssue(payload: unknown, fallbackProjectName: string): IssueSnapshot;
export interface IssuePage {
    ids: number[];
    items: unknown[];
    totalCount: number;
    itemCount: number;
}
/** 严格解析列表响应及分页总数，结构异常时抛错。 */
export declare function parseIssuePage(payload: unknown): IssuePage;
