import type { IssueSnapshot, ProjectName } from '../../domain/types.js';
import { GcpClient } from './client.js';
export type ProjectMap = Record<ProjectName, number>;
/** 工单快照缓存，按远端更新时间决定是否覆盖本地记录。 */
export interface IssueSnapshotCache {
    get(id: number): IssueSnapshot | undefined;
    upsert(issue: IssueSnapshot): void;
}
/** 封装三项目分页查询；列表直出字段，更新时间未变则复用本地快照。 */
export declare class GcpIssueService {
    private readonly client;
    private readonly projects;
    private readonly completedStatusId;
    private readonly cache?;
    constructor(client: GcpClient, projects: ProjectMap, completedStatusId: number, cache?: IssueSnapshotCache | undefined);
    /** 查询日期范围内且当前状态为美术完成的工单。 */
    listCompleted(startDate: string, endDate: string): Promise<IssueSnapshot[]>;
    private resolve;
}
