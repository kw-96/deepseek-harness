/** 返回北京时间当天日期。 */
export declare function todayInShanghai(now?: Date): string;
/** 返回上一自然周周一至周日。 */
export declare function previousWeekRange(now?: Date): {
    startDate: string;
    endDate: string;
};
