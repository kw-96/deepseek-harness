import type { IssueSnapshot, Violation } from './types.js';
/** 根据已确认的设计工单规则返回违规项。 */
export declare function inspectIssue(issue: IssueSnapshot): Violation[];
