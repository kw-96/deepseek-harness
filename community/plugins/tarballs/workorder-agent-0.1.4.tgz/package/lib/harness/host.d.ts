import type { Context } from '@deepseek-ai/cordis';
import { Config, type PluginConfig } from './pluginConfig.js';
export declare const name = "workorder-agent-host";
export declare const inject: string[];
export { Config };
/** 工单插件在官方设置中的命名空间。 */
export declare const WORKORDER_SETTINGS_NS = "workorder-agent";
/**
 * 挂载工单 Host：配置走设置卡片，关闭 enabled 时卸载运行时。
 * @param ctx 插件上下文
 * @param config 组合层配置
 */
export declare function apply(ctx: Context, config: PluginConfig): Promise<void>;
