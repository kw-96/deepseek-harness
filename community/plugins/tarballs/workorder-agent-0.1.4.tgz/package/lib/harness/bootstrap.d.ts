import { Hono } from 'hono';
import type { PluginConfig } from './pluginConfig.js';
/** 写入工单设置并等待运行时重载。 */
export type BootstrapWrite = (patch: Record<string, unknown>) => Promise<void>;
/** 构建未配置时的引导路由，接收表单并写入设置。 */
export declare function bootstrapRoute(config: PluginConfig, write: BootstrapWrite): Hono;
