import type { Context } from '@deepseek-ai/cordis';
export declare const WORKORDER_SKILL_NAME = "workorder-webhook-review";
/** 在指定 Agent 作用域挂载工单 Webhook 复核 Skill。 */
export declare function mountWorkorderSkill(agentCtx: Context, knowledgeBase: string): void;
