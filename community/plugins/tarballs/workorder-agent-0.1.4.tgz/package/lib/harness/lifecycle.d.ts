import type { Context } from '@deepseek-ai/cordis';
import { type BootstrapWrite } from './bootstrap.js';
import { type PluginConfig } from './pluginConfig.js';
/** 工单插件运行时：启用时挂载控制面、调度与 Webhook，禁用时完整卸载。 */
export declare class WorkorderPluginLifecycle {
    private readonly ctx;
    private runtime?;
    private agentRouter?;
    private unregister?;
    private active;
    private lastKey?;
    private queue;
    /** 由 Host 注入的设置写入器，未配置时引导页用它保存并重载。 */
    writeSettings: BootstrapWrite;
    /**
     * @param ctx 拥有 WebServer 的插件上下文
     */
    constructor(ctx: Context);
    /**
     * 按最新配置启停运行时；相同配置跳过。
     * @param config 当前生效的插件配置
     */
    apply(config: PluginConfig): Promise<void>;
    /** 停止业务运行时并撤掉路由。 */
    stop(): Promise<void>;
    private applyNow;
    private startNow;
    /** 将业务应用挂到 /workorder-agent 前缀，并补根路径重定向。 */
    private mountGateway;
    private stopNow;
}
