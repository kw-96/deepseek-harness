import type { Context } from '@deepseek-ai/cordis';
import type { AppConfig } from '../config.js';
import type { IssueSnapshot } from '../domain/types.js';
export declare const WORKORDER_AGENT_ID = "workorder-agent-background";
export interface WorkorderAgentRouter {
    reviewIssue(traceId: string, issue: IssueSnapshot): Promise<string>;
}
/** 基于 Harness ctx.agents 的后台单实例工单 Agent 路由器。 */
export declare class HarnessWorkorderAgent implements WorkorderAgentRouter {
    private readonly ctx;
    private readonly review;
    private handle?;
    private creating?;
    private reviewQueue;
    constructor(ctx: Context, review: AppConfig['review']);
    /** 创建或复用唯一后台 Agent，并返回本次工单的模型审核文字。 */
    reviewIssue(traceId: string, issue: IssueSnapshot): Promise<string>;
    private reviewOne;
    /** 停止由该路由器创建的后台 Agent。 */
    close(): Promise<void>;
    private getOrCreate;
    private buildPrompt;
}
