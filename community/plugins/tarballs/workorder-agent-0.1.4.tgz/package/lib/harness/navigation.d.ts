/**
 * 侧边栏入口脚本，不含 script 标签，供 webserver/index-inject 使用。
 * @returns 可内联的经典脚本正文
 */
export declare function controlPanelNavigationScript(): string;
/**
 * 将工单控制面入口注入 HTML，供测试与兼容旧索引变换调用。
 * @param html 原始 HTML
 * @returns 注入侧边栏脚本后的 HTML
 */
export declare function injectControlPanelNavigation(html: string): string;
