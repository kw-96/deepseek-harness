/** 底部持久终端：当前会话的 pwsh PTY 输出、输入、清空和关闭。 */
import type { CodexApi } from './RightPanel.js';
import type { SelectorHook, SessionListStateLike, TFn } from './faces.js';
interface BottomTerminalPanelProps {
    api: CodexApi;
    useSessions: SelectorHook<SessionListStateLike>;
    close: () => void;
    t: TFn;
}
/** 当前会话独占的底部终端面板。 */
export declare function BottomTerminalPanel({ api, useSessions, close, t }: BottomTerminalPanelProps): React.ReactNode;
export {};
