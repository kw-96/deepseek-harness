/**
 * The conversation PR status bar (design §1/§2): mounted above the input,
 * driven by frontend-paced `refreshFlowState` polling (ADR-0009: dsh never
 * forwards `github/flow-state` to the browser) plus an immediate re-sync on
 * `credentials/reference-updated`, hidden for unconnected users. [Create PR] and
 * [Merge] go straight to `@Remote` methods (zero model turns); [AI review] is
 * the one button that spends a turn, through `shell.prompt`. Both the
 * flow-state poller and the CI badge poller back off and STOP while the page
 * is hidden.
 * @module dsh-ui-github/status-bar
 */
import { type ReactElement } from 'react';
import { type UiLocale } from './i18n.js';
import type { GitHubUiRemote, GitHubUiShell } from './types.js';
/** CI badge poll pacing: start at `initialMs`, double to at most `maxMs`. */
export interface PollPolicy {
    readonly initialMs: number;
    readonly maxMs: number;
}
/** Injectable timer pair (tests drive polls and the collapse deterministically). */
export interface StatusBarTimers {
    setTimeout(fn: () => void, ms: number): unknown;
    clearTimeout(handle: unknown): void;
}
/** Real timers, used unless a test injects its own. */
export declare const defaultTimers: StatusBarTimers;
/** Props of {@link PrStatusBar}. */
export interface PrStatusBarProps {
    readonly remote: GitHubUiRemote;
    readonly shell: GitHubUiShell;
    readonly locale?: UiLocale;
    readonly poll?: PollPolicy;
    /** Flow-state poll pacing (ADR-0009), independent of the CI badge's. */
    readonly flowPoll?: PollPolicy;
    readonly collapseMs?: number;
    /** Loading cap of the agent-driven [Create PR] (ADR-0011). */
    readonly createTimeoutMs?: number;
    readonly timers?: StatusBarTimers;
}
/**
 * The PR status bar.
 * @param props - the client remote, the shell port, and optional pacing knobs.
 * @returns the bar element, or null while hidden.
 */
export declare function PrStatusBar(props: PrStatusBarProps): ReactElement | null;
