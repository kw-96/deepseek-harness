/**
 * The settings page's "Connect GitHub" section (design §1, mounted as the
 * plugin-config card per ADR-0008): [Connect GitHub] opens the Device Flow
 * authorization page with the user code auto-copied, progress arrives by
 * polling `deviceFlowStatus` at the server-dictated interval (ADR-0009: dsh
 * never forwards `github/device-flow` to the browser), and a connected user
 * sees `@login` plus [Disconnect]. Written with `createElement` so the
 * package stays inside the repo's `.ts`-only build.
 * @module dsh-ui-github/settings-section
 */
import { type ReactElement } from 'react';
import { type UiLocale } from './i18n.js';
import { type StatusBarTimers } from './status-bar.js';
import type { GitHubUiRemote, GitHubUiShell } from './types.js';
/** Props of {@link ConnectGitHubSection}. */
export interface ConnectSectionProps {
    readonly remote: GitHubUiRemote;
    readonly shell: GitHubUiShell;
    readonly locale?: UiLocale;
    /** Injectable timers (tests drive the status poll deterministically). */
    readonly timers?: StatusBarTimers;
}
/**
 * The "Connect GitHub" settings section.
 * @param props - the client remote, the shell port, and an optional locale.
 * @returns the section element.
 */
export declare function ConnectGitHubSection(props: ConnectSectionProps): ReactElement;
