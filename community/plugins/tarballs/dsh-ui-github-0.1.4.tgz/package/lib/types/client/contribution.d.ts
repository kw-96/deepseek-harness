/**
 * Hand-written Typert Remote contribution for the `githubConnect` namespace,
 * mounted by this package's client half through `ctx.remote.$mount`
 * (ADR-0008/ADR-0009: verified viable for an out-of-repo plugin — the dsh
 * gateway has no namespace whitelist and mounting has no boot-phase
 * restriction). Once the dsh Typert generator runs over
 * `dsh-github-connect`, its `./remote` artifact replaces this module.
 *
 * Two wire contracts this module must keep by hand:
 *
 * 1. Every `wire` field equals the host method's formal parameter name — the
 *    gateway's source-mode discovery derives wire fields from
 *    `Function.prototype.toString()` (`createPr(request)` → `request`).
 * 2. Every codec is `mode: 'strict'` and materializes a `TypertSchema` (a
 *    callable `parse`) through `create()` — the dsh client refuses SRC
 *    descriptors, and validates each argument and result through these
 *    parsers.
 * @module dsh-ui-github/client/contribution
 */
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** The `githubConnect` Remote face (mirrors `GitHubConnectService`'s @Remote methods). */
export declare const GITHUB_CONNECT_REMOTE: TypertRemoteContribution;
