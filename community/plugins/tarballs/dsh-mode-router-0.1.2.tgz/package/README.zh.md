# dsh-mode-router

[English](README.md) | 中文

挂在 DeepSeek Harness 的 agent 预设里的**逐轮模式路由**。每轮它读取本会话最近一条用户消息，用关键词打分**确定性地**判定「本轮以什么为验收重心」（不额外调用模型），再通过官方的 `systemPrompt.context` 扩展点把结论作为**动态上下文**注入。动态上下文默认进入模型历史，因此这段注入文本会留在会话日志里，事后可回放、可复核。

## 三种模式

| 模式 | 何时选中 | 注入的要求 |
| --- | --- | --- |
| `correct` 正确性 | 主体是代码/数据/接口/命令等可测量行为 | 先拿到可复核的证据（命令输出、测试结果、文件行号、接口回包）再下结论 |
| `experience` 体验 | 主体是视觉/交互/手感/文案 | 先写清将要看到的画面或交互，改完提示用户亲眼确认，不要只凭代码推断观感 |
| `research` 研究 | 主体是分析/比较/论证 | 每条结论标注来源，并区分事实与推断 |

零命中（或平局无法更具体）时回落到 `correct`；平局优先级为 研究 → 体验 → 正确性。

## 配置

| 字段 | 默认 | 含义 |
| --- | --- | --- |
| `enabled` | `true` | 设为 `false` 则完全不挂载、不注入 |
| `order` | `130` | 动态上下文排序位，排在内建的沙箱（110）、审批（115）、委派（120）策略之后 |

## 挂载方式

本包是**插件行**而非组合补丁：由预设按包名引用它。

```yaml
- id: mode-router
  name: dsh-mode-router
  config:
    enabled: true
```

本包同时声明「模式路由（自动）」预设：`bundle.patch.yml` 里插入一行 `@deepseek-ai/dsh-agent-preset`（id `mode-router`），行集取官方随附 `standard` 加四处本地定制——persona 追加中文回复要求、启用 `tool-ralph`、去掉已下线的 `tool-plugin-manager`、末尾追加本插件的 `mode-router` 行。装好本包（`pnpm build` 后打包，或让 `community/plugins/dev.mjs` 建立 junction）即得到该预设，无需另行维护预设文件。

0.1.7 之前预设是 `$DSH_HOME/.agent-presets/<id>/` 目录（`preset.yml` + `agent.cordis.yml`）；该目录已无人读取，仓库里的 `community/presets/` 已随本包声明一并删除。

## 兼容性

- 0.1.1 起兼容 DSH 0.2.1+：persona 行不再写 `suffix: Your working directory is {{cwd}}.`。DSH 0.2.1 不再注册 `cwd` 提示词变量，模板里出现未注册变量会让整轮运行在 prompt 组装阶段直接失败；官方 `standard` 预设也已删掉这一句。
- 0.1.0 及更早版本只适用于注册过 `cwd` 变量的旧运行时（0.2.0 系列）。

## 证据落在哪里

- 注入文本作为动态上下文进入模型请求，可从会话日志重建（`session.v3.jsonl.zstd` 为多帧 zstd，格式见仓库的会话持久化实现）。
- 分类器是纯函数（`src/classify.ts`），单测在 `tests/classify.spec.ts`：同一输入必得同一结论，且结论里带**命中的关键词**，便于事后核对。

## 已知限制与后续

- 分类刻意只用关键词打分：零成本、确定性、可解释；对于没有任何领域词的一句话会判错，但注入行会写明命中的关键词，因此判错是可见的而非静默的。
- 路由只改变「本轮按什么验收」，不增删工具、不切模型、不改会话预设——那些仍是会话级选择。
- 只按最近一条用户消息判定；一轮之内话题中途变化的，仍沿用该轮最初的结论。
