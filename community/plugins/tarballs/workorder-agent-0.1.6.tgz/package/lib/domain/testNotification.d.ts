/**
 * 生成固定测试通知文案；正文使用接收人本身，不做 @。
 * @param receiver 接收人（用户邮箱或群 ID）
 * @returns 测试消息正文
 */
export declare function buildTestNotification(receiver: string): {
    message: string;
};
