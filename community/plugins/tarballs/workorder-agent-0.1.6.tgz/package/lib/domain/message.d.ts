import type { IssueSnapshot, Violation } from './types.js';
/** 生成易协作工单详情地址。 */
export declare function issueUrl(host: string, issueId: number): string;
/** 按指派人聚合正式巡检消息，并附加工单详情链接。 */
export declare function buildInspectionMessage(title: string, violations: Violation[], host: string): string | null;
/**
 * 生成面向**指派给（设计师）**的单工单补全提醒文本。
 * 工单由运营提单、指派给设计师，字段由设计师本人补齐，因此该提醒以单聊发给指派给，
 * 正文只显示姓名、不使用 @ 占位；接收人取不到邮箱时由调用方回退默认接收人。
 * @param issue 工单快照
 * @param violations 规则缺项
 * @param modelOutput 模型审核结论
 * @param host 易协作 Host
 */
export declare function buildIssueReviewMessage(issue: IssueSnapshot, violations: Array<{
    ruleId: string;
    message: string;
}>, modelOutput: string, host: string): {
    message: string;
    receiver: string;
};
