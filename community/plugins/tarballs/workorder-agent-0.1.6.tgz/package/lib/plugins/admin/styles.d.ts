/** 返回 Ticket Hub 控制面样式。 */
export declare function adminStyles(): string;
