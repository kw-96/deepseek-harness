/** 返回挂载于 Harness WebServer 的 Ticket Hub 控制面。 */
export declare function adminPage(): string;
