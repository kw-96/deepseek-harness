import { Hono } from 'hono';
import type { AppConfig } from '../../config.js';
import type { WorkorderAgentRouter } from '../../harness/agent.js';
import type { GcpIssueService } from '../gcp/service.js';
import type { PopoDeliveryService } from '../popo/delivery.js';
import type { WorkorderStatsService } from '../stats/service.js';
import type { WorkorderStore } from '../store/store.js';
import type { VivoService } from '../vivo/service.js';
import type { WebhookRequestLog } from '../webhook/log.js';
import type { InspectionWorkflow } from '../workflow/service.js';
import type { IssueReviewWorkflow } from '../workflow/review.js';
/** 控制面配置更新器；更新完成前必须等待 Host 重载。 */
export type PluginSettingsWrite = (patch: Record<string, unknown>) => Promise<void>;
export interface AdminRouteDependencies {
    config: AppConfig;
    store: WorkorderStore;
    issues: GcpIssueService;
    delivery: PopoDeliveryService;
    workflow: InspectionWorkflow;
    review: IssueReviewWorkflow;
    stats: WorkorderStatsService;
    vivo: VivoService;
    webhookLog: WebhookRequestLog;
    agentRouter?: WorkorderAgentRouter;
    writePluginSettings?: PluginSettingsWrite;
}
/** 注册 Ticket Hub 控制面的管理 API。 */
export declare function installAdminRoutes(app: Hono, dependencies: AdminRouteDependencies): void;
