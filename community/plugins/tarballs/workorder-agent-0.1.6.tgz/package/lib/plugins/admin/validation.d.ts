import { z } from 'zod';
export declare const dateRangeSchema: z.ZodObject<{
    startDate: z.ZodString;
    endDate: z.ZodString;
}, z.core.$strip>;
export declare const previewIdSchema: z.ZodString;
export declare const messageIdSchema: z.ZodString;
export declare const issueIdSchema: z.ZodCoercedNumber<unknown>;
export declare const resumeMessageSchema: z.ZodObject<{
    confirmation: z.ZodLiteral<"确认从失败分段继续发送">;
}, z.core.$strip>;
export declare const sendPreviewSchema: z.ZodObject<{
    previewId: z.ZodString;
    confirmation: z.ZodLiteral<"确认发送正式巡检结果">;
}, z.core.$strip>;
export declare const resendPreviewSchema: z.ZodObject<{
    confirmation: z.ZodLiteral<"确认再次发送复核结果">;
}, z.core.$strip>;
/** 控制面允许在线修改的非敏感运行设置。 */
export declare const runtimeSettingsSchema: z.ZodObject<{
    scheduleEnabled: z.ZodOptional<z.ZodBoolean>;
    automaticSendEnabled: z.ZodOptional<z.ZodBoolean>;
    webhookProcessingEnabled: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
/** 模型审核与提单规范配置，服务商和模型 ID 必须成对提供。 */
export declare const reviewSettingsSchema: z.ZodObject<{
    reviewEnabled: z.ZodBoolean;
    reviewProvider: z.ZodString;
    reviewModel: z.ZodString;
    reviewMaxTokens: z.ZodNumber;
    reviewKnowledgeBase: z.ZodString;
    reviewNotificationEnabled: z.ZodBoolean;
}, z.core.$strip>;
/** 数据统计查询参数：日期可缺省，同时提供时校验先后顺序。 */
export declare const statsQuerySchema: z.ZodObject<{
    startDate: z.ZodOptional<z.ZodString>;
    endDate: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** vivo 采集请求：可选的目标游戏名列表。 */
export declare const vivoCollectSchema: z.ZodObject<{
    targets: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
/** vivo 推送请求：可选的采集轮次。 */
export declare const vivoRunSchema: z.ZodObject<{
    runId: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** vivo 截图请求：轮次与文件名，文件名仅允许单段。 */
export declare const vivoShotSchema: z.ZodObject<{
    runId: z.ZodString;
    file: z.ZodString;
}, z.core.$strip>;
