import { IssueRepository } from './issues/repository.js';
import { MessageRepository } from './message/repository.js';
import { ReviewRepository } from './reviews/repository.js';
import { VivoRepository } from '../vivo/repository.js';
import type { AuditEvent, PreviewDetail, PreviewRecord, PreviewView, RunRecord, SettingRecord, StoreHealth, WebhookEventView, WebhookTask } from './types.js';
export type { AuditEvent, IssueReviewRecord, IssueReviewView, PreviewDetail, PreviewRecord, PreviewView, RunRecord, SettingRecord, StoreHealth, WebhookEventView, WebhookTask } from './types.js';
/** 巡检、租约、设置与审计的 SQLite 存储。 */
export declare class WorkorderStore {
    private readonly db;
    readonly messages: MessageRepository;
    readonly issues: IssueRepository;
    readonly reviews: ReviewRepository;
    readonly vivo: VivoRepository;
    private readonly settings;
    constructor(path: string);
    /** 写入巡检批次。 */
    saveRun(run: RunRecord): void;
    /** 返回最近巡检批次。 */
    listRuns(limit?: number): RunRecord[];
    /** 获取发送租约；过期 pending 记录允许恢复。 */
    beginDelivery(key: string, leaseMs?: number): string | undefined;
    /** 标记发送成功，仅当前租约所有者可以提交。 */
    markDeliverySent(key: string, owner: string): boolean;
    /** 标记发送失败，仅当前租约所有者可以提交。 */
    markDeliveryFailed(key: string, owner: string, error: string): boolean;
    /** 保存不可变正式预览。 */
    savePreview(preview: PreviewRecord): void;
    /** 返回最近正式预览的脱敏视图。 */
    listPreviews(limit?: number): PreviewView[];
    /** 返回指定正式预览的安全详情，不暴露哈希和内部结果 JSON。 */
    getPreviewDetail(id: string): PreviewDetail | undefined;
    /** 读取任意状态的正式预览，用于人工确认后的再次发送。 */
    getPreview(id: string): PreviewRecord | undefined;
    /** 读取尚未发送且未过期的正式预览。 */
    getActivePreview(id: string): PreviewRecord | undefined;
    /** 原子标记预览已发送。 */
    markPreviewSent(id: string): boolean;
    /** 返回最近 Webhook 事件的脱敏视图。 */
    listWebhooks(limit?: number): WebhookEventView[];
    /** 保存 Webhook 后台任务；重复 trace_id 返回 false。 */
    saveWebhook(task: Omit<WebhookTask, 'status' | 'attempts'>): boolean;
    /** 领取一个到期或租约过期的 Webhook 任务。 */
    claimWebhook(leaseMs?: number): WebhookTask | undefined;
    /** 完成 Webhook 审核，并校验租约所有者。 */
    completeWebhook(task: WebhookTask, result: unknown): void;
    /** 记录 Webhook 失败，达到上限后写入死信状态。 */
    failWebhook(task: WebhookTask, error: string): void;
    /** 写入类型化设置，并保留修改主体。 */
    setSetting(setting: SettingRecord): void;
    /** 读取设置；兼容旧 settings 表记录。 */
    getSetting(key: string): SettingRecord | undefined;
    /** 保存布尔开关。 */
    setFlag(key: string, enabled: boolean, actor?: string): void;
    /** 读取布尔开关，缺失或非法值均使用默认值。 */
    getFlag(key: string, fallback?: boolean): boolean;
    /** 追加不可变审计事件。 */
    appendAudit(event: AuditEvent): void;
    /** 检查迁移状态和数据库写能力。 */
    health(): StoreHealth;
    /** 关闭数据库连接。 */
    close(): void;
}
