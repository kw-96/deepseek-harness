import type { SendOptions } from './sender.js';
/** POPO 机器人应用客户端参数。 */
export interface PopoAppOptions {
    /** 开放平台地址，默认线上环境 */
    baseUrl?: string;
    appId: string;
    appSecret: string;
    /** 默认接收人：用户邮箱或群 ID */
    receiver: string;
}
export interface PopoAppSendResponse {
    msgId: string;
}
/** text 类型正文上限（官方文档：3000 字符）。 */
export declare const MAX_TEXT_CHARACTERS = 3000;
/**
 * 机器人应用通道：先用 App 凭证换取 accessToken，再以 Open-Access-Token 头发送文本消息。
 * 与自定义群机器人 Webhook 客户端接口一致，可直接替换。
 */
export declare class PopoAppClient {
    private readonly options;
    private token?;
    private expiresAt;
    constructor(options: PopoAppOptions);
    /**
     * 发送单段文本；调用方保证正文不超过文本上限。
     * @param message 消息正文
     * @param options 本条消息的接收人，缺省用配置的默认接收人
     * @returns POPO 消息标识
     */
    sendText(message: string, options?: SendOptions): Promise<PopoAppSendResponse>;
    /** 取 accessToken；未过期时复用缓存。 */
    private accessToken;
    private post;
}
/**
 * 把开放平台错误码翻译成可读中文。
 * @param errcode 错误码
 * @param errmsg 平台原始文案
 */
export declare function describeError(errcode: number | undefined, errmsg: string | undefined): string;
