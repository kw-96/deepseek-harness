import type { WorkorderStore } from '../store/store.js';
import type { MessageTaskResult } from '../store/message/types.js';
import type { MessageSender } from './sender.js';
export interface DeliveryInput {
    key: string;
    message: string;
    sourceType: string;
    sourceId?: string;
    actor: string;
    automatic?: boolean;
    /** 本条消息的接收人；缺省用发送器默认接收人（例如单聊发给提单人本人）。 */
    receiver?: string;
}
/** 可靠 POPO 投递服务，负责持久化分段、顺序发送和失败续发。 */
export declare class PopoDeliveryService {
    private readonly store;
    private readonly client;
    constructor(store: WorkorderStore, client: MessageSender);
    /** 创建或复用消息任务并同步推进发送。 */
    deliver(input: DeliveryInput): Promise<MessageTaskResult>;
    /** 从首个未成功分段继续发送同一消息任务。 */
    resume(taskId: string): Promise<MessageTaskResult>;
    private process;
    private validate;
    private audit;
}
