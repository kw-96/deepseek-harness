import type { Hono } from 'hono';
import type { GcpWebhookHandler } from './handler.js';
import { type WebhookRequestLog } from './log.js';
/** 承载回调的路径来源。 */
export type WebhookSource = 'host' | 'ingress';
/**
 * 注册易协作事件接收路由；宿主前缀与独立入口共用同一契约。
 * 每次回调都写入入口记录，被拒绝的请求同样留痕以便诊断。
 * @param app 目标 Hono 应用
 * @param token 入口令牌，构成路径最后一段
 * @param webhook 事件处理器
 * @param log 入口回调记录
 * @param source 当前承载路径的来源标记
 */
export declare function installWebhookRoute(app: Hono, token: string, webhook: GcpWebhookHandler, log: WebhookRequestLog, source: WebhookSource): void;
