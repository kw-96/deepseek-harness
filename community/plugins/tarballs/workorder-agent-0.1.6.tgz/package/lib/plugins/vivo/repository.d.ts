import type Database from 'better-sqlite3';
import type { VivoCase, VivoRun, VivoSummary } from './types.js';
/** 案例对比键：同一游戏、资源位与素材视为同一条案例。 */
export declare function caseKey(game: string, position: string, imageUrl: string, name: string): string;
/** vivo 优秀案例的持久化仓库。 */
export declare class VivoRepository {
    private readonly db;
    constructor(db: Database.Database);
    /**
     * 覆盖写入一轮采集及其案例。
     * @param run 轮次信息
     * @param cases 该轮案例
     */
    saveRun(run: VivoRun, cases: VivoCase[]): void;
    /** 返回最近采集轮次。 */
    listRuns(limit?: number): VivoRun[];
    /** 判断该轮次是否已入库。 */
    hasRun(id: string): boolean;
    /**
     * 按条件列出案例。
     * @param filter 轮次、游戏、资源位与条数上限
     * @returns 案例列表，按点击率倒序
     */
    listCases(filter?: {
        runId?: string;
        game?: string;
        position?: string;
        limit?: number;
    }): VivoCase[];
    /**
     * 读取指定轮次之前各案例键的历史最高点击率。
     * 轮次目录名按时间递增，直接以字符串比较确定先后。
     * @param runId 目标轮次
     * @returns 案例键到历史最高点击率的映射
     */
    bestCtrBefore(runId: string): Map<string, number>;
    /** 返回案例明细的筛选维度取值。 */
    facets(): {
        games: string[];
        positions: string[];
    };
    /**
     * 返回最近一轮的去重案例集合：同一「游戏 + 资源位 + 素材」只保留最高点击率。
     * 与既有 dashboard 的口径一致。
     * @param runId 轮次；缺省取最新一轮
     */
    bestCases(runId?: string): VivoCase[];
    /** 返回看板汇总。 */
    summary(): VivoSummary;
}
