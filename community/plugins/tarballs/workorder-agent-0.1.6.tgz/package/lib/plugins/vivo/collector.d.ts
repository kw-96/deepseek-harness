/** 采集任务状态。 */
export interface CollectState {
    running: boolean;
    targets: string[];
    startedAt?: string;
    finishedAt?: string;
    exitCode?: number;
    log: string[];
}
/** vivo 采集进程管理：同一时刻只允许一个任务，保留日志尾部。 */
export declare class VivoCollector {
    private readonly options;
    private readonly onFinish?;
    private child?;
    private current;
    /**
     * @param options 项目目录、Python 解释器与采集脚本
     * @param onFinish 进程结束后的回调，用于同步新产出
     */
    constructor(options: {
        projectDir: string;
        python: string;
        script: string;
    }, onFinish?: (() => void) | undefined);
    /**
     * 启动一次采集。
     * @param targets 游戏名列表
     * @returns 是否启动成功及失败原因
     */
    start(targets: string[]): {
        started: boolean;
        reason?: string;
    };
    /** 返回当前任务状态快照。 */
    state(): CollectState;
    /**
     * 终止正在运行的采集进程；采集脚本会自行关闭浏览器上下文。
     * @returns 是否真的终止了任务
     */
    stop(): boolean;
    private append;
    private finish;
}
