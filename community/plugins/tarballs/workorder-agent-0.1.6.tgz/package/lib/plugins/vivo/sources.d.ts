import type { VivoCase, VivoRun } from './types.js';
/**
 * 解析点击率文本为百分数数值；非法值返回 undefined。
 * @param value 形如 "1.30%" 的文本
 * @returns 百分数数值或 undefined
 */
export declare function parseCtr(value: unknown): number | undefined;
/**
 * 把一轮 data.json 解析为轮次信息与案例列表。
 * 兼容两种历史结构：结果项自带 case 对象，或旧版的 rank1 对象。
 * @param payload data.json 内容
 * @param runId 轮次目录名
 * @returns 轮次与案例
 */
export declare function parseRun(payload: unknown, runId: string): {
    run: VivoRun;
    cases: VivoCase[];
};
/**
 * 扫描采集输出目录下的全部轮次。
 * @param outputDir vivo-data 的 output 目录
 * @returns 按采集时间倒序的轮次与其案例
 */
export declare function scanOutput(outputDir: string): Array<{
    run: VivoRun;
    cases: VivoCase[];
}>;
