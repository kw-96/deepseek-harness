import type { InspectionRequest, InspectionResult } from '../../domain/types.js';
import type { GcpIssueService } from '../gcp/service.js';
import type { PopoDeliveryService } from '../popo/delivery.js';
import type { WorkorderStore } from '../store/store.js';
/** 设计师巡检工作流，负责查询、规则、幂等和发送闸门。 */
export declare class InspectionWorkflow {
    private readonly issues;
    private readonly store;
    private readonly delivery;
    private readonly gcpHost;
    private readonly testReceiver;
    constructor(issues: GcpIssueService, store: WorkorderStore, delivery: PopoDeliveryService, gcpHost: string, testReceiver: string);
    /** 发送固定内容的测试通知，不查询工单。 */
    sendTestNotification(): Promise<string>;
    /** 执行巡检；正式验收仅生成持久预览，不直接发送。 */
    inspect(request: InspectionRequest): Promise<InspectionResult>;
    /** 人工再次发送历史复核结果，每次确认均创建独立发送记录。 */
    resendPreview(previewId: string): Promise<string>;
    /** 发送此前持久化且未过期的同一份预览消息。 */
    sendPreview(previewId: string): Promise<InspectionResult>;
    private persistPreview;
    private sendOnce;
}
