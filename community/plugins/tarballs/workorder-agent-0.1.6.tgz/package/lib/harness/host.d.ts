import type { Context } from '@deepseek-ai/cordis';
import { Config, type PluginConfig } from './pluginConfig.js';
export declare const name = "workorder-agent-host";
export declare const inject: string[];
export { Config };
/**
 * 挂载工单 Host：配置走本插件 profile 条目的 volatile 字段，关闭 enabled 时卸载运行时。
 *
 * 0.2.0 起设置服务只投影 profile 条目的 volatile 字段，插件不再注册设置分节：
 * 条目 id 由 Loader 提供（`ctx.fiber.entry`），写入走 `ctx.settings.update`。
 * @param ctx 插件上下文
 * @param config 组合层配置（volatile 引用）
 */
export declare function apply(ctx: Context, config: PluginConfig): Promise<void>;
