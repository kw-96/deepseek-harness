import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type AppConfig } from '../config.js';
/** 工单 Host 插件的配置值。 */
export interface PluginConfigValues {
    enabled: boolean;
    dataDir: string;
    webhookToken: string;
    webhookIngressEnabled: boolean;
    webhookIngressHost: string;
    webhookIngressPort: number;
    gcpUserKey: string;
    gcpUrl: string;
    gcpHost: string;
    popoAppId: string;
    popoAppSecret: string;
    popoAppReceiver: string;
    completedStatusId: number;
    projectIdChannelArt: number;
    projectIdReturnBusiness: number;
    projectIdAiOperations: number;
    reviewEnabled: boolean;
    reviewProvider: string;
    reviewModel: string;
    reviewMaxTokens: number;
    reviewKnowledgeBase: string;
    reviewNotificationEnabled: boolean;
    vivoProjectDir: string;
    vivoPython: string;
    vivoScript: string;
    vivoTargets: string;
}
/**
 * 工单 Host 插件的可热更新配置。
 *
 * 0.2.0 起设置表单直接投影 profile 条目的 volatile 字段，因此每个字段都是 Loader
 * 原地提交的引用；插件用 `.get()` 读取当前生效值，无需再向设置服务注册分节。
 */
export type PluginConfig = {
    [K in keyof PluginConfigValues]: Volatile<PluginConfigValues[K]>;
};
/** Cordis / 设置卡片使用的工单插件配置模式。 */
export declare const Config: z<PluginConfig>;
/**
 * 读取当前生效的配置值。
 * @param config 插件 Config 的 volatile 引用集合
 * @returns 解包后的普通配置值
 */
export declare function readPluginConfig(config: PluginConfig): PluginConfigValues;
/**
 * 将插件配置映射为业务运行配置。
 * @param plugin 已按 schema 解析的插件配置
 * @returns 业务运行时配置
 */
export declare function toAppConfig(plugin: PluginConfigValues): AppConfig;
