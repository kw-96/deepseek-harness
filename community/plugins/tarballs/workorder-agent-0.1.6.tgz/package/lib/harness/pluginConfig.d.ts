import z from '@deepseek-ai/schemastery';
import { type AppConfig } from '../config.js';
/** 工单 Host 插件的可热更新配置。 */
export interface PluginConfig {
    enabled: boolean;
    dataDir: string;
    webhookToken: string;
    webhookIngressEnabled: boolean;
    webhookIngressHost: string;
    webhookIngressPort: number;
    gcpUserKey: string;
    gcpUrl: string;
    gcpHost: string;
    popoAppId: string;
    popoAppSecret: string;
    popoAppReceiver: string;
    completedStatusId: number;
    projectIdChannelArt: number;
    projectIdReturnBusiness: number;
    projectIdAiOperations: number;
    reviewEnabled: boolean;
    reviewProvider: string;
    reviewModel: string;
    reviewMaxTokens: number;
    reviewKnowledgeBase: string;
    reviewNotificationEnabled: boolean;
    vivoProjectDir: string;
    vivoPython: string;
    vivoScript: string;
    vivoTargets: string;
}
/** Cordis / 设置卡片使用的工单插件配置模式。 */
export declare const Config: z<PluginConfig>;
/**
 * 将插件配置映射为业务运行配置。
 * @param plugin 已按 schema 解析的插件配置
 * @returns 业务运行时配置
 */
export declare function toAppConfig(plugin: PluginConfig): AppConfig;
