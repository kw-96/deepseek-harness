import type { ProjectMap } from './plugins/gcp/service.js';
/** 默认提单规范，作为模型审核的可编辑知识库初始内容。 */
export declare const DEFAULT_REVIEW_KNOWLEDGE_BASE: string;
export interface AppConfigInput {
    port?: number;
    dataDir?: string;
    webhookToken: string;
    webhookIngressEnabled?: boolean;
    webhookIngressHost?: string;
    webhookIngressPort?: number;
    gcpUserKey: string;
    gcpUrl?: string;
    gcpHost?: string;
    popoAppId?: string;
    popoAppSecret?: string;
    popoAppReceiver?: string;
    completedStatusId?: number;
    projectIdChannelArt?: number;
    projectIdReturnBusiness?: number;
    projectIdAiOperations?: number;
    reviewEnabled?: boolean;
    reviewProvider?: string;
    reviewModel?: string;
    reviewMaxTokens?: number;
    reviewKnowledgeBase?: string;
    reviewNotificationEnabled?: boolean;
    vivoProjectDir?: string;
    vivoPython?: string;
    vivoScript?: string;
    vivoTargets?: string;
}
export interface AppConfig {
    port: number;
    dataDir: string;
    webhookToken: string;
    /** 独立事件入口：供内网中的易协作网关回调，关闭时只保留宿主前缀内的入口。 */
    webhookIngress: {
        enabled: boolean;
        host: string;
        port: number;
    };
    projects: ProjectMap;
    completedStatusId: number;
    gcp: {
        url: string;
        host: string;
        userKey: string;
    };
    /** POPO 机器人应用通道：App 凭证换 token 后发送，接收人为用户邮箱或群 ID。 */
    popo: {
        app: {
            id: string;
            secret: string;
            receiver: string;
        };
    };
    review: {
        enabled: boolean;
        provider?: string;
        model?: string;
        maxTokens: number;
        knowledgeBase: string;
        notificationEnabled: boolean;
    };
    /** vivo 优秀案例集成：项目目录、采集解释器与默认采集目标。 */
    vivo: {
        projectDir: string;
        python: string;
        script: string;
        defaultTargets: string;
    };
}
/**
 * 将已解析字段组装为运行配置。
 * @param input 令牌、项目与连接参数
 * @returns 校验后的应用配置
 */
export declare function buildAppConfig(input: AppConfigInput): AppConfig;
/** 从进程环境变量读取并校验运行配置。 */
export declare function loadConfig(): AppConfig;
